# 04. Referências acadêmicas comentadas

## Objetivo
Este documento ancora a malha conceitual em bases acadêmicas convergentes, distinguindo:
- estruturas aceitas na literatura;
- hipóteses especulativas;
- termos autorais que exigem formalização própria.

## Referências fundamentais por eixo

### 1. Física de partículas e teoria quântica de campos
1. **Peskin, M. E.; Schroeder, D. V.** *An Introduction to Quantum Field Theory*.  
   Uso: base para campos, simetrias, quantização e interações fundamentais.

2. **Weinberg, S.** *The Quantum Theory of Fields* (Vols. I–III).  
   Uso: formulação rigorosa de teoria quântica de campos e simetria.

3. **Griffiths, D.; Schroeter, D.** *Introduction to Elementary Particles*.  
   Uso: introdução organizada ao Modelo Padrão, quarks, glúons e interações.

### 2. Gravitação e relatividade
4. **Misner, C. W.; Thorne, K. S.; Wheeler, J. A.** *Gravitation*.  
   Uso: base clássica para relatividade geral, geometria e efeitos gravitacionais.

5. **Carroll, S.** *Spacetime and Geometry*.  
   Uso: ponte entre relatividade geral e formalização geométrica moderna.

6. **Ciufolini, I.; Wheeler, J. A.** *Gravitation and Inertia*.  
   Uso: referência útil para frame dragging e efeito de Lense–Thirring.

### 3. Gravidade quântica e formulações extensionais
7. **Rovelli, C.** *Quantum Gravity*.  
   Uso: introdução técnica à gravidade quântica em loop.

8. **Thiemann, T.** *Modern Canonical Quantum General Relativity*.  
   Uso: formulação canônica detalhada e rigorosa.

> Nota: “gravidade escalar”, “gravidade plasmática” e “forças da quinta à sétima ordem” não são, por si, teorias estabelecidas. Só podem entrar como hipóteses explicitamente marcadas.

### 4. Geometria e estruturas matemáticas
9. **Nakahara, M.** *Geometry, Topology and Physics*.  
   Uso: variedades, fibrados, conexões e geometria aplicada à física.

10. **Frankel, T.** *The Geometry of Physics*.  
    Uso: integração entre matemática geométrica e física teórica.

11. **Hori, K. et al.** *Mirror Symmetry*.  
    Uso: referência forte para dualidades e estruturas de Calabi–Yau.

### 5. Decoerência, informação quântica e sistemas abertos
12. **Schlosshauer, M.** *Decoherence and the Quantum-To-Classical Transition*.  
    Uso: decoerência como mecanismo de transição efetiva entre regimes.

13. **Nielsen, M.; Chuang, I.** *Quantum Computation and Quantum Information*.  
    Uso: estados, operadores, medição e informação quântica.

### 6. Cosmologia, matéria escura e energia escura
14. **Mukhanov, V.** *Physical Foundations of Cosmology*.  
    Uso: estrutura cosmológica moderna.

15. **Dodelson, S.; Schmidt, F.** *Modern Cosmology*.  
    Uso: matéria escura, energia escura e dinâmica cosmológica.

### 7. Twistor theory e formalismos avançados
16. **Penrose, R.; Rindler, W.** *Spinors and Space-Time*.  
    Uso: base para spinors, twistors e estruturas geométricas associadas.

17. **Ward, R.; Wells, R.** *Twistor Geometry and Field Theory*.  
    Uso: ligação entre teoria de campos e formulações twistoriais.

### 8. Engenharia reversa, sistemas e execução
18. **Levine, J.** *Linkers and Loaders*.  
    Uso: loaders, linkers, relocação e organização do binário.

19. **Bryant, R.; O'Hallaron, D.** *Computer Systems: A Programmer's Perspective*.  
    Uso: stack, heap, processo, memória, linking e execução.

20. **Yosifovich, P.; Ionescu, A.; Russinovich, M.; Solomon, D.** *Windows Internals* / referências equivalentes em sistemas operacionais.  
    Uso: execução, memória, threads, TLS e comportamento interno.

21. **Love, R.** *Linux Kernel Development*.  
    Uso: kernel, scheduling, memória e estrutura de baixo nível.

## Classificação epistemológica recomendada

### A. Pode ser usado como fundamento técnico
- quarks e glúons
- interação de cor
- campo de Higgs
- decoerência
- Lense–Thirring
- Bose–Einstein
- Calabi–Yau
- mirror symmetry
- twistor theory
- geometria não euclidiana
- linkers/loaders/heap/stack/TLS

### B. Só pode ser usado como hipótese
- forças de quinta ordem em diante
- gravidade escalar
- gravidade plasmática
- hiperdimensões arbitrárias sem modelo definido
- campos morfogenéticos como ontologia física
- intenção como variável física fundamental

### C. Exige tradução formal antes de qualquer uso técnico
- verbo vivo
- intenção pura
- spin transcendente
- loop infinito abortado
- fractal vivo
- alfa do amor

## Regras de uso acadêmico
1. Não tratar termos autorais como equivalentes a teorias estabelecidas.
2. Não atribuir validade empírica a hipóteses sem observável.
3. Definir domínio matemático, variável e regra de transição antes de alegar modelo.
4. Toda extensão deve informar em que difere das teorias existentes.
5. Toda hipótese deve declarar condição de refutação.

## F de resolvido
- Referências-base organizadas por área.
- Separação entre fundamento, hipótese e léxico autoral.

## F de gap
- Ainda falta converter cada referência em citação ABNT/BibTeX.
- Ainda falta amarrar cada capítulo do paper a essas fontes.

## F de next
1. Gerar `.bib` e referências em ABNT.
2. Inserir citações dentro do paper-base.
3. Cruzar cada termo da taxonomia com pelo menos 1 referência principal.
