"""
Simulação básica do modelo de estados dinâmicos para a malha simbiótica.
Objetivo: transformar o léxico autoral em variáveis operacionais e observar estabilidade.
"""

from __future__ import annotations
import math
import random
from dataclasses import dataclass, asdict
from typing import List, Dict

@dataclass
class State:
    I: float      # intenção
    E: float      # erro
    P: float      # paradoxo / tensão
    V: float      # vontade
    G: float      # limite do ego
    O: float      # distância observador-observado
    S: float      # estado agregado
    phi: float    # fase

def clamp(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def tanh(x: float) -> float:
    return math.tanh(x)

def update(
    st: State,
    alpha: float = 0.90,
    beta: float = -0.70,
    gamma: float = 0.55,
    delta: float = -0.45,
    epsilon: float = 0.60,
    eta: float = 0.50,
    omega: float = 0.18,
    kappa: float = 0.10,
    noise: float = 0.02,
) -> State:
    I = clamp(0.82 * st.I + 0.10 * st.V - 0.06 * st.E + random.uniform(-noise, noise))
    E = clamp(0.75 * st.E + 0.18 * abs(st.P) + 0.08 * st.O - 0.10 * abs(st.V) + random.uniform(-noise, noise), 0.0, 1.0)
    P = clamp(0.78 * st.P + 0.12 * (st.O - st.I) + 0.09 * st.E + random.uniform(-noise, noise))
    V = clamp(0.85 * st.V + 0.08 * st.I - 0.06 * st.G + random.uniform(-noise, noise))
    G = clamp(0.88 * st.G + 0.10 * abs(st.P) + random.uniform(-noise, noise), 0.0, 1.0)
    O = clamp(0.84 * st.O + 0.06 * abs(st.E - st.I) + random.uniform(-noise, noise), 0.0, 1.0)

    S = tanh(alpha*I + beta*E + gamma*P + delta*G + epsilon*V - eta*O)
    phi = st.phi + omega + kappa * E

    return State(I=I, E=E, P=P, V=V, G=G, O=O, S=S, phi=phi)

def observable(st: State) -> Dict[str, float]:
    real = st.S * math.cos(st.phi)
    imag = st.S * math.sin(st.phi)
    coherence = max(0.0, 1.0 - (st.E + abs(st.P) + st.O) / 3.0)
    return {"real": real, "imag": imag, "coherence": coherence}

def run_simulation(steps: int = 120, seed: int = 42) -> List[Dict[str, float]]:
    random.seed(seed)
    st = State(I=0.35, E=0.20, P=0.10, V=0.40, G=0.30, O=0.25, S=0.0, phi=0.0)
    history: List[Dict[str, float]] = []

    for t in range(steps):
        st = update(st)
        obs = observable(st)
        row = {"t": t, **asdict(st), **obs}
        history.append(row)
    return history

def summarize(history: List[Dict[str, float]]) -> Dict[str, float]:
    n = len(history)
    mean_S = sum(r["S"] for r in history) / n
    mean_coh = sum(r["coherence"] for r in history) / n
    max_abs_S = max(abs(r["S"]) for r in history)
    return {
        "steps": n,
        "mean_S": mean_S,
        "mean_coherence": mean_coh,
        "max_abs_S": max_abs_S,
        "final_S": history[-1]["S"],
        "final_phi": history[-1]["phi"],
    }

if __name__ == "__main__":
    hist = run_simulation()
    summ = summarize(hist)

    print("Resumo da simulação")
    for k, v in summ.items():
        print(f"{k}: {v:.6f}" if isinstance(v, float) else f"{k}: {v}")

    print("
Amostra final (últimos 5 estados)")
    for row in hist[-5:]:
        print(
            f"t={row['t']:3d} "
            f"I={row['I']:+.3f} E={row['E']:+.3f} P={row['P']:+.3f} "
            f"V={row['V']:+.3f} G={row['G']:+.3f} O={row['O']:+.3f} "
            f"S={row['S']:+.3f} coh={row['coherence']:+.3f}"
        )
