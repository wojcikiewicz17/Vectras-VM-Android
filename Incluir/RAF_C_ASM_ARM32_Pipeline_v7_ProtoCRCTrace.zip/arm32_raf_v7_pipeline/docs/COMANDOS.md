# Comandos

```bash
make
make test
make bench
make export
make fault
make target
make arm32_objcheck
```

Arquivos principais gerados:
- `docs/HOST_SELFTEST.txt`
- `docs/HOST_BENCHMARK.txt`
- `docs/HOST_FAULT.txt`
- `docs/HOST_TARGET.txt`
- `out/*.csv`
- `out/*.log`
- `out/*.bin`
