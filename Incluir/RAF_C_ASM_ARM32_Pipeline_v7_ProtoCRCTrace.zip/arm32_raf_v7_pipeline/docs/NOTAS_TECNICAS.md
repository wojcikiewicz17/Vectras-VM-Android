# Notas técnicas — v7

## 1. Parser de frame mais realista
A v7 sai do modelo “header simples + payload” e entra em um wire format com:
- sincronização (`sof`)
- validação de header (`header_crc16`)
- tipagem (`msg_type`)
- fragmentação (`frag_off`, `frag_len`, `total_len`)
- controle de fluxo lógico (`stream_id`, `seq`)
- integridade ponta a ponta (`payload_crc32`)

O reassembly aceita apenas fragmentos contíguos do mesmo `stream_id + seq`.

## 2. CRC híbrido
O modo `hybrid` foi desenhado para:
- rodar SW otimizado como baseline portátil
- usar HW quando o alvo expõe suporte real
- manter contabilidade explícita de:
  - `crc_hw_used`
  - `crc_hw_fallbacks`
  - `crc_sw_bytes`
  - `crc_hw_bytes`

## 3. Telemetria
A v7 adiciona três camadas de observabilidade:
- **CSV** para análise rápida em planilha/scripts
- **log textual** para troubleshooting humano
- **trace binário fixo** para pós-processamento de alto volume

Também foram adicionados:
- **p999**
- histograma por faixas de ns
- `packet_count` por mensagem reassemblada

## 4. Fault model
Fault injection continua determinístico, com quatro tipos:
- drop fragment
- corrupt header
- corrupt payload
- truncate last

Na v7, o impacto é mais real porque a unidade de falha age no **wire packet/fragmento**, e não apenas no frame já pronto.
