# Modo alvo — contador de ciclos / timer de hardware

A v7 mantém suporte ao mesmo modelo de relógio da v6:

- `host-clock` (fallback portátil)
- `arm-pmccntr`
- `arm-generic-timer`

## Macros relevantes
- `RAF_ARM32_USE_PMCCNTR`
- `RAF_ARM32_USE_GENERIC_TIMER`

## Leitura honesta
Neste ambiente, o modo `target` roda com fallback `host-clock`.
No alvo ARM32 real, o objetivo é ligar uma das fontes acima para medir ciclos/tempo sem depender do relógio do host.

## Uso típico no alvo
```bash
make CFLAGS='-O3 -DRAF_ARM32_USE_PMCCNTR'
./build/host/raf_pipeline_v7 target
```
ou
```bash
make CFLAGS='-O3 -DRAF_ARM32_USE_GENERIC_TIMER'
./build/host/raf_pipeline_v7 target
```
