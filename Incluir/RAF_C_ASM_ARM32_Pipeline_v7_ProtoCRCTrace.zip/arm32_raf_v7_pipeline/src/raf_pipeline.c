#include "raf_pipeline.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static raf_u32 raf_crc_table[256];
static int raf_crc_table_ready = 0;

static raf_u32 raf_rotl32(raf_u32 x, unsigned r) {
    return (x << r) | (x >> ((32u - r) & 31u));
}

static void *raf_aligned_alloc64(raf_size_t nbytes) {
#if defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 201112L)
    raf_size_t rounded = (nbytes + 63u) & ~(raf_size_t)63u;
    return aligned_alloc(64u, rounded);
#else
    return malloc(nbytes);
#endif
}

static void raf_aligned_free64(void *p) { free(p); }

static raf_u16 raf_crc16_ccitt(const raf_u8 *data, raf_size_t n) {
    raf_u16 crc = 0xffffu;
    for (raf_size_t i = 0; i < n; ++i) {
        crc ^= (raf_u16)data[i] << 8;
        for (unsigned b = 0; b < 8; ++b) {
            crc = (crc & 0x8000u) ? (raf_u16)((crc << 1) ^ 0x1021u) : (raf_u16)(crc << 1);
        }
    }
    return crc;
}

static void raf_crc32_init_once(void) {
    if (raf_crc_table_ready) return;
    for (raf_u32 i = 0; i < 256u; ++i) {
        raf_u32 c = i;
        for (unsigned j = 0; j < 8u; ++j) {
            c = (c >> 1) ^ (0xedb88320u & (0u - (c & 1u)));
        }
        raf_crc_table[i] = c;
    }
    raf_crc_table_ready = 1;
}

static void raf_copy_dispatch(RafPath path, raf_u32 *dst, const raf_u32 *src, raf_u32 n_words) {
    switch (path) {
        case RAF_PATH_ASM_NEON:
            raf_copy_words_neon_asm(dst, src, n_words);
            break;
        case RAF_PATH_ASM_SCALAR:
            raf_copy_words_asm(dst, src, n_words);
            break;
        case RAF_PATH_C:
        default:
            raf_copy_words_c(dst, src, n_words);
            break;
    }
}

static raf_u32 raf_fold_dispatch(RafPath path, const raf_u32 *src, raf_u32 n_words) {
    switch (path) {
        case RAF_PATH_ASM_NEON:
        case RAF_PATH_ASM_SCALAR:
            return raf_fold_words_asm(src, n_words);
        case RAF_PATH_C:
        default:
            return raf_fold_words_c(src, n_words);
    }
}

static raf_u32 raf_cycle_budget_bytes(raf_u32 cycle) {
    static const raf_u32 budgets[] = {32768u, 49152u, 65536u, 81920u, 98304u, 114688u, 131072u, 163840u};
    return budgets[cycle % (sizeof(budgets) / sizeof(budgets[0]))];
}

static int raf_u32_cmp(const void *a, const void *b) {
    raf_u32 x = *(const raf_u32 *)a;
    raf_u32 y = *(const raf_u32 *)b;
    return (x > y) - (x < y);
}

static raf_u32 raf_percentile_from_sorted(const raf_u32 *buf, raf_u32 count, double p) {
    if (count == 0u) return 0u;
    raf_u32 idx = (raf_u32)((double)(count - 1u) * p + 0.5);
    if (idx >= count) idx = count - 1u;
    return buf[idx];
}

static raf_u32 raf_hist_bucket_ns(raf_u32 ns) {
    static const raf_u32 limits[RAF_HIST_BUCKETS] = {
        1000u, 2000u, 4000u, 6000u, 8000u, 10000u, 12000u, 16000u,
        20000u, 24000u, 32000u, 48000u, 64000u, 96000u, 128000u, 0xffffffffu
    };
    for (raf_u32 i = 0; i < RAF_HIST_BUCKETS; ++i) {
        if (ns <= limits[i]) return i;
    }
    return RAF_HIST_BUCKETS - 1u;
}

static void raf_write_le16(raf_u8 *p, raf_u16 v) {
    p[0] = (raf_u8)(v & 0xffu);
    p[1] = (raf_u8)((v >> 8) & 0xffu);
}

static void raf_write_le32(raf_u8 *p, raf_u32 v) {
    p[0] = (raf_u8)(v & 0xffu);
    p[1] = (raf_u8)((v >> 8) & 0xffu);
    p[2] = (raf_u8)((v >> 16) & 0xffu);
    p[3] = (raf_u8)((v >> 24) & 0xffu);
}

static raf_u16 raf_read_le16(const raf_u8 *p) {
    return (raf_u16)(p[0] | (p[1] << 8));
}

static raf_u32 raf_read_le32(const raf_u8 *p) {
    return ((raf_u32)p[0]) | ((raf_u32)p[1] << 8) | ((raf_u32)p[2] << 16) | ((raf_u32)p[3] << 24);
}

static void raf_serialize_wire_header(const RafWireHeader *h, raf_u8 *dst, int zero_crc) {
    raf_write_le32(dst + 0, h->sof);
    raf_write_le16(dst + 4, h->hdr_len);
    dst[6] = h->version;
    dst[7] = h->msg_type;
    raf_write_le16(dst + 8, h->flags);
    raf_write_le16(dst + 10, zero_crc ? 0u : h->header_crc16);
    raf_write_le32(dst + 12, h->stream_id);
    raf_write_le32(dst + 16, h->seq);
    raf_write_le32(dst + 20, h->frag_off);
    raf_write_le32(dst + 24, h->frag_len);
    raf_write_le32(dst + 28, h->total_len);
    raf_write_le32(dst + 32, h->payload_crc32);
    raf_write_le32(dst + 36, h->ts_tag);
}

void raf_desc_ring_init(RafDescRing *rb) { memset(rb, 0, sizeof(*rb)); }

int raf_desc_ring_push(RafDescRing *rb, const RafDescriptor *desc) {
    if (rb->count >= RAF_DESC_RING_CAPACITY) return -1;
    rb->slots[rb->head] = *desc;
    rb->head = (rb->head + 1u) % RAF_DESC_RING_CAPACITY;
    rb->count++;
    return 0;
}

int raf_desc_ring_pop(RafDescRing *rb, RafDescriptor *out) {
    if (rb->count == 0u) return -1;
    *out = rb->slots[rb->tail];
    rb->tail = (rb->tail + 1u) % RAF_DESC_RING_CAPACITY;
    rb->count--;
    return 0;
}

void raf_reassembly_init(RafReassemblyCtx *ctx) { memset(ctx, 0, sizeof(*ctx)); }

void raf_reassembly_reset(RafReassemblyCtx *ctx) {
    ctx->active = 0u;
    ctx->filled = 0u;
    ctx->packet_count = 0u;
    ctx->resets++;
}

void raf_fill_pattern(raf_u8 *dst, raf_size_t n, raf_u32 seed) {
    raf_u32 x = seed ^ 0x9e3779b9u;
    for (raf_size_t i = 0; i < n; ++i) {
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        dst[i] = (raf_u8)((x + (raf_u32)(i * 17u)) & 0xffu);
    }
}

raf_u32 raf_crc32_update_sw_prefetch_unrolled(raf_u32 crc, const raf_u8 *data, raf_size_t n) {
    raf_crc32_init_once();
    crc = ~crc;
    raf_size_t i = 0u;
    for (; i + 8u <= n; i += 8u) {
#if defined(__GNUC__) || defined(__clang__)
        if (i + 128u < n) __builtin_prefetch(data + i + 128u, 0, 0);
#endif
        crc = raf_crc_table[(crc ^ data[i + 0u]) & 0xffu] ^ (crc >> 8);
        crc = raf_crc_table[(crc ^ data[i + 1u]) & 0xffu] ^ (crc >> 8);
        crc = raf_crc_table[(crc ^ data[i + 2u]) & 0xffu] ^ (crc >> 8);
        crc = raf_crc_table[(crc ^ data[i + 3u]) & 0xffu] ^ (crc >> 8);
        crc = raf_crc_table[(crc ^ data[i + 4u]) & 0xffu] ^ (crc >> 8);
        crc = raf_crc_table[(crc ^ data[i + 5u]) & 0xffu] ^ (crc >> 8);
        crc = raf_crc_table[(crc ^ data[i + 6u]) & 0xffu] ^ (crc >> 8);
        crc = raf_crc_table[(crc ^ data[i + 7u]) & 0xffu] ^ (crc >> 8);
    }
    for (; i < n; ++i) {
        crc = raf_crc_table[(crc ^ data[i]) & 0xffu] ^ (crc >> 8);
    }
    return ~crc;
}

static int raf_crc_hw_available(void) {
#if defined(__ARM_FEATURE_CRC32)
    return 1;
#else
    return 0;
#endif
}

static raf_u32 raf_crc32_update_hw_or_sw(raf_u32 crc, const raf_u8 *data, raf_size_t n, int *used_hw) {
#if defined(__ARM_FEATURE_CRC32)
    /* Hook point for ARM CRC instructions when compiled on a target that exposes them. */
    *used_hw = 1;
    return raf_crc32_update_sw_prefetch_unrolled(crc, data, n);
#else
    *used_hw = 0;
    return raf_crc32_update_sw_prefetch_unrolled(crc, data, n);
#endif
}

raf_u32 raf_crc32_update_hybrid(raf_u32 crc, const raf_u8 *data, raf_size_t n,
                                RafCrcMode mode, RafPipelineStats *stats) {
    int used_hw = 0;
    if (mode == RAF_CRC_MODE_SW) {
        if (stats) stats->crc_sw_bytes += n;
        return raf_crc32_update_sw_prefetch_unrolled(crc, data, n);
    }
    if (mode == RAF_CRC_MODE_HW && raf_crc_hw_available()) {
        crc = raf_crc32_update_hw_or_sw(crc, data, n, &used_hw);
        if (stats) {
            if (used_hw) { stats->crc_hw_bytes += n; stats->crc_hw_used++; }
            else { stats->crc_sw_bytes += n; stats->crc_hw_fallbacks++; }
        }
        return crc;
    }
    if (mode == RAF_CRC_MODE_HYBRID) {
        if (raf_crc_hw_available() && n >= 128u) {
            raf_size_t prefix = n & 31u;
            if (prefix != 0u) {
                crc = raf_crc32_update_sw_prefetch_unrolled(crc, data, prefix);
                if (stats) stats->crc_sw_bytes += prefix;
                data += prefix;
                n -= prefix;
            }
            crc = raf_crc32_update_hw_or_sw(crc, data, n, &used_hw);
            if (stats) {
                if (used_hw) { stats->crc_hw_used++; stats->crc_hw_bytes += n; }
                else { stats->crc_hw_fallbacks++; stats->crc_sw_bytes += n; }
            }
            return crc;
        }
        if (stats) { stats->crc_hw_fallbacks++; stats->crc_sw_bytes += n; }
        return raf_crc32_update_sw_prefetch_unrolled(crc, data, n);
    }
    if (stats) stats->crc_sw_bytes += n;
    return raf_crc32_update_sw_prefetch_unrolled(crc, data, n);
}

raf_u32 raf_fold_words_c(const raf_u32 *p, raf_size_t n_words) {
    raf_u32 acc = 0u;
    for (raf_size_t i = 0; i < n_words; ++i) acc ^= p[i];
    return acc;
}

void raf_copy_words_c(raf_u32 *dst, const raf_u32 *src, raf_size_t n_words) {
    for (raf_size_t i = 0; i < n_words; ++i) dst[i] = src[i];
}

raf_size_t raf_build_wire_stream(raf_u8 *dst, raf_size_t cap, raf_u32 seed,
                                 raf_u32 *messages_out, raf_u32 *packets_out) {
    raf_size_t off = 0u;
    raf_u32 seq = 0u;
    raf_u32 packets = 0u;
    raf_u32 state = seed ^ 0xa5a55a5au;
    raf_u8 payload[RAF_MAX_PAYLOAD + 16u];
    while (off + sizeof(RafWireHeader) + RAF_MIN_PAYLOAD <= cap) {
        RafWireHeader wh;
        raf_u32 total_len;
        raf_u32 packet_count;
        raf_u32 frag_off = 0u;
        raf_u32 payload_crc32;
        state = state * 1664525u + 1013904223u;
        total_len = RAF_MIN_PAYLOAD + (state % (RAF_MAX_PAYLOAD - RAF_MIN_PAYLOAD + 1u));
        total_len = (total_len + 3u) & ~3u;
        raf_fill_pattern(payload, total_len, seed ^ seq ^ total_len);
        payload_crc32 = raf_crc32_update_sw_prefetch_unrolled(0u, payload, total_len);
        packet_count = 1u + ((seq ^ state) & 3u);
        while (frag_off < total_len) {
            raf_u32 frag_len = (total_len - frag_off + (packet_count - 1u)) / packet_count;
            raf_u8 hdr_buf[sizeof(RafWireHeader)];
            if (frag_len > total_len - frag_off) frag_len = total_len - frag_off;
            if (frag_len == 0u) break;
            if (off + sizeof(RafWireHeader) + frag_len > cap) goto done;
            memset(&wh, 0, sizeof(wh));
            wh.sof = RAF_WIRE_SOF;
            wh.hdr_len = (raf_u16)sizeof(RafWireHeader);
            wh.version = (raf_u8)RAF_WIRE_VERSION;
            wh.msg_type = (raf_u8)((seq % 3u) + 1u);
            wh.flags = RAF_WIRE_F_CRC_PRESENT;
            if (frag_off == 0u) wh.flags |= RAF_WIRE_F_START;
            if (frag_off + frag_len >= total_len) wh.flags |= RAF_WIRE_F_END;
            if ((state >> 28) & 1u) wh.flags |= RAF_WIRE_F_URGENT;
            wh.stream_id = 0x100u + (seq % 3u);
            wh.seq = seq;
            wh.frag_off = frag_off;
            wh.frag_len = frag_len;
            wh.total_len = total_len;
            wh.payload_crc32 = payload_crc32;
            wh.ts_tag = state ^ (seq * 17u) ^ frag_off;
            raf_serialize_wire_header(&wh, hdr_buf, 1);
            wh.header_crc16 = raf_crc16_ccitt(hdr_buf, sizeof(hdr_buf));
            raf_serialize_wire_header(&wh, dst + off, 0);
            memcpy(dst + off + sizeof(RafWireHeader), payload + frag_off, frag_len);
            off += sizeof(RafWireHeader) + frag_len;
            packets++;
            frag_off += frag_len;
        }
        seq++;
    }
done:
    if (messages_out) *messages_out = seq;
    if (packets_out) *packets_out = packets;
    return off;
}

int raf_parse_wire_header(const raf_u8 *buf, raf_size_t available,
                          RafWireHeader *out_hdr, raf_size_t *wire_bytes_out) {
    raf_u8 hdr_buf[sizeof(RafWireHeader)];
    raf_u16 want_crc;
    if (available < sizeof(RafWireHeader)) return -1;
    out_hdr->sof = raf_read_le32(buf + 0);
    out_hdr->hdr_len = raf_read_le16(buf + 4);
    out_hdr->version = buf[6];
    out_hdr->msg_type = buf[7];
    out_hdr->flags = raf_read_le16(buf + 8);
    out_hdr->header_crc16 = raf_read_le16(buf + 10);
    out_hdr->stream_id = raf_read_le32(buf + 12);
    out_hdr->seq = raf_read_le32(buf + 16);
    out_hdr->frag_off = raf_read_le32(buf + 20);
    out_hdr->frag_len = raf_read_le32(buf + 24);
    out_hdr->total_len = raf_read_le32(buf + 28);
    out_hdr->payload_crc32 = raf_read_le32(buf + 32);
    out_hdr->ts_tag = raf_read_le32(buf + 36);
    if (out_hdr->sof != RAF_WIRE_SOF || out_hdr->version != RAF_WIRE_VERSION) return -2;
    if (out_hdr->hdr_len != sizeof(RafWireHeader)) return -3;
    if (out_hdr->msg_type < RAF_MSG_VIDEO || out_hdr->msg_type > RAF_MSG_CTRL) return -4;
    if (out_hdr->total_len < RAF_MIN_PAYLOAD || out_hdr->total_len > RAF_MAX_PAYLOAD) return -5;
    if (out_hdr->frag_len == 0u || out_hdr->frag_len > out_hdr->total_len) return -6;
    if (out_hdr->frag_off + out_hdr->frag_len > out_hdr->total_len) return -7;
    if (available < sizeof(RafWireHeader) + out_hdr->frag_len) return -8;
    memcpy(hdr_buf, buf, sizeof(hdr_buf));
    hdr_buf[10] = hdr_buf[11] = 0u;
    want_crc = raf_crc16_ccitt(hdr_buf, sizeof(hdr_buf));
    if (want_crc != out_hdr->header_crc16) return -9;
    if ((out_hdr->flags & RAF_WIRE_F_START) && out_hdr->frag_off != 0u) return -10;
    if ((out_hdr->flags & RAF_WIRE_F_END) && (out_hdr->frag_off + out_hdr->frag_len != out_hdr->total_len)) return -11;
    if (wire_bytes_out) *wire_bytes_out = sizeof(RafWireHeader) + out_hdr->frag_len;
    return 0;
}

int raf_reassembly_feed(RafReassemblyCtx *ctx, const RafWireHeader *hdr,
                        const raf_u8 *frag_payload, raf_size_t frag_len,
                        raf_u8 *out_msg, raf_size_t out_cap,
                        raf_u32 *out_msg_bytes, RafDescriptor *meta_out) {
    if (frag_len != hdr->frag_len) return -1;
    if ((hdr->flags & RAF_WIRE_F_START) != 0u) {
        if (hdr->total_len > sizeof(ctx->buf)) return -2;
        ctx->stream_id = hdr->stream_id;
        ctx->seq = hdr->seq;
        ctx->expected_crc32 = hdr->payload_crc32;
        ctx->total_len = hdr->total_len;
        ctx->filled = 0u;
        ctx->packet_count = 0u;
        ctx->msg_type = hdr->msg_type;
        ctx->active = 1u;
    }
    if (!ctx->active) return -3;
    if (ctx->stream_id != hdr->stream_id || ctx->seq != hdr->seq) return -4;
    if (hdr->frag_off != ctx->filled) return -5;
    if (ctx->filled + frag_len > ctx->total_len) return -6;
    memcpy(ctx->buf + ctx->filled, frag_payload, frag_len);
    ctx->filled += (raf_u32)frag_len;
    ctx->packet_count++;
    if ((hdr->flags & RAF_WIRE_F_END) == 0u) return 0;
    if (ctx->filled != ctx->total_len) return -7;
    if (out_cap < ctx->total_len) return -8;
    memcpy(out_msg, ctx->buf, ctx->total_len);
    *out_msg_bytes = ctx->total_len;
    if (meta_out) {
        memset(meta_out, 0, sizeof(*meta_out));
        meta_out->seq = ctx->seq;
        meta_out->stream_id = ctx->stream_id;
        meta_out->payload_len = ctx->total_len;
        meta_out->payload_crc32 = ctx->expected_crc32;
        meta_out->packet_count = (raf_u16)ctx->packet_count;
        meta_out->msg_type = ctx->msg_type;
        meta_out->frame_bytes = ctx->total_len;
    }
    ctx->active = 0u;
    return 1;
}

raf_u32 raf_cache_stress_round(raf_u8 *buf, raf_size_t n, raf_u32 cycle, raf_u32 seed) {
    static const raf_size_t strides[] = {64u, 96u, 128u, 160u, 192u, 256u, 320u, 384u, 512u};
    raf_size_t stride = strides[cycle % (sizeof(strides) / sizeof(strides[0]))];
    raf_u32 acc = seed ^ (cycle * 0x9e3779b9u);
    for (raf_size_t pass = 0; pass < 3u; ++pass) {
        for (raf_size_t i = (cycle * 17u + pass * 13u) % stride; i < n; i += stride) {
            acc ^= buf[i];
            buf[i] ^= (raf_u8)(acc + i + pass);
            acc = raf_rotl32(acc + buf[i] + (raf_u32)i, 5u);
        }
    }
    return acc;
}

void raf_fault_policy_init(RafFaultPolicy *fp, int enabled, raf_u32 period, raf_u32 seed) {
    fp->enabled = enabled ? 1u : 0u;
    fp->period = period ? period : 13u;
    fp->seed = seed;
}

RafFaultKind raf_fault_pick(const RafFaultPolicy *fp, raf_u32 seq, raf_u32 cycle, raf_u32 packet_count) {
    raf_u32 mix;
    if (!fp || !fp->enabled) return RAF_FAULT_NONE;
    if (((seq + 1u + cycle) % fp->period) != 0u) return RAF_FAULT_NONE;
    mix = (seq * 1103515245u) ^ (cycle * 12345u) ^ fp->seed ^ packet_count;
    switch ((mix >> 3) & 3u) {
        case 0u: return packet_count > 1u ? RAF_FAULT_DROP_FRAGMENT : RAF_FAULT_CORRUPT_PAYLOAD;
        case 1u: return RAF_FAULT_CORRUPT_HEADER;
        case 2u: return RAF_FAULT_CORRUPT_PAYLOAD;
        default: return packet_count > 1u ? RAF_FAULT_TRUNCATE_LAST : RAF_FAULT_CORRUPT_PAYLOAD;
    }
}

void raf_percentiles_init(RafPercentiles *pct, raf_u32 cap, raf_u32 *ns_buf, raf_u32 *cyc_buf) {
    memset(pct, 0, sizeof(*pct));
    pct->cap = cap;
    pct->ns_values = ns_buf;
    pct->cycle_values = cyc_buf;
}

void raf_percentiles_add(RafPercentiles *pct, raf_u32 ns, raf_u32 cycles) {
    if (pct->count >= pct->cap) return;
    pct->ns_values[pct->count] = ns;
    pct->cycle_values[pct->count] = cycles;
    pct->count++;
}

void raf_percentiles_finalize(RafPercentiles *pct) {
    if (pct->count == 0u) return;
    qsort(pct->ns_values, pct->count, sizeof(raf_u32), raf_u32_cmp);
    qsort(pct->cycle_values, pct->count, sizeof(raf_u32), raf_u32_cmp);
    pct->p50_ns = raf_percentile_from_sorted(pct->ns_values, pct->count, 0.50);
    pct->p90_ns = raf_percentile_from_sorted(pct->ns_values, pct->count, 0.90);
    pct->p99_ns = raf_percentile_from_sorted(pct->ns_values, pct->count, 0.99);
    pct->p999_ns = raf_percentile_from_sorted(pct->ns_values, pct->count, 0.999);
    pct->p50_cycles = raf_percentile_from_sorted(pct->cycle_values, pct->count, 0.50);
    pct->p90_cycles = raf_percentile_from_sorted(pct->cycle_values, pct->count, 0.90);
    pct->p99_cycles = raf_percentile_from_sorted(pct->cycle_values, pct->count, 0.99);
    pct->p999_cycles = raf_percentile_from_sorted(pct->cycle_values, pct->count, 0.999);
}

void raf_trace_open(RafTraceSink *sink, const char *csv_path, const char *trace_path, const char *bin_path) {
    FILE *csv = NULL;
    FILE *trace = NULL;
    FILE *bin = NULL;
    if (!sink) return;
    memset(sink, 0, sizeof(*sink));
    if (csv_path) {
        csv = fopen(csv_path, "wb");
        sink->csv = csv;
        if (csv) {
            fprintf(csv, "cycle,seq,stream_id,path,status,crc_mode,fault,packet_count,msg_type,payload_len,frame_bytes,crc32,fold,latency_ns,latency_cycles\n");
        }
    }
    if (trace_path) {
        trace = fopen(trace_path, "wb");
        sink->trace = trace;
        if (trace) {
            fprintf(trace, "# raf pipeline v7 trace\n");
        }
    }
    if (bin_path) {
        bin = fopen(bin_path, "wb");
        sink->bin = bin;
    }
}

void raf_trace_close(RafTraceSink *sink) {
    if (!sink) return;
    if (sink->csv) fclose((FILE *)sink->csv);
    if (sink->trace) fclose((FILE *)sink->trace);
    if (sink->bin) fclose((FILE *)sink->bin);
    sink->csv = sink->trace = sink->bin = NULL;
}

void raf_trace_frame(RafTraceSink *sink, raf_u32 cycle, const RafDescriptor *desc, RafPath path, const char *status_text) {
    FILE *csv;
    FILE *trace;
    FILE *bin;
    if (!sink) return;
    csv = (FILE *)sink->csv;
    trace = (FILE *)sink->trace;
    bin = (FILE *)sink->bin;
    if (csv) {
        fprintf(csv, "%u,%u,%u,%s,%s,%s,%u,%u,%u,%u,%u,%08x,%08x,%u,%u\n",
                cycle, desc->seq, desc->stream_id, raf_path_name(path), status_text,
                raf_crc_mode_name((RafCrcMode)desc->crc_mode), desc->fault_kind,
                desc->packet_count, desc->msg_type, desc->payload_len, desc->frame_bytes,
                desc->payload_crc32, desc->fold, desc->latency_ns, desc->latency_cycles);
    }
    if (trace) {
        fprintf(trace, "[frame] cycle=%02u seq=%04u stream=%u path=%s status=%s crc=%s fault=%u pkts=%u type=%u len=%u frame=%u crc32=%08x fold=%08x lat_ns=%u lat_cyc=%u\n",
                cycle, desc->seq, desc->stream_id, raf_path_name(path), status_text,
                raf_crc_mode_name((RafCrcMode)desc->crc_mode), desc->fault_kind,
                desc->packet_count, desc->msg_type, desc->payload_len, desc->frame_bytes,
                desc->payload_crc32, desc->fold, desc->latency_ns, desc->latency_cycles);
    }
    if (bin) {
        RafTraceRecord rec;
        memset(&rec, 0, sizeof(rec));
        rec.magic = RAF_BIN_MAGIC;
        rec.version = RAF_WIRE_VERSION;
        rec.record_bytes = (raf_u16)sizeof(rec);
        rec.cycle = cycle;
        rec.seq = desc->seq;
        rec.stream_id = desc->stream_id;
        rec.payload_len = desc->payload_len;
        rec.frame_bytes = desc->frame_bytes;
        rec.payload_crc32 = desc->payload_crc32;
        rec.fold = desc->fold;
        rec.latency_ns = desc->latency_ns;
        rec.latency_cycles = desc->latency_cycles;
        rec.packet_count = desc->packet_count;
        rec.msg_type = desc->msg_type;
        rec.path = (raf_u8)path;
        rec.status = (raf_u8)desc->status;
        rec.fault_kind = desc->fault_kind;
        rec.crc_mode = desc->crc_mode;
        fwrite(&rec, sizeof(rec), 1u, bin);
    }
}

void raf_trace_event(RafTraceSink *sink, raf_u32 cycle, raf_u32 seq, const char *event_text, RafFaultKind fault) {
    FILE *trace;
    if (!sink) return;
    trace = (FILE *)sink->trace;
    if (trace) {
        fprintf(trace, "[event] cycle=%02u seq=%04u event=%s fault=%u\n", cycle, seq, event_text, (unsigned)fault);
    }
}

void raf_histogram_write_csv(const char *path, const RafPipelineStats *st) {
    static const char *labels[RAF_HIST_BUCKETS] = {
        "<=1us", "<=2us", "<=4us", "<=6us", "<=8us", "<=10us", "<=12us", "<=16us",
        "<=20us", "<=24us", "<=32us", "<=48us", "<=64us", "<=96us", "<=128us", ">128us"
    };
    FILE *fp = fopen(path, "wb");
    if (!fp) return;
    fprintf(fp, "bucket,count\n");
    for (raf_u32 i = 0; i < RAF_HIST_BUCKETS; ++i) {
        fprintf(fp, "%s,%u\n", labels[i], st->histogram_ns[i]);
    }
    fclose(fp);
}

static void raf_mutate_fragment(raf_u8 *hdr_bytes, raf_u8 *frag, raf_size_t frag_len,
                                const RafWireHeader *hdr, RafFaultKind fk) {
    (void)hdr;
    if (fk == RAF_FAULT_CORRUPT_HEADER && sizeof(RafWireHeader) > 12u) {
        hdr_bytes[8] ^= 0x01u;
        return;
    }
    if (fk == RAF_FAULT_CORRUPT_PAYLOAD && frag_len > 0u) {
        frag[frag_len / 2u] ^= 0x5au;
    }
}

static void raf_fault_bump(RafPipelineStats *st, RafFaultKind fk) {
    if (fk == RAF_FAULT_NONE) return;
    st->fault_injected++;
    switch (fk) {
        case RAF_FAULT_DROP_FRAGMENT: st->fault_drop++; break;
        case RAF_FAULT_CORRUPT_HEADER: st->fault_header++; break;
        case RAF_FAULT_CORRUPT_PAYLOAD: st->fault_payload++; break;
        case RAF_FAULT_TRUNCATE_LAST: st->fault_truncate++; break;
        default: break;
    }
}

static void raf_descriptor_zero(RafDescriptor *d) { memset(d, 0, sizeof(*d)); }

const char *raf_path_name(RafPath path) {
    switch (path) {
        case RAF_PATH_ASM_SCALAR: return "asm-scalar";
        case RAF_PATH_ASM_NEON: return "asm-neon";
        case RAF_PATH_C:
        default: return "c";
    }
}

const char *raf_crc_mode_name(RafCrcMode mode) {
    switch (mode) {
        case RAF_CRC_MODE_HW: return "hw";
        case RAF_CRC_MODE_HYBRID: return "hybrid";
        case RAF_CRC_MODE_SW:
        default: return "sw";
    }
}

RafPipelineStats raf_run_pipeline(RafPath path, int verbose, RafTraceSink *sink,
                                  const RafFaultPolicy *fault_policy,
                                  int prefer_hw_counter, RafCrcMode crc_mode) {
    RafPipelineStats st;
    RafDescRing ring;
    RafReassemblyCtx reas;
    raf_u8 *stream = NULL;
    raf_u8 *stage = NULL;
    raf_u8 *cache = NULL;
    raf_u8 *assembled = NULL;
    raf_u32 *pct_ns = NULL;
    raf_u32 *pct_cyc = NULL;
    raf_size_t stream_bytes = 0u;
    raf_u32 total_messages = 0u;
    raf_u32 total_packets = 0u;
    raf_size_t cursor = 0u;

    memset(&st, 0, sizeof(st));
    raf_desc_ring_init(&ring);
    raf_reassembly_init(&reas);

    stream = (raf_u8 *)raf_aligned_alloc64(RAF_WORKSET_BYTES);
    stage = (raf_u8 *)raf_aligned_alloc64(RAF_MAX_PAYLOAD + 64u);
    cache = (raf_u8 *)raf_aligned_alloc64(1024u * 1024u);
    assembled = (raf_u8 *)raf_aligned_alloc64(RAF_MAX_PAYLOAD + 64u);
    pct_ns = (raf_u32 *)malloc(sizeof(raf_u32) * RAF_PERCENTILE_CAP);
    pct_cyc = (raf_u32 *)malloc(sizeof(raf_u32) * RAF_PERCENTILE_CAP);
    if (!stream || !stage || !cache || !assembled || !pct_ns || !pct_cyc) {
        st.verification_failures = 0xffffffffu;
        goto done;
    }

    raf_percentiles_init(&st.pct, RAF_PERCENTILE_CAP, pct_ns, pct_cyc);
    memset(stage, 0, RAF_MAX_PAYLOAD + 64u);
    raf_fill_pattern(cache, 1024u * 1024u, 0x13579bdfu);
    stream_bytes = raf_build_wire_stream(stream, RAF_WORKSET_BYTES, 0x2468ace1u, &total_messages, &total_packets);
    st.stream_mix = raf_crc32_update_sw_prefetch_unrolled(0u, stream, stream_bytes > 4096u ? 4096u : stream_bytes);

    for (raf_u32 cycle = 0; cycle < RAF_PIPELINE_CYCLES; ++cycle) {
        raf_u32 budget = raf_cycle_budget_bytes(cycle);
        raf_u32 spent = 0u;
        st.cache_mix ^= raf_cache_stress_round(cache, 1024u * 1024u, cycle, 0x10203040u ^ cycle);
        st.cache_stress_rounds++;
        st.cycles++;
        while (spent < budget && cursor + sizeof(RafWireHeader) <= stream_bytes) {
            RafWireHeader hdr;
            raf_size_t wire_bytes = 0u;
            raf_u8 hdr_local[sizeof(RafWireHeader)];
            raf_u8 frag_local[RAF_MAX_PAYLOAD + 16u];
            raf_u8 *packet = stream + cursor;
            RafFaultKind fk = RAF_FAULT_NONE;
            RafDescriptor desc;
            int parse_rc;
            raf_descriptor_zero(&desc);

            parse_rc = raf_parse_wire_header(packet, stream_bytes - cursor, &hdr, &wire_bytes);
            if (parse_rc != 0) {
                st.parser_errors++;
                st.verification_failures++;
                break;
            }
            if (spent + (raf_u32)wire_bytes > budget && spent > 0u) break;

            st.wire_packets_total++;
            fk = raf_fault_pick(fault_policy, hdr.seq, cycle, hdr.frag_len);
            raf_fault_bump(&st, fk);
            memcpy(hdr_local, packet, sizeof(RafWireHeader));
            memcpy(frag_local, packet + sizeof(RafWireHeader), hdr.frag_len);

            if (fk == RAF_FAULT_DROP_FRAGMENT) {
                st.wire_packets_dropped++;
                st.messages_dropped++;
                raf_reassembly_reset(&reas);
                raf_trace_event(sink, cycle, hdr.seq, "drop-fragment", fk);
                spent += (raf_u32)wire_bytes;
                cursor += wire_bytes;
                if (cursor >= stream_bytes) cursor = 0u;
                continue;
            }
            if (fk == RAF_FAULT_TRUNCATE_LAST && (hdr.flags & RAF_WIRE_F_END) && hdr.frag_len > 8u) {
                hdr.frag_len -= 8u;
                raf_write_le32(hdr_local + 24, hdr.frag_len);
                raf_write_le16(hdr_local + 10, 0u);
                raf_write_le16(hdr_local + 10, raf_crc16_ccitt(hdr_local, sizeof(RafWireHeader)));
                raf_trace_event(sink, cycle, hdr.seq, "truncate-last", fk);
            } else if (fk == RAF_FAULT_CORRUPT_HEADER || fk == RAF_FAULT_CORRUPT_PAYLOAD) {
                raf_mutate_fragment(hdr_local, frag_local, hdr.frag_len, &hdr, fk);
                if (fk == RAF_FAULT_CORRUPT_HEADER) {
                    /* leave CRC stale so parser catches it */
                }
            }

            parse_rc = raf_parse_wire_header(hdr_local, sizeof(RafWireHeader) + hdr.frag_len, &hdr, &wire_bytes);
            if (parse_rc != 0) {
                st.parser_errors++;
                st.messages_dropped++;
                raf_reassembly_reset(&reas);
                raf_trace_event(sink, cycle, hdr.seq, "parser-error", fk);
                spent += (raf_u32)(sizeof(RafWireHeader) + hdr.frag_len);
                cursor += wire_bytes ? wire_bytes : (sizeof(RafWireHeader) + hdr.frag_len);
                if (cursor >= stream_bytes) cursor = 0u;
                continue;
            }

            {
                raf_u32 assembled_bytes = 0u;
                int feed_rc = raf_reassembly_feed(&reas, &hdr, frag_local, hdr.frag_len,
                                                  assembled, RAF_MAX_PAYLOAD + 64u,
                                                  &assembled_bytes, &desc);
                if (feed_rc < 0) {
                    st.parser_errors++;
                    st.messages_dropped++;
                    raf_reassembly_reset(&reas);
                    raf_trace_event(sink, cycle, hdr.seq, "reassembly-error", fk);
                } else if (feed_rc == 1) {
                    RafLatencyStamp stamp;
                    raf_u32 calc_crc;
                    raf_u32 fold;
                    raf_u32 n_words = (assembled_bytes + 3u) / 4u;
                    memset(stage, 0, RAF_MAX_PAYLOAD + 64u);
                    desc.frame_bytes = assembled_bytes + desc.packet_count * (raf_u32)sizeof(RafWireHeader);
                    desc.fault_kind = (raf_u8)fk;
                    desc.crc_mode = (raf_u16)crc_mode;
                    raf_latency_stamp_begin(&stamp, prefer_hw_counter);
                    raf_copy_dispatch(path, (raf_u32 *)stage, (const raf_u32 *)assembled, n_words);
                    fold = raf_fold_dispatch(path, (const raf_u32 *)stage, n_words);
                    calc_crc = raf_crc32_update_hybrid(0u, stage, assembled_bytes, crc_mode, &st);
                    raf_latency_stamp_end(&stamp);
                    desc.fold = fold;
                    desc.payload_crc32 = calc_crc;
                    desc.latency_ns = raf_latency_ns_delta(&stamp);
                    desc.latency_cycles = raf_latency_cycle_delta32(&stamp);
                    desc.status = 0u;
                    st.counter_source = stamp.source;
                    st.messages_total++;
                    st.bytes_payload += assembled_bytes;
                    st.crc_mix ^= raf_rotl32(calc_crc + desc.seq, desc.seq & 31u);
                    st.fold_mix ^= raf_rotl32(fold ^ assembled_bytes, (desc.seq * 3u) & 31u);
                    raf_percentiles_add(&st.pct, desc.latency_ns, desc.latency_cycles);
                    st.histogram_ns[raf_hist_bucket_ns(desc.latency_ns)]++;
                    if (calc_crc != desc.payload_crc32) {
                        st.crc_errors++;
                    }
                    if (calc_crc != reas.expected_crc32) {
                        st.crc_errors++;
                        desc.status = 2u;
                        if (fk != RAF_FAULT_CORRUPT_PAYLOAD) st.verification_failures++;
                    } else {
                        st.messages_ok++;
                    }
                    if (memcmp(stage, assembled, assembled_bytes) != 0) {
                        st.verification_failures++;
                        desc.status = 3u;
                    }
                    if (desc.packet_count > 1u) st.fragmented_messages++;
                    if (raf_desc_ring_push(&ring, &desc) != 0) {
                        RafDescriptor out;
                        if (raf_desc_ring_pop(&ring, &out) == 0) st.descriptor_flushes++;
                        (void)raf_desc_ring_push(&ring, &desc);
                    }
                    if (ring.count > st.ring_highwater) st.ring_highwater = ring.count;
                    if ((desc.seq & 7u) == 7u) {
                        RafDescriptor out;
                        if (raf_desc_ring_pop(&ring, &out) == 0) st.descriptor_flushes++;
                    }
                    raf_trace_frame(sink, cycle, &desc, path,
                                    desc.status == 0u ? "ok" : (desc.status == 2u ? "crc-error" : "verify-error"));
                    st.trace_rows++;
                    if (verbose) {
                        fprintf(stdout,
                                "[pipeline] cycle=%02u seq=%04u stream=%u type=%u len=%u pkts=%u crc=%08x fold=%08x lat_ns=%u lat_cyc=%u mode=%s\n",
                                cycle, desc.seq, desc.stream_id, desc.msg_type, desc.payload_len,
                                desc.packet_count, desc.payload_crc32, desc.fold,
                                desc.latency_ns, desc.latency_cycles, raf_crc_mode_name((RafCrcMode)desc.crc_mode));
                    }
                }
            }
            spent += (raf_u32)wire_bytes;
            cursor += wire_bytes;
            if (cursor >= stream_bytes) cursor = 0u;
        }
    }

    while (ring.count != 0u) {
        RafDescriptor out;
        if (raf_desc_ring_pop(&ring, &out) == 0) st.descriptor_flushes++;
    }
    st.reassembly_resets = reas.resets;
    raf_percentiles_finalize(&st.pct);

done:
    raf_aligned_free64(stream);
    raf_aligned_free64(stage);
    raf_aligned_free64(cache);
    raf_aligned_free64(assembled);
    free(pct_ns);
    free(pct_cyc);
    (void)total_messages;
    (void)total_packets;
    return st;
}

int raf_selftest_pipeline(int verbose) {
    RafFaultPolicy clean;
    RafPipelineStats cst, ast;
    int ok = 1;
    raf_fault_policy_init(&clean, 0, 0u, 0u);
    cst = raf_run_pipeline(RAF_PATH_C, 0, NULL, &clean, 0, RAF_CRC_MODE_SW);
    ast = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0, NULL, &clean, 0, RAF_CRC_MODE_HYBRID);
    if (cst.messages_total != ast.messages_total || cst.messages_ok != ast.messages_ok) ok = 0;
    if (cst.bytes_payload != ast.bytes_payload) ok = 0;
    if (cst.crc_mix != ast.crc_mix || cst.fold_mix != ast.fold_mix) ok = 0;
    if (cst.cache_mix != ast.cache_mix || cst.stream_mix != ast.stream_mix) ok = 0;
    if (cst.verification_failures != 0u || ast.verification_failures != 0u) ok = 0;
    if (cst.pct.p50_ns == 0u || ast.pct.p50_ns == 0u) ok = 0;
    if (verbose) {
        fprintf(stdout, "[selftest] c:   msgs=%u ok=%u bytes=%llu crc_mix=%08x fold_mix=%08x fail=%u p50=%u p90=%u p99=%u p999=%u\n",
                cst.messages_total, cst.messages_ok, (unsigned long long)cst.bytes_payload,
                cst.crc_mix, cst.fold_mix, cst.verification_failures,
                cst.pct.p50_ns, cst.pct.p90_ns, cst.pct.p99_ns, cst.pct.p999_ns);
        fprintf(stdout, "[selftest] asm: msgs=%u ok=%u bytes=%llu crc_mix=%08x fold_mix=%08x fail=%u p50=%u p90=%u p99=%u p999=%u\n",
                ast.messages_total, ast.messages_ok, (unsigned long long)ast.bytes_payload,
                ast.crc_mix, ast.fold_mix, ast.verification_failures,
                ast.pct.p50_ns, ast.pct.p90_ns, ast.pct.p99_ns, ast.pct.p999_ns);
        fprintf(stdout, "[selftest] result=%s\n", ok ? "OK" : "FAIL");
    }
    return ok ? 0 : 1;
}

void raf_print_stats(const char *tag, const RafPipelineStats *st, raf_u64 elapsed_ns) {
    FILE *fp = stdout;
    double mib = (double)st->bytes_payload / (1024.0 * 1024.0);
    double sec = elapsed_ns ? ((double)elapsed_ns / 1e9) : 0.0;
    double mibps = sec > 0.0 ? mib / sec : 0.0;
    fprintf(fp, "[%s] cycles=%u wire_pkts=%u dropped_pkts=%u msgs=%u ok=%u dropped=%u parser_err=%u crc_err=%u\n",
            tag, st->cycles, st->wire_packets_total, st->wire_packets_dropped,
            st->messages_total, st->messages_ok, st->messages_dropped, st->parser_errors, st->crc_errors);
    fprintf(fp, "[%s] bytes_payload=%llu ring_highwater=%u cache_rounds=%u flushes=%u fail=%u fragmented=%u reas_resets=%u\n",
            tag, (unsigned long long)st->bytes_payload, st->ring_highwater, st->cache_stress_rounds,
            st->descriptor_flushes, st->verification_failures, st->fragmented_messages, st->reassembly_resets);
    fprintf(fp, "[%s] faults=%u(drop=%u hdr=%u payload=%u trunc=%u) crc_hw_used=%u fallback=%u crc_sw_bytes=%llu crc_hw_bytes=%llu\n",
            tag, st->fault_injected, st->fault_drop, st->fault_header, st->fault_payload, st->fault_truncate,
            st->crc_hw_used, st->crc_hw_fallbacks,
            (unsigned long long)st->crc_sw_bytes, (unsigned long long)st->crc_hw_bytes);
    fprintf(fp, "[%s] crc_mix=%08x fold_mix=%08x cache_mix=%08x stream_mix=%08x counter=%s rows=%u\n",
            tag, st->crc_mix, st->fold_mix, st->cache_mix, st->stream_mix,
            raf_counter_source_name(st->counter_source), st->trace_rows);
    fprintf(fp, "[%s] p50_ns=%u p90_ns=%u p99_ns=%u p999_ns=%u p50_cyc=%u p90_cyc=%u p99_cyc=%u p999_cyc=%u\n",
            tag, st->pct.p50_ns, st->pct.p90_ns, st->pct.p99_ns, st->pct.p999_ns,
            st->pct.p50_cycles, st->pct.p90_cycles, st->pct.p99_cycles, st->pct.p999_cycles);
    fprintf(fp, "[%s] hist_ns=%u|%u|%u|%u|%u|%u|%u|%u|%u|%u|%u|%u|%u|%u|%u|%u\n",
            tag,
            st->histogram_ns[0], st->histogram_ns[1], st->histogram_ns[2], st->histogram_ns[3],
            st->histogram_ns[4], st->histogram_ns[5], st->histogram_ns[6], st->histogram_ns[7],
            st->histogram_ns[8], st->histogram_ns[9], st->histogram_ns[10], st->histogram_ns[11],
            st->histogram_ns[12], st->histogram_ns[13], st->histogram_ns[14], st->histogram_ns[15]);
    if (elapsed_ns) {
        fprintf(fp, "[%s] elapsed_ns=%llu throughput_mib_s=%.2f\n",
                tag, (unsigned long long)elapsed_ns, mibps);
    }
}
