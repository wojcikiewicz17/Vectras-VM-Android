# RAF Pipeline v7 — ARM32 frame parser, CRC híbrido e telemetria pesada

Projeto C/ASM para **Linux ARM32 / ARMv7-A** com foco em um pipeline mais próximo de uso real:

- parser de frame com **header estilo protocolo de enlace/aplicação**
- **reassembly fragmentado** por `stream_id + seq + frag_off`
- **fault injection** determinístico
- CRC32 em modo **SW otimizado** ou **híbrido SW/HW**
- cópia/fold em **C / ASM scalar / NEON opcional**
- telemetria pesada com **p50/p90/p99/p999**, **histograma** e **export binário de trace**

## O que mudou em relação à v6

### Parser mais próximo do protocolo real
A wire header agora carrega:
- `sof`
- `hdr_len`
- `version`
- `msg_type`
- `flags` (`START`, `END`, `URGENT`, `CRC_PRESENT`)
- `header_crc16`
- `stream_id`
- `seq`
- `frag_off`
- `frag_len`
- `total_len`
- `payload_crc32`
- `ts_tag`

Isso aproxima o fluxo de um protocolo embarcado/telemetria/stream onde o pipeline precisa validar integridade de header, offset de fragmento, comprimento total e reassembly coerente.

### CRC híbrido SW/HW + prefetch + unroll
- **SW**: tabela CRC32 + loop unrolled + prefetch
- **HW**: hook opcional para targets com suporte real
- **HYBRID**: tenta HW em blocos úteis; quando indisponível, cai para SW e contabiliza fallback

No host atual, o caminho híbrido **faz fallback para SW**, e isso é registrado nas estatísticas.

### Telemetria pesada
- export **CSV** por frame
- export **log textual**
- export **binário** (`RafTraceRecord` fixo)
- percentis: **p50 / p90 / p99 / p999**
- histograma de latência em ns (`hist_*.csv`)

## Build
```bash
make
make test
make bench
make export
make fault
make target
make arm32_objcheck
```

## Saídas
- `out/trace_host.csv`
- `out/trace_host.log`
- `out/trace_host.bin`
- `out/hist_host.csv`
- `out/fault_trace.csv`
- `out/fault_trace.log`
- `out/fault_trace.bin`
- `out/fault_hist.csv`
- `out/target_trace.csv`
- `out/target_trace.log`
- `out/target_trace.bin`
- `out/target_hist.csv`

## Observação importante
No host x86_64 deste ambiente, o caminho “ASM” usa **stubs em C** para validar o pipeline. A parte ARM32 real foi validada por:
- montagem
- geração de objeto
- disassembly
- checagem de API freestanding

Ou seja: o pipeline está pronto e coerente, mas o ganho real de ASM/NEON e o uso real de contador de hardware ainda precisam de execução em **hardware ARM32 nativo**.
