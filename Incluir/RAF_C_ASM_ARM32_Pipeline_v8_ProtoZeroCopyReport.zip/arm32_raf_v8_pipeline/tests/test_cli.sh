#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
make test
make export
make report
make fault
