# RAF Pipeline v8 — protocolo realista + zero-copy + backpressure + pós-processador

Esta v8 introduz:

- **perfil de protocolo mais próximo de frame real**: `session_id`, `channel_id`, `qos`, `ack_seq`, `window`, `app_tag`, `ttl_ticks`
- **zero-copy no fast path** para mensagens de um único fragmento sem mutação
- **copy-once** apenas quando há reassembly fragmentado
- **ring SPSC lock-free** para handoff de descritores
- **backpressure** por high-water mark
- **TTL em ticks** como temporizador grosseiro de custo quase zero
- **pós-processador** que lê o `.bin` e emite relatório automático

## Comandos

```bash
make
make test
make bench
make export
make fault
make target
make report
make arm32_objcheck
```

## Observação sobre TTL

`ttl_ticks` pode ser usado como **timer de custo quase zero** quando ele é carregado junto no frame e interpretado como **janela máxima em ciclos do pipeline**.

Ele **não substitui** um relógio preciso. Serve bem para:

- descartar mensagens velhas sob backpressure
- orçamento de entrega grosseiro
- validade relativa entre estágios

Ele **não serve sozinho** para:

- timestamp absoluto
- SLA fino em microssegundos
- latência precisa entre nós sem relógio de referência
