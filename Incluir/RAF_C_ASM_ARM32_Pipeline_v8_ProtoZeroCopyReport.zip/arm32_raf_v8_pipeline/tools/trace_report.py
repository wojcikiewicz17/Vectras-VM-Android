#!/usr/bin/env python3
import argparse, csv, json, math, os, struct

FMT = '<IHHIIIIIIIIIIHBBBBH HBBHH'
# normalize spaces for struct
FMT = FMT.replace(' ', '')
SIZE = struct.calcsize(FMT)
STATUS = {
    0: 'ok',
    2: 'crc-error',
    3: 'verify-error',
    4: 'bp-drop',
    5: 'ttl-drop',
}


def percentile(vals, p):
    if not vals:
        return 0
    vals = sorted(vals)
    idx = int(round((len(vals)-1) * p))
    idx = max(0, min(idx, len(vals)-1))
    return vals[idx]


def load_records(path):
    recs = []
    with open(path, 'rb') as f:
        while True:
            chunk = f.read(SIZE)
            if not chunk:
                break
            if len(chunk) != SIZE:
                raise SystemExit(f'trace truncado: {len(chunk)} bytes restantes')
            tup = struct.unpack(FMT, chunk)
            recs.append({
                'magic': tup[0], 'version': tup[1], 'record_bytes': tup[2], 'cycle': tup[3], 'seq': tup[4],
                'stream_id': tup[5], 'session_id': tup[6], 'payload_len': tup[7], 'frame_bytes': tup[8],
                'payload_crc32': tup[9], 'fold': tup[10], 'latency_ns': tup[11], 'latency_cycles': tup[12],
                'packet_count': max(1, min(4, tup[13])), 'msg_type': tup[14], 'path': tup[15], 'status': tup[16],
                'fault_kind': tup[17], 'crc_mode': tup[18], 'channel_id': tup[19], 'qos': tup[20],
                'ttl_ticks': tup[21], 'queue_depth': tup[22], 'bp_flags': tup[23],
            })
    return recs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--bin', required=True)
    ap.add_argument('--out-md', required=True)
    ap.add_argument('--out-json', required=True)
    args = ap.parse_args()

    recs = load_records(args.bin)
    lat = [r['latency_ns'] for r in recs if r['status'] == 0]
    qd = [r['queue_depth'] for r in recs]
    summary = {
        'records': len(recs),
        'ok': sum(1 for r in recs if r['status'] == 0),
        'crc_error': sum(1 for r in recs if r['status'] == 2),
        'verify_error': sum(1 for r in recs if r['status'] == 3),
        'bp_drop': sum(1 for r in recs if r['status'] == 4),
        'ttl_drop': sum(1 for r in recs if r['status'] == 5),
        'max_queue_depth': max(qd) if qd else 0,
        'p50_ns': percentile(lat, 0.50),
        'p90_ns': percentile(lat, 0.90),
        'p99_ns': percentile(lat, 0.99),
        'p999_ns': percentile(lat, 0.999),
        'avg_payload': int(sum(r['payload_len'] for r in recs) / len(recs)) if recs else 0,
        'avg_packets': round(sum(r['packet_count'] for r in recs) / len(recs), 2) if recs else 0,
        'ttl_hints': sum(1 for r in recs if r['ttl_ticks'] > 0),
        'urgent_or_qos2plus': sum(1 for r in recs if r['qos'] >= 2),
    }
    os.makedirs(os.path.dirname(args.out_md), exist_ok=True)
    with open(args.out_json, 'w') as f:
        json.dump(summary, f, indent=2)
    md = []
    md.append('# Relatório automático de trace v8')
    md.append('')
    md.append('| Métrica | Valor |')
    md.append('|---|---:|')
    for k in ['records','ok','crc_error','verify_error','bp_drop','ttl_drop','max_queue_depth','p50_ns','p90_ns','p99_ns','p999_ns','avg_payload','avg_packets','ttl_hints','urgent_or_qos2plus']:
        md.append(f'| {k} | {summary[k]} |')
    md.append('')
    md.append('## Observações')
    md.append('- `ttl_ticks` funciona como orçamento temporal **grosseiro** por ciclos do pipeline, não como relógio preciso.')
    md.append('- `bp_drop` indica queda por backpressure/high-water.')
    md.append('- `ttl_drop` indica expiração por janela de entrega baseada em ticks.')
    with open(args.out_md, 'w') as f:
        f.write('\n'.join(md) + '\n')
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
