#include "raf_pipeline.h"

int raf_api_check(void) {
    RafWireHeader h;
    RafDescriptor d;
    RafPipelineStats st;
    RafFaultPolicy fp;
    RafTraceSink sink;
    raf_fault_policy_init(&fp, 0, 0u, 0u);
    raf_desc_ring_init((RafDescRing *)&st);
    raf_reassembly_init((RafReassemblyCtx *)&d);
    raf_trace_open(&sink, 0, 0, 0);
    raf_trace_close(&sink);
    return (int)(h.hdr_len + d.payload_len + st.cycles + fp.period);
}
