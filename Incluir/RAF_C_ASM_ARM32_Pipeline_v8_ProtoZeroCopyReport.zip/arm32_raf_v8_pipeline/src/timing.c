#include "raf_pipeline.h"

#include <time.h>

static raf_u64 raf_ns_now64_local(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return ((raf_u64)ts.tv_sec * 1000000000ull) + (raf_u64)ts.tv_nsec;
}

#if defined(__arm__) && !defined(__aarch64__)
static raf_u64 raf_read_pmccntr(void) {
#if defined(RAF_ARM32_USE_PMCCNTR)
    raf_u32 lo;
    __asm__ volatile("mrc p15, 0, %0, c9, c13, 0" : "=r"(lo));
    return (raf_u64)lo;
#else
    return 0ull;
#endif
}

static raf_u64 raf_read_generic_timer(void) {
#if defined(RAF_ARM32_USE_GENERIC_TIMER)
    raf_u32 lo, hi;
    __asm__ volatile("mrrc p15, 1, %0, %1, c14" : "=r"(lo), "=r"(hi));
    return ((raf_u64)hi << 32) | lo;
#else
    return 0ull;
#endif
}
#endif

void raf_latency_stamp_begin(RafLatencyStamp *stamp, int prefer_hw) {
    stamp->ns_start = raf_ns_now64_local();
    stamp->cyc_start = stamp->ns_start;
    stamp->source = RAF_COUNTER_HOST_CLOCK;
#if defined(__arm__) && !defined(__aarch64__)
    if (prefer_hw) {
#if defined(RAF_ARM32_USE_PMCCNTR)
        stamp->cyc_start = raf_read_pmccntr();
        stamp->source = RAF_COUNTER_ARM_PMCCNTR;
#elif defined(RAF_ARM32_USE_GENERIC_TIMER)
        stamp->cyc_start = raf_read_generic_timer();
        stamp->source = RAF_COUNTER_ARM_GENERIC_TIMER;
#endif
    }
#else
    (void)prefer_hw;
#endif
}

void raf_latency_stamp_end(RafLatencyStamp *stamp) {
    stamp->ns_stop = raf_ns_now64_local();
    stamp->cyc_stop = stamp->ns_stop;
#if defined(__arm__) && !defined(__aarch64__)
    if (stamp->source == RAF_COUNTER_ARM_PMCCNTR) {
#if defined(RAF_ARM32_USE_PMCCNTR)
        stamp->cyc_stop = raf_read_pmccntr();
#endif
    } else if (stamp->source == RAF_COUNTER_ARM_GENERIC_TIMER) {
#if defined(RAF_ARM32_USE_GENERIC_TIMER)
        stamp->cyc_stop = raf_read_generic_timer();
#endif
    }
#endif
}

raf_u32 raf_latency_ns_delta(const RafLatencyStamp *stamp) {
    raf_u64 delta = stamp->ns_stop - stamp->ns_start;
    return (raf_u32)(delta > 0xffffffffull ? 0xffffffffu : delta);
}

raf_u32 raf_latency_cycle_delta32(const RafLatencyStamp *stamp) {
    raf_u64 delta = stamp->cyc_stop - stamp->cyc_start;
    return (raf_u32)(delta > 0xffffffffull ? 0xffffffffu : delta);
}

const char *raf_counter_source_name(RafCounterSource src) {
    switch (src) {
        case RAF_COUNTER_ARM_PMCCNTR: return "arm-pmccntr";
        case RAF_COUNTER_ARM_GENERIC_TIMER: return "arm-generic-timer";
        case RAF_COUNTER_HOST_CLOCK:
        default: return "host-clock";
    }
}
