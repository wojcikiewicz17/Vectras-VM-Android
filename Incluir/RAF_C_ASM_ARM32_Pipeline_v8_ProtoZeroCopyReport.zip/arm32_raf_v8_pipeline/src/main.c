#include "raf_pipeline.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

static raf_u64 ns_now64(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return ((raf_u64)ts.tv_sec * 1000000000ull) + (raf_u64)ts.tv_nsec;
}

static void usage(const char *argv0) {
    fprintf(stderr,
            "usage: %s [run|bench|selftest|export|fault|target]\n"
            "  run      : pipeline asm-scalar + crc hybrid + zero-copy path\n"
            "  bench    : compara C x ASM e mostra p50/p90/p99/p999\n"
            "  selftest : valida C x ASM sem faults\n"
            "  export   : gera csv/log/bin e histograma\n"
            "  fault    : roda com fault injection + reassembly fragmentado\n"
            "  target   : tenta usar contador de hardware\n",
            argv0);
}

int main(int argc, char **argv) {
    RafFaultPolicy clean, faults;
    raf_fault_policy_init(&clean, 0, 0u, 0u);
    raf_fault_policy_init(&faults, 1, 11u, 0x5a5aa55au);

    if (argc <= 1 || strcmp(argv[1], "run") == 0) {
        RafPipelineStats st = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0, NULL, &clean, 0, RAF_CRC_MODE_HYBRID);
        raf_print_stats("run", &st, 0ull);
        return st.verification_failures ? 1 : 0;
    }
    if (strcmp(argv[1], "selftest") == 0) {
        return raf_selftest_pipeline(1);
    }
    if (strcmp(argv[1], "bench") == 0) {
        raf_u64 t0, t1;
        RafPipelineStats cst, ast;
        t0 = ns_now64();
        cst = raf_run_pipeline(RAF_PATH_C, 0, NULL, &clean, 0, RAF_CRC_MODE_SW);
        t1 = ns_now64();
        raf_print_stats("bench-c", &cst, t1 - t0);
        t0 = ns_now64();
        ast = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0, NULL, &clean, 0, RAF_CRC_MODE_HYBRID);
        t1 = ns_now64();
        raf_print_stats("bench-asm", &ast, t1 - t0);
        return 0;
    }
    if (strcmp(argv[1], "export") == 0) {
        const char *csv = argc > 2 ? argv[2] : "out/trace_host.csv";
        const char *log = argc > 3 ? argv[3] : "out/trace_host.log";
        const char *bin = argc > 4 ? argv[4] : "out/trace_host.bin";
        const char *hist = argc > 5 ? argv[5] : "out/hist_host.csv";
        RafTraceSink sink;
        RafPipelineStats st;
        raf_trace_open(&sink, csv, log, bin);
        st = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0, &sink, &clean, 0, RAF_CRC_MODE_HYBRID);
        raf_trace_close(&sink);
        raf_histogram_write_csv(hist, &st);
        raf_print_stats("export", &st, 0ull);
        return st.verification_failures ? 1 : 0;
    }
    if (strcmp(argv[1], "fault") == 0) {
        const char *csv = argc > 2 ? argv[2] : "out/fault_trace.csv";
        const char *log = argc > 3 ? argv[3] : "out/fault_trace.log";
        const char *bin = argc > 4 ? argv[4] : "out/fault_trace.bin";
        const char *hist = argc > 5 ? argv[5] : "out/fault_hist.csv";
        RafTraceSink sink;
        RafPipelineStats st;
        raf_trace_open(&sink, csv, log, bin);
        st = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0, &sink, &faults, 0, RAF_CRC_MODE_HYBRID);
        raf_trace_close(&sink);
        raf_histogram_write_csv(hist, &st);
        raf_print_stats("fault", &st, 0ull);
        return 0;
    }
    if (strcmp(argv[1], "target") == 0) {
        RafTraceSink sink;
        RafPipelineStats st;
        raf_trace_open(&sink, "out/target_trace.csv", "out/target_trace.log", "out/target_trace.bin");
        st = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0, &sink, &clean, 1, RAF_CRC_MODE_HYBRID);
        raf_trace_close(&sink);
        raf_histogram_write_csv("out/target_hist.csv", &st);
        raf_print_stats("target", &st, 0ull);
        return 0;
    }
    usage(argv[0]);
    return 2;
}
