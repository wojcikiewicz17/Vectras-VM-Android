#include "raf_pipeline.h"

raf_u32 raf_fold_words_asm(const raf_u32 *p, raf_u32 n_words) {
    return raf_fold_words_c(p, n_words);
}

void raf_copy_words_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words) {
    raf_copy_words_c(dst, src, n_words);
}

void raf_copy_words_neon_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words) {
    raf_copy_words_c(dst, src, n_words);
}
