# Modo alvo v8

A v8 preserva os hooks de contador/timer:
- `RAF_ARM32_USE_PMCCNTR`
- `RAF_ARM32_USE_GENERIC_TIMER`

No host, o fallback continua sendo `host-clock`.

## Uso esperado no alvo
- PMCCNTR: melhor para ciclos CPU quando disponível/liberado
- Generic timer: melhor para relógio monotônico de hardware
- TTL: usar como **janela de expiração**, não como cronômetro fino
