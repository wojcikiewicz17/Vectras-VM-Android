# Notas técnicas v8

## O que mudou
- Header mais próximo de protocolo real: `session_id`, `channel_id`, `qos`, `ttl_ticks`, `ack_seq`, `window`, `app_tag`
- Fast path zero-copy para frame unitário sem mutação
- Copy-once para mensagens fragmentadas em reassembly
- Ring SPSC lock-free de descritores
- Backpressure por high-water mark com descarte de baixa prioridade
- TTL em ticks como orçamento temporal grosseiro
- Pós-processador do trace binário gerando relatório automático

## Observação de honestidade técnica
Sem os campos reais do seu frame, esta v8 implementa um **perfil realista placeholder**. A arquitetura já está pronta para receber o protocolo real com troca de layout do header e regras do parser.

## TTL como timer de custo quase zero
Sim, **como janela de validade relativa**. Não substitui contador de hardware nem relógio de alta precisão. Serve para:
- descarte por envelhecimento
- prazo relativo entre estágios
- backpressure com expiração barata

Não serve para:
- timestamp absoluto
- SLA fino em microssegundos
- comparação entre máquinas sem base comum
