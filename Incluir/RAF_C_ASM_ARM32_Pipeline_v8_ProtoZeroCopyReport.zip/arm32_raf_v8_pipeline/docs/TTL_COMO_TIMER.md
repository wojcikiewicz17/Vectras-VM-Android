# TTL como timer de custo quase zero

## Resposta curta
Sim, **como orçamento temporal grosseiro**.

## Quando funciona
- pipeline em ciclos discretos
- validade relativa (`expira em N ciclos`)
- descarte sob fila / backpressure
- sistemas em que o frame já carrega TTL naturalmente

## Quando não funciona
- sincronismo preciso
- medição absoluta de latência
- métricas finas em microssegundos
- comparação confiável entre máquinas sem relógio comum

## Regra prática
Use TTL para **eligibilidade/expiração**, não para cronômetro fino.
