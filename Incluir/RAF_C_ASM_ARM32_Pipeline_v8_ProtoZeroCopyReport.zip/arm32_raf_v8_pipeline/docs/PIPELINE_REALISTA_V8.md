# Pipeline realista v8

Perfil placeholder pronto para receber campos reais do seu frame.

Campos adicionados no header:
- `session_id`
- `channel_id`
- `qos`
- `ttl_ticks`
- `ack_seq`
- `window`
- `app_tag`

Estratégia:
- frame único -> zero-copy direto do wire buffer
- fragmentado -> reassembly + copy-once para slot de pool
- ring SPSC lock-free -> handoff de descritores
- backpressure -> queda de baixa prioridade em high-water
- TTL -> expiração grosseira por ciclo do pipeline
