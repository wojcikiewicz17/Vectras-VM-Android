# Relatório automático de trace v8

| Métrica | Valor |
|---|---:|
| records | 2746 |
| ok | 33 |
| crc_error | 0 |
| verify_error | 0 |
| bp_drop | 2398 |
| ttl_drop | 315 |
| max_queue_depth | 128 |
| p50_ns | 2395 |
| p90_ns | 4504 |
| p99_ns | 12502 |
| p999_ns | 12502 |
| avg_payload | 823 |
| avg_packets | 3.14 |
| ttl_hints | 2746 |
| urgent_or_qos2plus | 1200 |

## Observações
- `ttl_ticks` funciona como orçamento temporal **grosseiro** por ciclos do pipeline, não como relógio preciso.
- `bp_drop` indica queda por backpressure/high-water.
- `ttl_drop` indica expiração por janela de entrega baseada em ticks.
