make
make test
make bench
make export
make fault
make target
make report
make arm32_objcheck
