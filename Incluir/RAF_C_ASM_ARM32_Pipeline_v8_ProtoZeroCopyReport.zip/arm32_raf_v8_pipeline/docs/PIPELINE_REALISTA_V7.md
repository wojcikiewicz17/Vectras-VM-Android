# Pipeline realista v7

Fluxo modelado:
1. geração de mensagens lógicas (`msg_type`, `stream_id`, `seq`)
2. fragmentação em wire packets
3. serialização de header com `header_crc16`
4. parsing do wire packet
5. fault injection opcional no pacote/fragmento
6. reassembly por `stream_id + seq + frag_off`
7. cópia/fold do payload
8. CRC final em modo SW/HW/HYBRID
9. emissão de descritor
10. export de telemetria (csv/log/bin/hist)

Isso aproxima melhor o pipeline de cenários como:
- transporte de frames em firmware
- link proprietário de telemetria
- parser de protocolo embarcado
- canal com perda/truncamento/corrupção de fragmento
