# Perfil de protocolo placeholder v8

Campos implementados:
- `sof`
- `hdr_len`
- `version`
- `msg_type`
- `flags`
- `header_crc16`
- `stream_id`
- `seq`
- `frag_off`
- `frag_len`
- `total_len`
- `payload_crc32`
- `ts_tag`
- `channel_id`
- `qos`
- `ttl_ticks`
- `session_id`
- `ack_seq`
- `window`
- `app_tag`

## Como adaptar para o frame real
Substituir ou remapear:
- largura dos campos
- endianess
- campos opcionais/extensão
- regras de fragmentação
- semântica de QoS/TTL/ACK/window
