RAFAELIA EXECUÇÃO — PACOTE COMPLETO

Conteúdo do ZIP
1. 01_Rafaelia_Execucao_Saneada.docx / .md
   - saneamento conceitual do manifesto original
   - separação entre engenharia verificável, ciência formal, hipótese autoral e linguagem expressiva

2. 02_Paper_Base_Completo.docx / .md
   - paper base completo, em linguagem acadêmica
   - inclui título, resumo, problema, objetivos, hipóteses, método, métricas, protocolo experimental, limites e referências-base

3. 03_Hipoteses_Metricas_Experimentos.xlsx
   - planilha com hipóteses, variáveis, métricas, experimentos, riscos e cronograma

4. 04_Matriz_de_Afirmacoes.csv
   - classificação de afirmações por status epistemológico

5. 05_Estrutura_Tese_Dissertacao.docx / .md
   - estrutura pronta para dissertação ou tese
   - capítulos, perguntas de pesquisa, métodos, anexos e trilha de execução

6. scripts_python/
   - protótipos e baselines para simulação, robustez, falsificabilidade e inferência de intenção de código
   - todos em Python puro, sem dependência de internet

7. requirements.txt
   - dependências mínimas sugeridas

8. COMO_EXECUTAR.txt
   - passos rápidos para rodar os scripts

Observações
- Este pacote é tecnicamente sério e academicamente utilizável.
- Não reivindica validação empírica final de hipóteses abertas.
- O pacote converte as ideias em estrutura pesquisável, falsificável e organizada.

Status final
- Gap anterior “paper completo” => FECHADO
- Gap anterior “scripts Python” => FECHADO
- Gap anterior “versão tese/dissertação” => FECHADO
