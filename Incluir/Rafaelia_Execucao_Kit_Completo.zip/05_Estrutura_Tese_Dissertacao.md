# Estrutura de tese ou dissertação

## Título-base
**Semântica Dinâmica, Fronteiras de Ruído e Inferência de Intenção: fundamentos, modelos e protocolos experimentais**

## 1. Introdução
- apresentação do problema;
- delimitação do escopo;
- justificativa teórica e técnica;
- contribuição esperada;
- perguntas de pesquisa;
- visão geral da estrutura do trabalho.

## 2. Perguntas de pesquisa
1. Como modelar interpretação como dinâmica de estado?
2. Como distinguir ruído destrutivo de ruído informativo?
3. Como medir estabilidade semântica sob variação contextual?
4. Em que medida a intenção funcional de artefatos computacionais pode ser inferida?
5. Quais limites epistemológicos impedem extrapolações indevidas?

## 3. Objetivos

### 3.1 Objetivo geral
Formalizar e avaliar um framework para coerência, ruído e intenção em sistemas simbólicos e computacionais.

### 3.2 Objetivos específicos
- construir taxonomia epistemológica;
- definir modelo mínimo;
- criar métricas e protocolos de teste;
- rodar simulações e baselines;
- avaliar limites e validade externa;
- organizar resultados em estrutura acadêmica completa.

## 4. Capítulo 1 — Ontologia e classificação epistemológica
Conteúdo:
- diferença entre fato, modelo, hipótese e linguagem expressiva;
- critérios de admissibilidade metodológica;
- riscos de mistura entre domínios.

Entrega:
- quadro taxonômico central do trabalho.

## 5. Capítulo 2 — Fundamentação matemática e computacional
Conteúdo:
- sistemas dinâmicos;
- teoria da informação;
- estados latentes;
- robustez, sensibilidade e estabilidade;
- análise estática e dinâmica de software.

Entrega:
- base formal para os experimentos.

## 6. Capítulo 3 — Modelo de semântica dinâmica
Conteúdo:
- definição de variáveis;
- equações de atualização;
- noção de atrator, fronteira e colapso;
- parâmetros e cenários de simulação.

Entrega:
- modelo mínimo reproduzível.

## 7. Capítulo 4 — Ruído informativo e estabilidade contextual
Conteúdo:
- desenho experimental;
- níveis de ruído;
- métricas de coerência;
- análise de regimes.

Entrega:
- resultados sobre fronteiras e estabilidade.

## 8. Capítulo 5 — Inferência de intenção em software
Conteúdo:
- corpus;
- rotulagem;
- features estáticas e dinâmicas;
- baseline heurístico;
- classificação e avaliação.

Entrega:
- experimento aplicado de maior concretude técnica.

## 9. Capítulo 6 — Validação, falsificação e limites
Conteúdo:
- repetibilidade;
- análise de sensibilidade;
- ameaça à validade;
- limites epistemológicos;
- riscos de overfitting conceitual.

Entrega:
- seção crítica do trabalho.

## 10. Capítulo 7 — Discussão
Conteúdo:
- o que foi sustentado;
- o que falhou;
- o que permaneceu inconclusivo;
- implicações para pesquisa futura.

## 11. Conclusão
- síntese das contribuições;
- resposta às perguntas de pesquisa;
- agenda futura.

## 12. Anexos sugeridos
- matriz de afirmações;
- planilha de hipóteses e métricas;
- scripts Python;
- logs de execução;
- tabelas complementares;
- guia de replicação.

## 13. Cronograma sugerido

### Mês 1–2
- revisão e saneamento conceitual;
- definição do corpus e das métricas.

### Mês 3–4
- formalização matemática;
- implementação dos scripts base.

### Mês 5–6
- experimentos de estabilidade e ruído.

### Mês 7–8
- experimento de inferência de intenção em código.

### Mês 9
- análise estatística e validação.

### Mês 10–12
- redação, revisão e consolidação final.

## 14. Requisitos mínimos para defesa séria
- variáveis definidas;
- protocolo reproduzível;
- métricas claras;
- resultados negativos incluídos;
- limites assumidos explicitamente;
- separação rígida entre hipótese e evidência.