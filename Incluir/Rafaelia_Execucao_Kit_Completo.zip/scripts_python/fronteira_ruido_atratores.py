"""
Detecção de fronteira entre ruído e colapso.
Gera um relatório simples para localizar a faixa intermediária em que a entropia
sobe sem que a estabilidade colapse totalmente.
"""
from __future__ import annotations
import argparse
import json
import math
import numpy as np
from sim_semantica_dinamica import simulate


def shannon_entropy(values: np.ndarray, bins: int = 12) -> float:
    hist, _ = np.histogram(values, bins=bins, density=True)
    hist = hist[hist > 0]
    probs = hist / hist.sum()
    return float(-(probs * np.log2(probs)).sum())


def boundary_scan(noises: list[float], seeds: int, steps: int) -> dict:
    rows = []
    for noise in noises:
        outputs = []
        stabilities = []
        collapses = []
        for seed in range(seeds):
            res = simulate(steps=steps, noise_scale=noise, seed=seed)
            outputs.extend(h["output"] for h in res["history_tail"])
            stabilities.append(res["metrics"]["stability_index"])
            collapses.append(res["metrics"]["collapse_rate"])
        out_arr = np.array(outputs, dtype=float)
        rows.append(
            {
                "noise": noise,
                "entropy": shannon_entropy(out_arr),
                "mean_stability": float(np.mean(stabilities)),
                "mean_collapse": float(np.mean(collapses)),
            }
        )
    return {"scan": rows}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=int, default=30)
    parser.add_argument("--steps", type=int, default=200)
    args = parser.parse_args()
    noises = [round(x, 2) for x in np.linspace(0.01, 0.45, 12)]
    print(json.dumps(boundary_scan(noises, args.seeds, args.steps), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()