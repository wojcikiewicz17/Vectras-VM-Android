"""
Baseline heurístico para inferência de intenção em código-fonte.
Não substitui análise estática profunda; serve como ponto de partida reproduzível.

Uso:
    python inferencia_intencao_codigo_baseline.py caminho/para/arquivo.c
    python inferencia_intencao_codigo_baseline.py pasta_com_codigos/
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from collections import Counter

PATTERNS = {
    "io": [r"\bprintf\b", r"\bfprintf\b", r"\bread\b", r"\bwrite\b", r"\bfopen\b", r"\bfclose\b"],
    "rede": [r"\bsocket\b", r"\bconnect\b", r"\bbind\b", r"\blisten\b", r"\bsend\b", r"\brecv\b"],
    "parsing": [r"\bstrtok\b", r"\bsscanf\b", r"\batoi\b", r"\bstrtol\b", r"\bjson\b", r"\bparse\b"],
    "criptografia": [r"\bsha\d+\b", r"\baes\b", r"\bcrypt\b", r"\bhash\b", r"\bencrypt\b", r"\bdecrypt\b"],
    "persistencia": [r"\bsql\b", r"\bsqlite\b", r"\bcommit\b", r"\brollback\b", r"\bquery\b", r"\binsert\b"],
    "controle_fluxo": [r"\bswitch\b", r"\bcase\b", r"\bgoto\b", r"\bwhile\b", r"\bfor\b", r"\bif\b"],
}

VALID_EXTS = {".c", ".h", ".cpp", ".hpp", ".cc", ".java", ".py", ".rs", ".go", ".asm", ".s"}


def scan_text(text: str) -> dict:
    scores = Counter()
    lowered = text.lower()
    for label, patterns in PATTERNS.items():
        for pat in patterns:
            scores[label] += len(re.findall(pat, lowered))
    total = sum(scores.values()) or 1
    ranking = [
        {"label": label, "score": int(score), "ratio": score / total}
        for label, score in scores.most_common()
    ]
    return {"predicted_label": ranking[0]["label"] if ranking else "indefinido", "ranking": ranking}


def read_targets(path: Path) -> list[Path]:
    if path.is_file():
        return [path]
    return [p for p in path.rglob("*") if p.suffix.lower() in VALID_EXTS and p.is_file()]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=str)
    args = parser.parse_args()
    target = Path(args.path)

    outputs = []
    for file_path in read_targets(target):
        try:
            text = file_path.read_text(encoding="utf-8", errors="ignore")
        except Exception as exc:
            outputs.append({"file": str(file_path), "error": str(exc)})
            continue
        result = scan_text(text)
        outputs.append({"file": str(file_path), **result})

    print(json.dumps(outputs, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()