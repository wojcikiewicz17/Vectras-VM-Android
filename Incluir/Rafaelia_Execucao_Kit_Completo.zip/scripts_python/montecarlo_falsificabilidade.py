"""
Varredura Monte Carlo para falsificabilidade.
Objetivo: verificar se o modelo reage de forma diferenciada entre regimes de ruído.
"""
from __future__ import annotations
import argparse
import json
import numpy as np
from sim_semantica_dinamica import simulate


def sweep(noise_levels: list[float], repetitions: int, steps: int) -> dict:
    results = []
    for noise in noise_levels:
        collapse_rates = []
        stability = []
        for seed in range(repetitions):
            out = simulate(steps=steps, noise_scale=noise, seed=seed)
            collapse_rates.append(out["metrics"]["collapse_rate"])
            stability.append(out["metrics"]["stability_index"])
        results.append(
            {
                "noise": noise,
                "collapse_rate_mean": float(np.mean(collapse_rates)),
                "collapse_rate_std": float(np.std(collapse_rates)),
                "stability_mean": float(np.mean(stability)),
                "stability_std": float(np.std(stability)),
            }
        )
    return {"results": results}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repetitions", type=int, default=50)
    parser.add_argument("--steps", type=int, default=250)
    args = parser.parse_args()

    noise_levels = [0.01, 0.05, 0.10, 0.15, 0.20, 0.30, 0.40]
    result = sweep(noise_levels, repetitions=args.repetitions, steps=args.steps)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()