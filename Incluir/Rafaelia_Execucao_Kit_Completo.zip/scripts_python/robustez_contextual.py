"""
Experimento de robustez contextual.
Gera versões perturbadas de um vetor de estado e mede a persistência relativa.
"""
from __future__ import annotations
import argparse
import json
import numpy as np


def perturb(vec: np.ndarray, scale: float, rng: np.random.Generator) -> np.ndarray:
    return np.clip(vec + rng.normal(0.0, scale, size=vec.shape[0]), -1.0, 1.0)


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    if denom == 0:
        return 0.0
    return float(np.dot(a, b) / denom)


def robustness(trials: int, dim: int, scale: float, seed: int) -> dict:
    rng = np.random.default_rng(seed)
    base = rng.normal(0.0, 1.0, size=dim)
    sims = []
    for _ in range(trials):
        p = perturb(base, scale, rng)
        sims.append(cosine(base, p))
    sims_arr = np.array(sims, dtype=float)
    return {
        "params": {"trials": trials, "dim": dim, "scale": scale, "seed": seed},
        "metrics": {
            "mean_cosine_similarity": float(sims_arr.mean()),
            "std_cosine_similarity": float(sims_arr.std()),
            "robustness_index": float(np.quantile(sims_arr, 0.1)),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", type=int, default=1000)
    parser.add_argument("--dim", type=int, default=32)
    parser.add_argument("--scale", type=float, default=0.10)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    print(json.dumps(robustness(args.trials, args.dim, args.scale, args.seed), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()