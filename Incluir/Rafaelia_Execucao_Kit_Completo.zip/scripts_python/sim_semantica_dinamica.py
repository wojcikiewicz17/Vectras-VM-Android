"""
Simulação mínima de semântica dinâmica.
Modelo acadêmico-operacional para testar estabilidade, coerência e colapso
sob perturbação contextual.

Uso:
    python sim_semantica_dinamica.py --steps 200 --noise 0.15 --seed 7
"""
from __future__ import annotations
import argparse
import json
from dataclasses import dataclass, asdict
import numpy as np


@dataclass
class State:
    I: float  # direção interpretativa
    E: float  # erro observável
    P: float  # tensão interna
    V: float  # persistência operacional
    G: float  # limite estrutural
    O: float  # distância observador-fenômeno


def clip01(x: float) -> float:
    return float(np.clip(x, -1.0, 1.0))


def update_state(s: State, noise_scale: float, rng: np.random.Generator) -> tuple[State, float]:
    n = rng.normal(0.0, noise_scale, size=6)
    S_next = np.tanh(
        0.90 * s.I
        + 0.35 * s.E
        + 0.50 * s.P
        + 0.25 * s.G
        + 0.55 * s.V
        - 0.40 * s.O
        + n[0]
    )

    I2 = clip01(0.72 * s.I + 0.18 * S_next - 0.10 * s.E + n[1])
    E2 = clip01(0.40 * abs(S_next - s.I) + 0.45 * s.E + abs(n[2]) * 0.25)
    P2 = clip01(0.65 * s.P + 0.20 * (s.V - s.G) + n[3])
    V2 = clip01(0.78 * s.V + 0.10 * S_next - 0.08 * s.E + n[4])
    G2 = clip01(0.84 * s.G + 0.05 * abs(P2) + n[5])
    O2 = clip01(0.80 * s.O + 0.15 * E2 - 0.08 * V2)

    return State(I2, E2, P2, V2, G2, O2), float(S_next)


def simulate(steps: int, noise_scale: float, seed: int) -> dict:
    rng = np.random.default_rng(seed)
    state = State(
        I=float(rng.uniform(-0.2, 0.2)),
        E=float(rng.uniform(0.0, 0.2)),
        P=float(rng.uniform(-0.3, 0.3)),
        V=float(rng.uniform(0.2, 0.6)),
        G=float(rng.uniform(0.2, 0.5)),
        O=float(rng.uniform(0.1, 0.4)),
    )

    history = []
    outputs = []
    collapses = 0

    for _ in range(steps):
        prev = np.array(list(asdict(state).values()), dtype=float)
        state, out = update_state(state, noise_scale, rng)
        cur = np.array(list(asdict(state).values()), dtype=float)
        dist = float(np.linalg.norm(cur - prev))
        if dist > 0.55:
            collapses += 1
        history.append(asdict(state) | {"delta_norm": dist, "output": out})
        outputs.append(out)

    outputs_arr = np.array(outputs, dtype=float)
    delta_arr = np.array([r["delta_norm"] for r in history], dtype=float)

    return {
        "params": {"steps": steps, "noise_scale": noise_scale, "seed": seed},
        "metrics": {
            "mean_output": float(outputs_arr.mean()),
            "std_output": float(outputs_arr.std()),
            "mean_delta": float(delta_arr.mean()),
            "collapse_rate": float(collapses / max(1, steps)),
            "stability_index": float(1.0 / (1.0 + delta_arr.mean())),
        },
        "history_tail": history[-10:],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=200)
    parser.add_argument("--noise", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()

    result = simulate(args.steps, args.noise, args.seed)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()