#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
make
python3 tools/make_random_ckpt.py demo_random.bin
./build/tinygpt --ckpt demo_random.bin --gen 80 --temp 0.9 --topk 32 "Ola mundo"
