# tinygpt_c_asm

Projeto compacto, no espírito **nanoGPT**, mas com foco em **C + ASM (x86_64)**.

## O que é

Este repositório entrega um **Transformer decoder-only mínimo** com:

- embeddings de token e posição
- multi-head causal self-attention
- MLP com GELU
- layer norm
- geração autoregressiva
- kernel de produto escalar em **assembly x86_64**
- checkpoint binário simples

## O que não é

Não é um clone completo do nanoGPT.

Ele foi pensado como um **esqueleto didático e hackável** para:

- estudar forward pass de GPT em C
- mover hot paths para assembly
- experimentar formatos de checkpoint simples
- servir de base para treino/export depois

## Estrutura

```text
.
├── Makefile
├── README.md
├── examples/
├── src/
│   ├── dot_x86_64.s
│   ├── gpt.c
│   ├── gpt.h
│   └── main.c
└── tools/
    └── make_random_ckpt.py
```

## Compilar

```bash
make
```

Saída:

```bash
build/tinygpt
```

## Rodar sem checkpoint

Isso inicializa pesos randômicos em memória.

```bash
./build/tinygpt "Ola mundo"
```

## Gerar checkpoint randômico

```bash
python3 tools/make_random_ckpt.py demo_random.bin
```

Depois:

```bash
./build/tinygpt --ckpt demo_random.bin "Ola mundo"
```

## Opções úteis

```bash
./build/tinygpt --ckpt demo_random.bin --gen 128 --temp 0.9 --topk 32 --seed 123 "Era uma vez"
```

## Formato do checkpoint

Header binário:

- `magic` = `TGPT`
- `version`
- `GPTConfig`

Depois disso vêm os tensores em `float32`, em ordem fixa:

1. token embedding
2. positional embedding
3. pesos por camada
4. layer norm final
5. lm head (se não houver weight tying)

## Config default

- vocab: 256
- seq_len: 64
- layers: 2
- heads: 4
- d_model: 64
- d_ff: 256
- tied weights: sim

## Próximos passos naturais

- KV cache
- tokenizer BPE real
- treino/export a partir de Python
- AVX2/AVX-512 nos kernels
- quantização
- suporte a checkpoints treinados

## Observação importante

Com pesos randômicos, a geração será **ruído**. Isso é esperado.

O valor do projeto está em deixar pronta a espinha dorsal de um GPT mínimo em **C/ASM**, não em fingir que já existe um modelo treinado grande.
