#!/usr/bin/env python3
import argparse
import struct
import random
from pathlib import Path

MAGIC = 0x54475054
VERSION = 1


def rand_list(n, scale, rng):
    return [(rng.random() * 2.0 - 1.0) * scale for _ in range(n)]


def write_f32s(f, vals):
    f.write(struct.pack(f"<{len(vals)}f", *vals))


def main():
    ap = argparse.ArgumentParser(description="Gera um checkpoint randomico para o tinygpt_c_asm")
    ap.add_argument("out", nargs="?", default="demo_random.bin")
    ap.add_argument("--vocab", type=int, default=256)
    ap.add_argument("--seq-len", type=int, default=64)
    ap.add_argument("--layers", type=int, default=2)
    ap.add_argument("--heads", type=int, default=4)
    ap.add_argument("--d-model", type=int, default=64)
    ap.add_argument("--d-ff", type=int, default=256)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--untied", action="store_true")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    cfg = (
        args.vocab,
        args.seq_len,
        args.layers,
        args.heads,
        args.d_model,
        args.d_ff,
        0 if args.untied else 1,
    )

    out = Path(args.out)
    with out.open("wb") as f:
        header = struct.pack("<II7i", MAGIC, VERSION, *cfg)
        f.write(header)

        write_f32s(f, rand_list(args.vocab * args.d_model, 0.08, rng))
        write_f32s(f, rand_list(args.seq_len * args.d_model, 0.08, rng))
        for _ in range(args.layers):
            write_f32s(f, [1.0] * args.d_model)
            write_f32s(f, [0.0] * args.d_model)
            for _proj in range(4):
                write_f32s(f, rand_list(args.d_model * args.d_model, 0.04, rng))
                write_f32s(f, rand_list(args.d_model, 0.01, rng))
            write_f32s(f, [1.0] * args.d_model)
            write_f32s(f, [0.0] * args.d_model)
            write_f32s(f, rand_list(args.d_ff * args.d_model, 0.04, rng))
            write_f32s(f, rand_list(args.d_ff, 0.01, rng))
            write_f32s(f, rand_list(args.d_model * args.d_ff, 0.04, rng))
            write_f32s(f, rand_list(args.d_model, 0.01, rng))
        write_f32s(f, [1.0] * args.d_model)
        write_f32s(f, [0.0] * args.d_model)
        if args.untied:
            write_f32s(f, rand_list(args.vocab * args.d_model, 0.04, rng))

    print(f"checkpoint salvo em: {out}")


if __name__ == "__main__":
    main()
