#ifndef TINYGPT_GPT_H
#define TINYGPT_GPT_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int vocab_size;
    int seq_len;
    int n_layer;
    int n_head;
    int d_model;
    int d_ff;
    int tie_weights;
} GPTConfig;

typedef struct {
    float *ln1_g;
    float *ln1_b;
    float *wq;
    float *bq;
    float *wk;
    float *bk;
    float *wv;
    float *bv;
    float *wo;
    float *bo;
    float *ln2_g;
    float *ln2_b;
    float *fc1;
    float *b1;
    float *fc2;
    float *b2;
} GPTLayer;

typedef struct {
    GPTConfig cfg;
    float *tok_embed;
    float *pos_embed;
    GPTLayer *layers;
    float *ln_f_g;
    float *ln_f_b;
    float *lm_head;
} GPTModel;

typedef struct {
    int temperature_mode;
    float temperature;
    int top_k;
    uint64_t rng_state;
} Sampler;

float dot_f32_asm(const float *a, const float *b, int n);
float dot_f32_c(const float *a, const float *b, int n);

int gpt_default_config(GPTConfig *cfg);
int gpt_init_random(GPTModel *m, const GPTConfig *cfg, uint64_t seed);
int gpt_save_checkpoint(const char *path, const GPTModel *m);
int gpt_load_checkpoint(const char *path, GPTModel *m);
void gpt_free(GPTModel *m);

void sampler_init(Sampler *sampler, float temperature, int top_k, uint64_t seed);
int gpt_generate(const GPTModel *m,
                 const uint8_t *prompt,
                 int prompt_len,
                 int max_new_tokens,
                 Sampler *sampler,
                 uint8_t *out_tokens,
                 int out_capacity);

#ifdef __cplusplus
}
#endif

#endif
