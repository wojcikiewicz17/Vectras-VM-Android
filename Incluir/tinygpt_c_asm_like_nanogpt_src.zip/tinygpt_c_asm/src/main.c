#include "gpt.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void usage(const char *prog) {
    fprintf(stderr,
            "uso: %s [--ckpt arquivo.bin] [--gen N] [--temp T] [--topk K] [--seed S] [prompt]\n",
            prog);
}

int main(int argc, char **argv) {
    const char *ckpt = NULL;
    const char *prompt = "Ola";
    int gen_tokens = 96;
    float temperature = 0.8f;
    int top_k = 32;
    unsigned long long seed = 42ULL;

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--ckpt") == 0 && i + 1 < argc) {
            ckpt = argv[++i];
        } else if (strcmp(argv[i], "--gen") == 0 && i + 1 < argc) {
            gen_tokens = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--temp") == 0 && i + 1 < argc) {
            temperature = (float)atof(argv[++i]);
        } else if (strcmp(argv[i], "--topk") == 0 && i + 1 < argc) {
            top_k = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--seed") == 0 && i + 1 < argc) {
            seed = strtoull(argv[++i], NULL, 10);
        } else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            usage(argv[0]);
            return 0;
        } else {
            prompt = argv[i];
        }
    }

    GPTModel model;
    memset(&model, 0, sizeof(model));
    if (ckpt) {
        if (gpt_load_checkpoint(ckpt, &model) != 0) {
            fprintf(stderr, "falha ao carregar checkpoint: %s\n", ckpt);
            return 1;
        }
    } else {
        GPTConfig cfg;
        gpt_default_config(&cfg);
        if (gpt_init_random(&model, &cfg, seed) != 0) {
            fprintf(stderr, "falha ao inicializar modelo randomico\n");
            return 1;
        }
    }

    Sampler sampler;
    sampler_init(&sampler, temperature, top_k, seed);

    const int prompt_len = (int)strlen(prompt);
    const int cap = prompt_len + gen_tokens + 1;
    uint8_t *tokens = (uint8_t *)calloc((size_t)cap, sizeof(uint8_t));
    if (!tokens) {
        gpt_free(&model);
        return 1;
    }

    int n = gpt_generate(&model,
                         (const uint8_t *)prompt,
                         prompt_len,
                         gen_tokens,
                         &sampler,
                         tokens,
                         cap - 1);
    if (n < 0) {
        fprintf(stderr, "falha na geracao\n");
        free(tokens);
        gpt_free(&model);
        return 1;
    }
    tokens[n] = 0;
    for (int i = 0; i < n; ++i) {
        unsigned char c = tokens[i];
        if ((c >= 32 && c <= 126) || c == '\n' || c == '\t' || c == '\r') fputc((int)c, stdout);
        else fputc('.', stdout);
    }
    fputc('\n', stdout);

    free(tokens);
    gpt_free(&model);
    return 0;
}
