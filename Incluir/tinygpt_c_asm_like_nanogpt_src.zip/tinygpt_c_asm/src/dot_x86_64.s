.intel_syntax noprefix
.text
.global dot_f32_asm
.type dot_f32_asm, @function
# float dot_f32_asm(const float* a, const float* b, int n)
# SysV: rdi=a, rsi=b, edx=n, return xmm0
dot_f32_asm:
    push rbp
    mov rbp, rsp
    pxor xmm0, xmm0
    xor ecx, ecx
    mov eax, edx
    shr eax, 2
    jz .tail
.loop4:
    movups xmm1, XMMWORD PTR [rdi + rcx*4]
    movups xmm2, XMMWORD PTR [rsi + rcx*4]
    mulps xmm1, xmm2
    addps xmm0, xmm1
    add ecx, 4
    dec eax
    jnz .loop4
.tail:
    movaps xmm3, xmm0
    movhlps xmm3, xmm0
    addps xmm0, xmm3
    movaps xmm3, xmm0
    shufps xmm3, xmm3, 0x55
    addss xmm0, xmm3

    mov eax, edx
    and eax, 3
    jz .done
.tail_loop:
    movss xmm1, DWORD PTR [rdi + rcx*4]
    movss xmm2, DWORD PTR [rsi + rcx*4]
    mulss xmm1, xmm2
    addss xmm0, xmm1
    inc ecx
    dec eax
    jnz .tail_loop
.done:
    pop rbp
    ret
.size dot_f32_asm, .-dot_f32_asm
