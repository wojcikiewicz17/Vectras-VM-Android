#include "gpt.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TGPT_MAGIC 0x54475054u /* TGPT */
#define TGPT_VERSION 1u

static float rand_f32(uint64_t *state) {
    *state = (*state * 6364136223846793005ULL) + 1ULL;
    uint32_t x = (uint32_t)(*state >> 32);
    return ((float)x / (float)UINT32_MAX) * 2.0f - 1.0f;
}

static void *xcalloc(size_t n, size_t size) {
    void *p = calloc(n, size);
    if (!p) {
        fprintf(stderr, "out of memory\n");
    }
    return p;
}

static int alloc_layer(GPTLayer *layer, const GPTConfig *cfg) {
    const int dm = cfg->d_model;
    const int dff = cfg->d_ff;
    layer->ln1_g = (float *)xcalloc(dm, sizeof(float));
    layer->ln1_b = (float *)xcalloc(dm, sizeof(float));
    layer->wq = (float *)xcalloc((size_t)dm * dm, sizeof(float));
    layer->bq = (float *)xcalloc(dm, sizeof(float));
    layer->wk = (float *)xcalloc((size_t)dm * dm, sizeof(float));
    layer->bk = (float *)xcalloc(dm, sizeof(float));
    layer->wv = (float *)xcalloc((size_t)dm * dm, sizeof(float));
    layer->bv = (float *)xcalloc(dm, sizeof(float));
    layer->wo = (float *)xcalloc((size_t)dm * dm, sizeof(float));
    layer->bo = (float *)xcalloc(dm, sizeof(float));
    layer->ln2_g = (float *)xcalloc(dm, sizeof(float));
    layer->ln2_b = (float *)xcalloc(dm, sizeof(float));
    layer->fc1 = (float *)xcalloc((size_t)dff * dm, sizeof(float));
    layer->b1 = (float *)xcalloc(dff, sizeof(float));
    layer->fc2 = (float *)xcalloc((size_t)dm * dff, sizeof(float));
    layer->b2 = (float *)xcalloc(dm, sizeof(float));
    return layer->b2 ? 0 : -1;
}

static void free_layer(GPTLayer *layer) {
    free(layer->ln1_g); free(layer->ln1_b);
    free(layer->wq); free(layer->bq);
    free(layer->wk); free(layer->bk);
    free(layer->wv); free(layer->bv);
    free(layer->wo); free(layer->bo);
    free(layer->ln2_g); free(layer->ln2_b);
    free(layer->fc1); free(layer->b1);
    free(layer->fc2); free(layer->b2);
    memset(layer, 0, sizeof(*layer));
}

int gpt_default_config(GPTConfig *cfg) {
    if (!cfg) return -1;
    cfg->vocab_size = 256;
    cfg->seq_len = 64;
    cfg->n_layer = 2;
    cfg->n_head = 4;
    cfg->d_model = 64;
    cfg->d_ff = 256;
    cfg->tie_weights = 1;
    return 0;
}

static void init_norm(float *g, float *b, int n) {
    for (int i = 0; i < n; ++i) {
        g[i] = 1.0f;
        b[i] = 0.0f;
    }
}

static void init_matrix(float *w, int rows, int cols, uint64_t *seed, float scale) {
    const size_t n = (size_t)rows * cols;
    for (size_t i = 0; i < n; ++i) {
        w[i] = rand_f32(seed) * scale;
    }
}

static void init_vector(float *v, int n, uint64_t *seed, float scale) {
    for (int i = 0; i < n; ++i) {
        v[i] = rand_f32(seed) * scale;
    }
}

int gpt_init_random(GPTModel *m, const GPTConfig *cfg, uint64_t seed) {
    if (!m || !cfg) return -1;
    memset(m, 0, sizeof(*m));
    m->cfg = *cfg;
    const int dm = cfg->d_model;
    const int v = cfg->vocab_size;
    m->tok_embed = (float *)xcalloc((size_t)v * dm, sizeof(float));
    m->pos_embed = (float *)xcalloc((size_t)cfg->seq_len * dm, sizeof(float));
    m->layers = (GPTLayer *)xcalloc(cfg->n_layer, sizeof(GPTLayer));
    m->ln_f_g = (float *)xcalloc(dm, sizeof(float));
    m->ln_f_b = (float *)xcalloc(dm, sizeof(float));
    if (!m->tok_embed || !m->pos_embed || !m->layers || !m->ln_f_g || !m->ln_f_b) return -1;
    if (!cfg->tie_weights) {
        m->lm_head = (float *)xcalloc((size_t)v * dm, sizeof(float));
        if (!m->lm_head) return -1;
    }

    const float emb_scale = 0.08f;
    const float proj_scale = 0.04f;
    init_matrix(m->tok_embed, v, dm, &seed, emb_scale);
    init_matrix(m->pos_embed, cfg->seq_len, dm, &seed, emb_scale);
    init_norm(m->ln_f_g, m->ln_f_b, m->cfg.d_model);

    for (int l = 0; l < cfg->n_layer; ++l) {
        GPTLayer *ly = &m->layers[l];
        if (alloc_layer(ly, cfg) != 0) return -1;
        init_norm(ly->ln1_g, ly->ln1_b, dm);
        init_norm(ly->ln2_g, ly->ln2_b, dm);
        init_matrix(ly->wq, dm, dm, &seed, proj_scale);
        init_matrix(ly->wk, dm, dm, &seed, proj_scale);
        init_matrix(ly->wv, dm, dm, &seed, proj_scale);
        init_matrix(ly->wo, dm, dm, &seed, proj_scale);
        init_matrix(ly->fc1, cfg->d_ff, dm, &seed, proj_scale);
        init_matrix(ly->fc2, dm, cfg->d_ff, &seed, proj_scale);
        init_vector(ly->bq, dm, &seed, 0.01f);
        init_vector(ly->bk, dm, &seed, 0.01f);
        init_vector(ly->bv, dm, &seed, 0.01f);
        init_vector(ly->bo, dm, &seed, 0.01f);
        init_vector(ly->b1, cfg->d_ff, &seed, 0.01f);
        init_vector(ly->b2, dm, &seed, 0.01f);
    }

    if (m->lm_head) {
        init_matrix(m->lm_head, v, dm, &seed, proj_scale);
    }
    return 0;
}

void gpt_free(GPTModel *m) {
    if (!m) return;
    if (m->layers) {
        for (int l = 0; l < m->cfg.n_layer; ++l) {
            free_layer(&m->layers[l]);
        }
    }
    free(m->tok_embed);
    free(m->pos_embed);
    free(m->layers);
    free(m->ln_f_g);
    free(m->ln_f_b);
    free(m->lm_head);
    memset(m, 0, sizeof(*m));
}

typedef struct {
    uint32_t magic;
    uint32_t version;
    GPTConfig cfg;
} FileHeader;

static int write_array(FILE *f, const float *p, size_t n) {
    return fwrite(p, sizeof(float), n, f) == n ? 0 : -1;
}

static int read_array(FILE *f, float *p, size_t n) {
    return fread(p, sizeof(float), n, f) == n ? 0 : -1;
}

int gpt_save_checkpoint(const char *path, const GPTModel *m) {
    if (!path || !m) return -1;
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    FileHeader h;
    h.magic = TGPT_MAGIC;
    h.version = TGPT_VERSION;
    h.cfg = m->cfg;
    int rc = 0;
    if (fwrite(&h, sizeof(h), 1, f) != 1) rc = -1;
    if (!rc) rc = write_array(f, m->tok_embed, (size_t)m->cfg.vocab_size * m->cfg.d_model);
    if (!rc) rc = write_array(f, m->pos_embed, (size_t)m->cfg.seq_len * m->cfg.d_model);
    for (int l = 0; !rc && l < m->cfg.n_layer; ++l) {
        const GPTLayer *ly = &m->layers[l];
        rc |= write_array(f, ly->ln1_g, m->cfg.d_model);
        rc |= write_array(f, ly->ln1_b, m->cfg.d_model);
        rc |= write_array(f, ly->wq, (size_t)m->cfg.d_model * m->cfg.d_model);
        rc |= write_array(f, ly->bq, m->cfg.d_model);
        rc |= write_array(f, ly->wk, (size_t)m->cfg.d_model * m->cfg.d_model);
        rc |= write_array(f, ly->bk, m->cfg.d_model);
        rc |= write_array(f, ly->wv, (size_t)m->cfg.d_model * m->cfg.d_model);
        rc |= write_array(f, ly->bv, m->cfg.d_model);
        rc |= write_array(f, ly->wo, (size_t)m->cfg.d_model * m->cfg.d_model);
        rc |= write_array(f, ly->bo, m->cfg.d_model);
        rc |= write_array(f, ly->ln2_g, m->cfg.d_model);
        rc |= write_array(f, ly->ln2_b, m->cfg.d_model);
        rc |= write_array(f, ly->fc1, (size_t)m->cfg.d_ff * m->cfg.d_model);
        rc |= write_array(f, ly->b1, m->cfg.d_ff);
        rc |= write_array(f, ly->fc2, (size_t)m->cfg.d_model * m->cfg.d_ff);
        rc |= write_array(f, ly->b2, m->cfg.d_model);
    }
    if (!rc) rc = write_array(f, m->ln_f_g, m->cfg.d_model);
    if (!rc) rc = write_array(f, m->ln_f_b, m->cfg.d_model);
    if (!rc && !m->cfg.tie_weights) rc = write_array(f, m->lm_head, (size_t)m->cfg.vocab_size * m->cfg.d_model);
    fclose(f);
    return rc ? -1 : 0;
}

int gpt_load_checkpoint(const char *path, GPTModel *m) {
    if (!path || !m) return -1;
    FILE *f = fopen(path, "rb");
    if (!f) return -1;
    FileHeader h;
    if (fread(&h, sizeof(h), 1, f) != 1) {
        fclose(f);
        return -1;
    }
    if (h.magic != TGPT_MAGIC || h.version != TGPT_VERSION) {
        fclose(f);
        return -1;
    }
    if (gpt_init_random(m, &h.cfg, 1u) != 0) {
        fclose(f);
        return -1;
    }
    int rc = 0;
    rc |= read_array(f, m->tok_embed, (size_t)m->cfg.vocab_size * m->cfg.d_model);
    rc |= read_array(f, m->pos_embed, (size_t)m->cfg.seq_len * m->cfg.d_model);
    for (int l = 0; !rc && l < m->cfg.n_layer; ++l) {
        GPTLayer *ly = &m->layers[l];
        rc |= read_array(f, ly->ln1_g, m->cfg.d_model);
        rc |= read_array(f, ly->ln1_b, m->cfg.d_model);
        rc |= read_array(f, ly->wq, (size_t)m->cfg.d_model * m->cfg.d_model);
        rc |= read_array(f, ly->bq, m->cfg.d_model);
        rc |= read_array(f, ly->wk, (size_t)m->cfg.d_model * m->cfg.d_model);
        rc |= read_array(f, ly->bk, m->cfg.d_model);
        rc |= read_array(f, ly->wv, (size_t)m->cfg.d_model * m->cfg.d_model);
        rc |= read_array(f, ly->bv, m->cfg.d_model);
        rc |= read_array(f, ly->wo, (size_t)m->cfg.d_model * m->cfg.d_model);
        rc |= read_array(f, ly->bo, m->cfg.d_model);
        rc |= read_array(f, ly->ln2_g, m->cfg.d_model);
        rc |= read_array(f, ly->ln2_b, m->cfg.d_model);
        rc |= read_array(f, ly->fc1, (size_t)m->cfg.d_ff * m->cfg.d_model);
        rc |= read_array(f, ly->b1, m->cfg.d_ff);
        rc |= read_array(f, ly->fc2, (size_t)m->cfg.d_model * m->cfg.d_ff);
        rc |= read_array(f, ly->b2, m->cfg.d_model);
    }
    rc |= read_array(f, m->ln_f_g, m->cfg.d_model);
    rc |= read_array(f, m->ln_f_b, m->cfg.d_model);
    if (!rc && !m->cfg.tie_weights) rc |= read_array(f, m->lm_head, (size_t)m->cfg.vocab_size * m->cfg.d_model);
    fclose(f);
    if (rc) {
        gpt_free(m);
        return -1;
    }
    return 0;
}

float dot_f32_c(const float *a, const float *b, int n) {
    float s = 0.0f;
    for (int i = 0; i < n; ++i) s += a[i] * b[i];
    return s;
}

static void matvec(const float *W, const float *b, const float *x, float *y, int out_dim, int in_dim) {
    for (int o = 0; o < out_dim; ++o) {
        float v = b ? b[o] : 0.0f;
        v += dot_f32_asm(&W[(size_t)o * in_dim], x, in_dim);
        y[o] = v;
    }
}

static void layernorm(const float *x, float *y, const float *g, const float *b, int n) {
    float mean = 0.0f;
    float var = 0.0f;
    for (int i = 0; i < n; ++i) mean += x[i];
    mean /= (float)n;
    for (int i = 0; i < n; ++i) {
        const float d = x[i] - mean;
        var += d * d;
    }
    var /= (float)n;
    const float inv = 1.0f / sqrtf(var + 1e-5f);
    for (int i = 0; i < n; ++i) {
        y[i] = ((x[i] - mean) * inv) * g[i] + b[i];
    }
}

static float gelu_scalar(float x) {
    const float c = 0.044715f;
    const float s = 0.7978845608f;
    return 0.5f * x * (1.0f + tanhf(s * (x + c * x * x * x)));
}

static void softmax_inplace(float *x, int n) {
    float maxv = x[0];
    for (int i = 1; i < n; ++i) if (x[i] > maxv) maxv = x[i];
    float sum = 0.0f;
    for (int i = 0; i < n; ++i) {
        x[i] = expf(x[i] - maxv);
        sum += x[i];
    }
    if (sum <= 0.0f) return;
    const float inv = 1.0f / sum;
    for (int i = 0; i < n; ++i) x[i] *= inv;
}

static uint64_t splitmix64(uint64_t *x) {
    uint64_t z = (*x += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

static float rng_uniform01(uint64_t *state) {
    const uint64_t z = splitmix64(state);
    return (float)((z >> 11) * (1.0 / 9007199254740992.0));
}

void sampler_init(Sampler *sampler, float temperature, int top_k, uint64_t seed) {
    sampler->temperature_mode = (temperature > 0.0f && fabsf(temperature - 1.0f) > 1e-6f);
    sampler->temperature = temperature <= 0.0f ? 1.0f : temperature;
    sampler->top_k = top_k;
    sampler->rng_state = seed ? seed : 123456789ULL;
}

static int sample_from_logits(const float *logits, int n, Sampler *sampler) {
    int argmax = 0;
    for (int i = 1; i < n; ++i) if (logits[i] > logits[argmax]) argmax = i;
    if (!sampler || (!sampler->temperature_mode && sampler->top_k <= 1)) return argmax;

    float *tmp = (float *)malloc((size_t)n * sizeof(float));
    if (!tmp) return argmax;
    memcpy(tmp, logits, (size_t)n * sizeof(float));
    if (sampler->top_k > 0 && sampler->top_k < n) {
        for (int keep = 0; keep < sampler->top_k; ++keep) {
            int best = keep;
            for (int j = keep + 1; j < n; ++j) if (tmp[j] > tmp[best]) best = j;
            float tv = tmp[keep]; tmp[keep] = tmp[best]; tmp[best] = tv;
        }
        const float cutoff = tmp[sampler->top_k - 1];
        memcpy(tmp, logits, (size_t)n * sizeof(float));
        for (int i = 0; i < n; ++i) if (tmp[i] < cutoff) tmp[i] = -1e30f;
    }
    const float inv_temp = 1.0f / sampler->temperature;
    for (int i = 0; i < n; ++i) tmp[i] *= inv_temp;
    softmax_inplace(tmp, n);
    const float u = rng_uniform01(&sampler->rng_state);
    float cdf = 0.0f;
    int chosen = argmax;
    for (int i = 0; i < n; ++i) {
        cdf += tmp[i];
        if (u <= cdf) {
            chosen = i;
            break;
        }
    }
    free(tmp);
    return chosen;
}

static void forward_logits(const GPTModel *m, const uint8_t *tokens, int T, float *logits_out) {
    const GPTConfig *cfg = &m->cfg;
    const int dm = cfg->d_model;
    const int H = cfg->n_head;
    const int hs = dm / H;
    const int dff = cfg->d_ff;

    float *x = (float *)xcalloc((size_t)T * dm, sizeof(float));
    float *xn = (float *)xcalloc((size_t)T * dm, sizeof(float));
    float *q = (float *)xcalloc((size_t)T * dm, sizeof(float));
    float *k = (float *)xcalloc((size_t)T * dm, sizeof(float));
    float *v = (float *)xcalloc((size_t)T * dm, sizeof(float));
    float *ctx = (float *)xcalloc((size_t)T * dm, sizeof(float));
    float *att = (float *)xcalloc((size_t)T * T, sizeof(float));
    float *ff1 = (float *)xcalloc(dff, sizeof(float));
    float *ff2 = (float *)xcalloc(dm, sizeof(float));
    float *tmp = (float *)xcalloc(dm, sizeof(float));

    for (int t = 0; t < T; ++t) {
        const float *te = &m->tok_embed[(size_t)tokens[t] * dm];
        const float *pe = &m->pos_embed[(size_t)t * dm];
        for (int i = 0; i < dm; ++i) {
            x[(size_t)t * dm + i] = te[i] + pe[i];
        }
    }

    for (int l = 0; l < cfg->n_layer; ++l) {
        const GPTLayer *ly = &m->layers[l];
        for (int t = 0; t < T; ++t) {
            layernorm(&x[(size_t)t * dm], &xn[(size_t)t * dm], ly->ln1_g, ly->ln1_b, dm);
            matvec(ly->wq, ly->bq, &xn[(size_t)t * dm], &q[(size_t)t * dm], dm, dm);
            matvec(ly->wk, ly->bk, &xn[(size_t)t * dm], &k[(size_t)t * dm], dm, dm);
            matvec(ly->wv, ly->bv, &xn[(size_t)t * dm], &v[(size_t)t * dm], dm, dm);
        }

        memset(ctx, 0, (size_t)T * dm * sizeof(float));
        const float scale = 1.0f / sqrtf((float)hs);
        for (int h = 0; h < H; ++h) {
            for (int t = 0; t < T; ++t) {
                for (int tp = 0; tp <= t; ++tp) {
                    const float *qt = &q[(size_t)t * dm + h * hs];
                    const float *kt = &k[(size_t)tp * dm + h * hs];
                    att[(size_t)t * T + tp] = dot_f32_asm(qt, kt, hs) * scale;
                }
                for (int tp = t + 1; tp < T; ++tp) {
                    att[(size_t)t * T + tp] = -1e30f;
                }
                softmax_inplace(&att[(size_t)t * T], T);
                for (int i = 0; i < hs; ++i) {
                    float acc = 0.0f;
                    for (int tp = 0; tp < T; ++tp) {
                        acc += att[(size_t)t * T + tp] * v[(size_t)tp * dm + h * hs + i];
                    }
                    ctx[(size_t)t * dm + h * hs + i] = acc;
                }
            }
        }

        for (int t = 0; t < T; ++t) {
            matvec(ly->wo, ly->bo, &ctx[(size_t)t * dm], tmp, dm, dm);
            for (int i = 0; i < dm; ++i) x[(size_t)t * dm + i] += tmp[i];
        }

        for (int t = 0; t < T; ++t) {
            layernorm(&x[(size_t)t * dm], &xn[(size_t)t * dm], ly->ln2_g, ly->ln2_b, dm);
            matvec(ly->fc1, ly->b1, &xn[(size_t)t * dm], ff1, dff, dm);
            for (int i = 0; i < dff; ++i) ff1[i] = gelu_scalar(ff1[i]);
            matvec(ly->fc2, ly->b2, ff1, ff2, dm, dff);
            for (int i = 0; i < dm; ++i) x[(size_t)t * dm + i] += ff2[i];
        }
    }

    layernorm(&x[(size_t)(T - 1) * dm], tmp, m->ln_f_g, m->ln_f_b, dm);
    const float *lm = m->cfg.tie_weights ? m->tok_embed : m->lm_head;
    for (int tok = 0; tok < cfg->vocab_size; ++tok) {
        logits_out[tok] = dot_f32_asm(&lm[(size_t)tok * dm], tmp, dm);
    }

    free(x); free(xn); free(q); free(k); free(v); free(ctx); free(att); free(ff1); free(ff2); free(tmp);
}

int gpt_generate(const GPTModel *m,
                 const uint8_t *prompt,
                 int prompt_len,
                 int max_new_tokens,
                 Sampler *sampler,
                 uint8_t *out_tokens,
                 int out_capacity) {
    if (!m || !prompt || !out_tokens || out_capacity <= 0) return -1;
    int n = 0;
    for (int i = 0; i < prompt_len && n < out_capacity; ++i) out_tokens[n++] = prompt[i];
    float *logits = (float *)xcalloc(m->cfg.vocab_size, sizeof(float));
    if (!logits) return -1;
    for (int step = 0; step < max_new_tokens && n < out_capacity; ++step) {
        int T = n < m->cfg.seq_len ? n : m->cfg.seq_len;
        const uint8_t *window = &out_tokens[n - T];
        forward_logits(m, window, T, logits);
        int next = sample_from_logits(logits, m->cfg.vocab_size, sampler);
        out_tokens[n++] = (uint8_t)next;
    }
    free(logits);
    return n;
}
