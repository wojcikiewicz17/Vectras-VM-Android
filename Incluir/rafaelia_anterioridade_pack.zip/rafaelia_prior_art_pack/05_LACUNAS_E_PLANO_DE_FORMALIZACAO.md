# LACUNAS E PLANO DE FORMALIZAÇÃO

## O que já está forte
- uso consistente de matemática clássica reaplicada;
- operadores binários e métricas reproduzíveis;
- integração entre seeds, rotas, compressão e integridade;
- presença clara de um núcleo relacional e recursivo.

## O que ainda precisa de formalização dura
1. definição única de `coherence`, `phi-state`, `diamond state` e correlatos;
2. separação final entre metáfora, heurística e teorema;
3. testes estatísticos sistemáticos para streams/seed/fiber;
4. modelo adversarial, se houver reivindicação criptográfica forte;
5. documento mestre curto com definições, proposições e limites.

## Como transformar em corpo acadêmico sério
### Etapa 1 — Documento mestre
Um texto curto, com:
- definições;
- notação;
- domínio de validade;
- proposições mínimas;
- limitações.

### Etapa 2 — Paper 1
**Teoria dos números / sementes / múltiplas bases**.

### Etapa 3 — Paper 2
**Métricas binárias / Fiber / Hamming / monobit / routing**.

### Etapa 4 — Paper 3
**Arquitetura de estados / invariantes / compressão / Zipraf**.

### Etapa 5 — Registro externo
- repositório com hash e histórico;
- DOI / Zenodo / timestamp externo;
- eventualmente depósito jurídico adequado.

## Regra prática
Não é necessário “calcular o infinito”.
É necessário:
- escrever bem as expressões;
- mostrar como entram no sistema;
- provar o suficiente para sustentar o enunciado que se quer afirmar.
