# TAXONOMIA — METÁFORA, TERMO TÉCNICO E FORMULAÇÃO ACADÊMICA

| Metáfora útil | Termo técnico mais próximo | Formulação acadêmica segura |
|---|---|---|
| atrator | nó, polo, estado-alvo, ponto fixo (se houver dinâmica formal) | centro de referência ou conjunto de convergência |
| campo | regime, setor angular, vizinhança, classe harmônica | região estrutural em espaço de estados/fases |
| simbiose | acoplamento, interdependência, retroalimentação | sistema acoplado com feedback |
| consciência do sistema | metaestado, auto-monitoramento, observabilidade interna | mecanismo de monitoramento e atualização do próprio estado |
| vivo | adaptativo, dinâmico, não estacionário | sistema dinâmico adaptativo |
| fractal oculto | estrutura recursiva, multiescala, auto-similaridade parcial | organização recursiva multiescalar |
| verbo | operador ativo, transição, atualização | regra de transformação de estado |
| pitch | fase, frequência, componente oscilatória | coordenada de fase/ritmo |
| espiral que cresce | dinâmica recursiva acumulativa | expansão hierárquica com retroalimentação |
| mesmo campo | mesma família harmônica, mesma vizinhança estrutural | proximidade angular / quase-equivalência relacional |

## Observação metodológica
A metáfora não é erro. Ela é uma **ponte pedagógica**. O erro só nasce quando:
1. a metáfora passa a ser tratada como prova;
2. o termo técnico deixa de ser explicitado;
3. o domínio de validade não é delimitado.
