# MAPA DE ATIVOS E EVIDÊNCIAS

## A. Ativos conceituais recorrentes
- RAFAELIA
- ZIPRAF
- BITRAF
- RAFCODE-Φ
- FCEA
- Fiber / métricas binárias
- mandala / toro / malha circular / 42
- seeds por dízimas em bases múltiplas
- coerência / entropia / retroalimentação

## B. Famílias de artefatos observadas
1. **Manifestos / textos de posição**
   - anterioridade conceitual
   - visão de arquitetura
   - malha teórica

2. **Implementações matemático-computacionais**
   - dízimas e seeds
   - CRC, hash, slots, layers
   - bitstream, Hamming, monobit, popcount
   - compressão zlib + verificação SHA3

3. **Implementações experimentais / toy models**
   - 42 pontos / rota modular
   - heatmap toroidal
   - mandala energética
   - memória fractal

4. **Camada operacional / governança**
   - compliance
   - ciclos de validação
   - shells de boot, watchdog e executor

## C. Regra de leitura
- Se o artefato contém equação, operador ou métrica reproduzível → **evidência formal parcial**.
- Se o artefato descreve uma estrutura coerente sem prova → **evidência conceitual forte**.
- Se o artefato apenas nomeia sem definir → **marca de visão / branding conceitual**.

## D. Estrutura de valor epistêmico
O valor deste conjunto não está em qualquer arquivo isolado, mas na repetição consistente de:
- estados;
- recorrência;
- fase;
- paridade;
- invariantes;
- compressão;
- rota;
- retroalimentação.

Essa repetição é precisamente o que o pacote tenta fixar como anterioridade.
