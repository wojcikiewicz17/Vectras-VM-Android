#include "raf_pipeline.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static raf_u32 raf_rotl32(raf_u32 x, unsigned r) {
    return (x << r) | (x >> ((32u - r) & 31u));
}

static raf_u32 raf_read_le32(const raf_u8 *p) {
    return ((raf_u32)p[0]) | ((raf_u32)p[1] << 8) | ((raf_u32)p[2] << 16) | ((raf_u32)p[3] << 24);
}

static void raf_write_le32(raf_u8 *p, raf_u32 v) {
    p[0] = (raf_u8)(v & 0xffu);
    p[1] = (raf_u8)((v >> 8) & 0xffu);
    p[2] = (raf_u8)((v >> 16) & 0xffu);
    p[3] = (raf_u8)((v >> 24) & 0xffu);
}

static void raf_write_le16(raf_u8 *p, raf_u16 v) {
    p[0] = (raf_u8)(v & 0xffu);
    p[1] = (raf_u8)((v >> 8) & 0xffu);
}

static raf_u32 raf_ns_now32(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (raf_u32)((raf_u64)ts.tv_sec * 1000000000ull + (raf_u64)ts.tv_nsec);
}

static void *raf_aligned_alloc64(raf_size_t nbytes) {
#if defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 201112L)
    raf_size_t rounded = (nbytes + 63u) & ~(raf_size_t)63u;
    return aligned_alloc(64u, rounded);
#else
    return malloc(nbytes);
#endif
}

static void raf_aligned_free64(void *p) {
    free(p);
}

void raf_desc_ring_init(RafDescRing *rb) {
    memset(rb, 0, sizeof(*rb));
}

int raf_desc_ring_push(RafDescRing *rb, const RafDescriptor *desc) {
    if (rb->count >= RAF_DESC_RING_CAPACITY) {
        return -1;
    }
    rb->slots[rb->head] = *desc;
    rb->head = (rb->head + 1u) % RAF_DESC_RING_CAPACITY;
    rb->count++;
    return 0;
}

int raf_desc_ring_pop(RafDescRing *rb, RafDescriptor *out) {
    if (rb->count == 0u) {
        return -1;
    }
    *out = rb->slots[rb->tail];
    rb->tail = (rb->tail + 1u) % RAF_DESC_RING_CAPACITY;
    rb->count--;
    return 0;
}

void raf_fill_pattern(raf_u8 *dst, raf_size_t n, raf_u32 seed) {
    raf_u32 x = seed ^ 0x9e3779b9u;
    for (raf_size_t i = 0; i < n; ++i) {
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        dst[i] = (raf_u8)((x + (raf_u32)(i * 17u)) & 0xffu);
    }
}

raf_u32 raf_crc32_update_c(raf_u32 crc, const raf_u8 *data, raf_size_t n) {
    crc = ~crc;
    for (raf_size_t i = 0; i < n; ++i) {
        crc ^= data[i];
        for (unsigned bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
        }
    }
    return ~crc;
}

raf_u32 raf_fold_words_c(const raf_u32 *p, raf_size_t n_words) {
    raf_u32 acc = 0u;
    for (raf_size_t i = 0; i < n_words; ++i) {
        acc ^= p[i];
    }
    return acc;
}

void raf_copy_words_c(raf_u32 *dst, const raf_u32 *src, raf_size_t n_words) {
    for (raf_size_t i = 0; i < n_words; ++i) {
        dst[i] = src[i];
    }
}

const char *raf_path_name(RafPath path) {
    switch (path) {
        case RAF_PATH_ASM_SCALAR: return "asm-scalar";
        case RAF_PATH_ASM_NEON: return "asm-neon";
        case RAF_PATH_C:
        default: return "c";
    }
}

static void raf_copy_dispatch(RafPath path, raf_u32 *dst, const raf_u32 *src, raf_u32 n_words) {
    switch (path) {
        case RAF_PATH_ASM_NEON:
            raf_copy_words_neon_asm(dst, src, n_words);
            break;
        case RAF_PATH_ASM_SCALAR:
            raf_copy_words_asm(dst, src, n_words);
            break;
        case RAF_PATH_C:
        default:
            raf_copy_words_c(dst, src, n_words);
            break;
    }
}

static raf_u32 raf_fold_dispatch(RafPath path, const raf_u32 *src, raf_u32 n_words) {
    switch (path) {
        case RAF_PATH_ASM_NEON:
        case RAF_PATH_ASM_SCALAR:
            return raf_fold_words_asm(src, n_words);
        case RAF_PATH_C:
        default:
            return raf_fold_words_c(src, n_words);
    }
}

static void raf_latency_add(RafLatencyTelemetry *lat, raf_u32 ns) {
    static const raf_u32 limits[RAF_LAT_BUCKETS - 1] = {500u, 1000u, 2000u, 4000u, 8000u, 16000u, 32000u, 64000u, 128000u, 256000u, 512000u};
    raf_u32 idx = RAF_LAT_BUCKETS - 1u;
    if (lat->samples == 0u || ns < lat->min_ns) {
        lat->min_ns = ns;
    }
    if (ns > lat->max_ns) {
        lat->max_ns = ns;
    }
    lat->sum_ns += ns;
    lat->samples++;
    if (lat->first_sample_count < RAF_SAMPLE_TRACE) {
        lat->first_samples[lat->first_sample_count++] = ns;
    }
    for (raf_u32 i = 0; i < RAF_LAT_BUCKETS - 1u; ++i) {
        if (ns < limits[i]) {
            idx = i;
            break;
        }
    }
    lat->buckets[idx]++;
}

raf_size_t raf_build_frame_stream(raf_u8 *dst, raf_size_t cap, raf_u32 seed, raf_u32 *frames_out) {
    raf_size_t off = 0u;
    raf_u32 seq = 0u;
    raf_u32 state = seed ^ 0xa5a55a5au;
    while (off + sizeof(RafFrameHeader) + RAF_MIN_PAYLOAD <= cap) {
        raf_u32 payload_len;
        raf_u8 *hdr = dst + off;
        raf_u8 *payload;
        state = state * 1664525u + 1013904223u;
        payload_len = RAF_MIN_PAYLOAD + (state % (RAF_MAX_PAYLOAD - RAF_MIN_PAYLOAD + 1u));
        payload_len = (payload_len + 3u) & ~3u;
        if (off + sizeof(RafFrameHeader) + payload_len > cap) {
            break;
        }
        payload = hdr + sizeof(RafFrameHeader);
        raf_fill_pattern(payload, payload_len, seed ^ seq ^ payload_len);
        raf_write_le32(hdr + 0, RAF_FRAME_MAGIC);
        raf_write_le16(hdr + 4, (raf_u16)RAF_FRAME_VERSION);
        raf_write_le16(hdr + 6, (raf_u16)(seq & 0x3u));
        raf_write_le32(hdr + 8, (raf_u32)sizeof(RafFrameHeader));
        raf_write_le32(hdr + 12, payload_len);
        raf_write_le32(hdr + 16, seq);
        raf_write_le32(hdr + 20, state ^ 0x55aa00ffu);
        raf_write_le32(hdr + 24, raf_crc32_update_c(0u, payload, payload_len));
        off += sizeof(RafFrameHeader) + payload_len;
        seq++;
    }
    if (frames_out) {
        *frames_out = seq;
    }
    return off;
}

int raf_parse_frame_header(const raf_u8 *buf, raf_size_t available, RafFrameHeader *out_hdr, raf_size_t *frame_bytes_out) {
    if (available < sizeof(RafFrameHeader)) {
        return -1;
    }
    out_hdr->magic = raf_read_le32(buf + 0);
    out_hdr->version = (raf_u16)(buf[4] | (buf[5] << 8));
    out_hdr->flags = (raf_u16)(buf[6] | (buf[7] << 8));
    out_hdr->header_bytes = raf_read_le32(buf + 8);
    out_hdr->payload_len = raf_read_le32(buf + 12);
    out_hdr->seq = raf_read_le32(buf + 16);
    out_hdr->reserved = raf_read_le32(buf + 20);
    out_hdr->payload_crc32 = raf_read_le32(buf + 24);

    if (out_hdr->magic != RAF_FRAME_MAGIC || out_hdr->version != RAF_FRAME_VERSION) {
        return -2;
    }
    if (out_hdr->header_bytes != sizeof(RafFrameHeader)) {
        return -3;
    }
    if (out_hdr->payload_len < RAF_MIN_PAYLOAD || out_hdr->payload_len > RAF_MAX_PAYLOAD) {
        return -4;
    }
    if ((out_hdr->payload_len & 3u) != 0u) {
        return -5;
    }
    if (available < sizeof(RafFrameHeader) + out_hdr->payload_len) {
        return -6;
    }
    if (frame_bytes_out) {
        *frame_bytes_out = sizeof(RafFrameHeader) + out_hdr->payload_len;
    }
    return 0;
}

raf_u32 raf_cache_stress_round(raf_u8 *buf, raf_size_t n, raf_u32 cycle, raf_u32 seed) {
    static const raf_size_t strides[] = {64u, 96u, 128u, 160u, 192u, 256u, 320u, 384u, 512u};
    raf_size_t stride = strides[cycle % (sizeof(strides) / sizeof(strides[0]))];
    raf_u32 acc = seed ^ (cycle * 0x9e3779b9u);
    for (raf_size_t pass = 0; pass < 3u; ++pass) {
        for (raf_size_t i = (cycle * 17u + pass * 13u) % stride; i < n; i += stride) {
            acc ^= buf[i];
            buf[i] ^= (raf_u8)(acc + i + pass);
            acc = raf_rotl32(acc + buf[i] + (raf_u32)i, 5u);
        }
    }
    return acc;
}

static raf_u32 raf_cycle_budget_bytes(raf_u32 cycle) {
    static const raf_u32 budgets[] = {
        32768u, 49152u, 65536u, 81920u, 98304u, 114688u, 131072u, 163840u
    };
    return budgets[cycle % (sizeof(budgets) / sizeof(budgets[0]))];
}

RafPipelineStats raf_run_pipeline(RafPath path, int verbose) {
    RafPipelineStats st;
    RafDescRing ring;
    raf_u8 *stream = NULL;
    raf_u8 *stage = NULL;
    raf_u8 *cache = NULL;
    raf_size_t stream_bytes = 0u;
    raf_u32 total_frames = 0u;
    raf_size_t cursor = 0u;
    raf_u32 last_seq = 0u;
    int have_last_seq = 0;

    memset(&st, 0, sizeof(st));
    raf_desc_ring_init(&ring);

    stream = (raf_u8 *)raf_aligned_alloc64(RAF_WORKSET_BYTES);
    stage = (raf_u8 *)raf_aligned_alloc64(RAF_MAX_PAYLOAD);
    cache = (raf_u8 *)raf_aligned_alloc64(1024u * 1024u);
    if (!stream || !stage || !cache) {
        st.verification_failures = 0xffffffffu;
        raf_aligned_free64(stream);
        raf_aligned_free64(stage);
        raf_aligned_free64(cache);
        return st;
    }

    memset(stage, 0, RAF_MAX_PAYLOAD);
    raf_fill_pattern(cache, 1024u * 1024u, 0x13579bdfu);
    stream_bytes = raf_build_frame_stream(stream, RAF_WORKSET_BYTES, 0x2468ace1u, &total_frames);
    st.stream_mix = raf_crc32_update_c(0u, stream, stream_bytes > 4096u ? 4096u : stream_bytes);

    for (raf_u32 cycle = 0; cycle < RAF_PIPELINE_CYCLES; ++cycle) {
        raf_u32 budget = raf_cycle_budget_bytes(cycle);
        raf_u32 spent = 0u;
        st.cache_mix ^= raf_cache_stress_round(cache, 1024u * 1024u, cycle, 0x10203040u ^ cycle);
        st.cache_stress_rounds++;
        st.cycles++;

        while (spent < budget && cursor + sizeof(RafFrameHeader) <= stream_bytes) {
            RafFrameHeader hdr;
            raf_size_t frame_bytes = 0u;
            raf_u32 t0, t1, latency;
            raf_u8 *payload;
            raf_u32 calc_crc;
            raf_u32 fold;
            RafDescriptor desc;
            int parse_rc = raf_parse_frame_header(stream + cursor, stream_bytes - cursor, &hdr, &frame_bytes);
            if (parse_rc != 0) {
                st.parser_errors++;
                st.verification_failures++;
                break;
            }
            if (spent + (raf_u32)frame_bytes > budget && spent > 0u) {
                break;
            }
            payload = stream + cursor + hdr.header_bytes;
            t0 = raf_ns_now32();
            raf_copy_dispatch(path, (raf_u32 *)stage, (const raf_u32 *)payload, hdr.payload_len / 4u);
            fold = raf_fold_dispatch(path, (const raf_u32 *)stage, hdr.payload_len / 4u);
            calc_crc = raf_crc32_update_c(0u, stage, hdr.payload_len);
            t1 = raf_ns_now32();
            latency = t1 - t0;

            st.frames_total++;
            st.bytes_payload += hdr.payload_len;
            st.crc_mix ^= raf_rotl32(calc_crc + hdr.seq, hdr.seq & 31u);
            st.fold_mix ^= raf_rotl32(fold ^ hdr.payload_len, (hdr.seq * 3u) & 31u);
            raf_latency_add(&st.latency, latency);

            if (calc_crc != hdr.payload_crc32) {
                st.crc_errors++;
                st.verification_failures++;
            } else {
                st.frames_ok++;
            }
            if (memcmp(stage, payload, hdr.payload_len) != 0) {
                st.verification_failures++;
            }
            if (have_last_seq && hdr.seq != last_seq + 1u) {
                st.verification_failures++;
            }
            last_seq = hdr.seq;
            have_last_seq = 1;

            desc.seq = hdr.seq;
            desc.payload_len = hdr.payload_len;
            desc.payload_crc32 = calc_crc;
            desc.fold = fold;
            desc.frame_bytes = (raf_u32)frame_bytes;
            desc.latency_ns = latency;

            if (raf_desc_ring_push(&ring, &desc) != 0) {
                RafDescriptor out;
                if (raf_desc_ring_pop(&ring, &out) == 0) {
                    st.descriptor_flushes++;
                    if (out.payload_len > RAF_MAX_PAYLOAD || out.seq > desc.seq) {
                        st.verification_failures++;
                    }
                }
                if (raf_desc_ring_push(&ring, &desc) != 0) {
                    st.frames_dropped++;
                    st.verification_failures++;
                }
            }
            if (ring.count > st.ring_highwater) {
                st.ring_highwater = ring.count;
            }
            if ((hdr.seq & 7u) == 7u) {
                RafDescriptor out;
                if (raf_desc_ring_pop(&ring, &out) == 0) {
                    st.descriptor_flushes++;
                    if (out.seq > hdr.seq || out.frame_bytes < sizeof(RafFrameHeader)) {
                        st.verification_failures++;
                    }
                }
            }

            if (verbose) {
                printf("[pipeline] cycle=%02u seq=%04u len=%4u crc=%08x fold=%08x lat_ns=%u ring=%u\n",
                       cycle, hdr.seq, hdr.payload_len, calc_crc, fold, latency, ring.count);
            }

            spent += (raf_u32)frame_bytes;
            cursor += frame_bytes;
            if (cursor >= stream_bytes) {
                cursor = 0u;
                have_last_seq = 0;
            }
        }
    }

    while (ring.count != 0u) {
        RafDescriptor out;
        if (raf_desc_ring_pop(&ring, &out) == 0) {
            st.descriptor_flushes++;
        }
    }

    raf_aligned_free64(stream);
    raf_aligned_free64(stage);
    raf_aligned_free64(cache);
    return st;
}

int raf_selftest_pipeline(int verbose) {
    RafPipelineStats cst = raf_run_pipeline(RAF_PATH_C, 0);
    RafPipelineStats ast = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0);
    int ok = 1;

    if (cst.frames_total != ast.frames_total || cst.frames_ok != ast.frames_ok) ok = 0;
    if (cst.bytes_payload != ast.bytes_payload) ok = 0;
    if (cst.crc_mix != ast.crc_mix || cst.fold_mix != ast.fold_mix) ok = 0;
    if (cst.cache_mix != ast.cache_mix || cst.stream_mix != ast.stream_mix) ok = 0;
    if (cst.verification_failures != 0u || ast.verification_failures != 0u) ok = 0;

    if (verbose) {
        printf("[selftest] c:   frames=%u ok=%u bytes=%llu crc_mix=%08x fold_mix=%08x cache_mix=%08x fail=%u\n",
               cst.frames_total, cst.frames_ok, (unsigned long long)cst.bytes_payload,
               cst.crc_mix, cst.fold_mix, cst.cache_mix, cst.verification_failures);
        printf("[selftest] asm: frames=%u ok=%u bytes=%llu crc_mix=%08x fold_mix=%08x cache_mix=%08x fail=%u\n",
               ast.frames_total, ast.frames_ok, (unsigned long long)ast.bytes_payload,
               ast.crc_mix, ast.fold_mix, ast.cache_mix, ast.verification_failures);
        printf("[selftest] result=%s\n", ok ? "OK" : "FAIL");
    }
    return ok ? 0 : 1;
}
