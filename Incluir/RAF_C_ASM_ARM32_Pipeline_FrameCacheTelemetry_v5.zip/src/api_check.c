#include "raf_pipeline.h"

int raf_api_check(void) {
    RafFrameHeader h;
    RafDescriptor d;
    RafPipelineStats s;
    RafDescRing r;
    raf_desc_ring_init(&r);
    h.magic = RAF_FRAME_MAGIC;
    d.seq = 0u;
    s.frames_total = 0u;
    return (int)(h.magic + d.seq + s.frames_total + r.count);
}
