#include "raf_pipeline.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

static unsigned long long raf_ns_now64(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return ((unsigned long long)ts.tv_sec * 1000000000ull) + (unsigned long long)ts.tv_nsec;
}

static void raf_print_latency(const RafLatencyTelemetry *lat) {
    static const char *labels[RAF_LAT_BUCKETS] = {
        "<500ns", "<1us", "<2us", "<4us", "<8us", "<16us",
        "<32us", "<64us", "<128us", "<256us", "<512us", ">=512us"
    };
    unsigned long long avg = lat->samples ? (unsigned long long)(lat->sum_ns / lat->samples) : 0ull;
    printf("[latency] samples=%u min_ns=%u max_ns=%u avg_ns=%llu\n",
           lat->samples, lat->min_ns, lat->max_ns, avg);
    printf("[latency] first_samples=");
    for (raf_u32 i = 0; i < lat->first_sample_count; ++i) {
        printf("%s%u", i ? "," : "", lat->first_samples[i]);
    }
    printf("\n");
    for (raf_u32 i = 0; i < RAF_LAT_BUCKETS; ++i) {
        printf("[latency] bucket[%s]=%u\n", labels[i], lat->buckets[i]);
    }
}

static void raf_print_stats(const char *tag, RafPipelineStats st, unsigned long long ns) {
    double mib = (double)st.bytes_payload / (1024.0 * 1024.0);
    double sec = ns ? ((double)ns / 1e9) : 0.0;
    double mibps = sec > 0.0 ? mib / sec : 0.0;
    printf("[%s] cycles=%u frames_total=%u ok=%u dropped=%u parser_err=%u crc_err=%u\n",
           tag, st.cycles, st.frames_total, st.frames_ok, st.frames_dropped, st.parser_errors, st.crc_errors);
    printf("[%s] bytes_payload=%llu ring_highwater=%u cache_rounds=%u flushes=%u fail=%u\n",
           tag, (unsigned long long)st.bytes_payload, st.ring_highwater, st.cache_stress_rounds,
           st.descriptor_flushes, st.verification_failures);
    printf("[%s] crc_mix=%08x fold_mix=%08x cache_mix=%08x stream_mix=%08x\n",
           tag, st.crc_mix, st.fold_mix, st.cache_mix, st.stream_mix);
    if (ns) {
        printf("[%s] elapsed_ns=%llu throughput_mib_s=%.2f\n", tag, ns, mibps);
    }
    raf_print_latency(&st.latency);
}

int main(int argc, char **argv) {
    if (argc > 1 && strcmp(argv[1], "selftest") == 0) {
        return raf_selftest_pipeline(1);
    }
    if (argc > 1 && strcmp(argv[1], "bench") == 0) {
        unsigned long long t0, t1;
        RafPipelineStats cst, ast;
        t0 = raf_ns_now64();
        cst = raf_run_pipeline(RAF_PATH_C, 0);
        t1 = raf_ns_now64();
        raf_print_stats("bench-c", cst, t1 - t0);
        t0 = raf_ns_now64();
        ast = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0);
        t1 = raf_ns_now64();
        raf_print_stats("bench-asm", ast, t1 - t0);
        return 0;
    }
    if (argc > 1 && strcmp(argv[1], "verbose") == 0) {
        RafPipelineStats st = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 1);
        raf_print_stats("verbose", st, 0ull);
        return 0;
    }
    {
        RafPipelineStats st = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0);
        raf_print_stats("run", st, 0ull);
    }
    return 0;
}
