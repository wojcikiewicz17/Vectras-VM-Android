#ifndef RAF_PIPELINE_H
#define RAF_PIPELINE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef uint8_t  raf_u8;
typedef uint16_t raf_u16;
typedef uint32_t raf_u32;
typedef uint64_t raf_u64;
typedef size_t   raf_size_t;

enum {
    RAF_PIPELINE_CYCLES = 56,
    RAF_WORKSET_BYTES = 5 * 1024 * 1024,
    RAF_MAX_PAYLOAD = 1536,
    RAF_MIN_PAYLOAD = 64,
    RAF_FRAME_MAGIC = 0x35464152u, /* "RAF5" little-endian */
    RAF_FRAME_VERSION = 1u,
    RAF_DESC_RING_CAPACITY = 128,
    RAF_LAT_BUCKETS = 12,
    RAF_SAMPLE_TRACE = 16
};

typedef enum {
    RAF_PATH_C = 0,
    RAF_PATH_ASM_SCALAR = 1,
    RAF_PATH_ASM_NEON = 2
} RafPath;

typedef struct {
    raf_u32 magic;
    raf_u16 version;
    raf_u16 flags;
    raf_u32 header_bytes;
    raf_u32 payload_len;
    raf_u32 seq;
    raf_u32 reserved;
    raf_u32 payload_crc32;
} RafFrameHeader;

typedef struct {
    raf_u32 seq;
    raf_u32 payload_len;
    raf_u32 payload_crc32;
    raf_u32 fold;
    raf_u32 frame_bytes;
    raf_u32 latency_ns;
} RafDescriptor;

typedef struct {
    RafDescriptor slots[RAF_DESC_RING_CAPACITY];
    raf_u32 head;
    raf_u32 tail;
    raf_u32 count;
} RafDescRing;

typedef struct {
    raf_u32 min_ns;
    raf_u32 max_ns;
    raf_u64 sum_ns;
    raf_u32 samples;
    raf_u32 buckets[RAF_LAT_BUCKETS];
    raf_u32 first_samples[RAF_SAMPLE_TRACE];
    raf_u32 first_sample_count;
} RafLatencyTelemetry;

typedef struct {
    raf_u32 cycles;
    raf_u32 frames_total;
    raf_u32 frames_ok;
    raf_u32 frames_dropped;
    raf_u32 parser_errors;
    raf_u32 crc_errors;
    raf_u32 ring_highwater;
    raf_u32 cache_stress_rounds;
    raf_u32 descriptor_flushes;
    raf_u64 bytes_payload;
    raf_u32 crc_mix;
    raf_u32 fold_mix;
    raf_u32 cache_mix;
    raf_u32 stream_mix;
    raf_u32 verification_failures;
    RafLatencyTelemetry latency;
} RafPipelineStats;

void raf_desc_ring_init(RafDescRing *rb);
int raf_desc_ring_push(RafDescRing *rb, const RafDescriptor *desc);
int raf_desc_ring_pop(RafDescRing *rb, RafDescriptor *out);

void raf_fill_pattern(raf_u8 *dst, raf_size_t n, raf_u32 seed);
raf_u32 raf_crc32_update_c(raf_u32 crc, const raf_u8 *data, raf_size_t n);
raf_u32 raf_fold_words_c(const raf_u32 *p, raf_size_t n_words);
void raf_copy_words_c(raf_u32 *dst, const raf_u32 *src, raf_size_t n_words);

raf_u32 raf_fold_words_asm(const raf_u32 *p, raf_u32 n_words);
void raf_copy_words_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words);
void raf_copy_words_neon_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words);

raf_size_t raf_build_frame_stream(raf_u8 *dst, raf_size_t cap, raf_u32 seed, raf_u32 *frames_out);
int raf_parse_frame_header(const raf_u8 *buf, raf_size_t available, RafFrameHeader *out_hdr, raf_size_t *frame_bytes_out);
raf_u32 raf_cache_stress_round(raf_u8 *buf, raf_size_t n, raf_u32 cycle, raf_u32 seed);
RafPipelineStats raf_run_pipeline(RafPath path, int verbose);
int raf_selftest_pipeline(int verbose);

const char *raf_path_name(RafPath path);

#ifdef __cplusplus
}
#endif

#endif
