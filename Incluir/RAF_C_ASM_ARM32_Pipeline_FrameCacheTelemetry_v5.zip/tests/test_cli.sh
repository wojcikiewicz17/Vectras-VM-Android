#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
make host >/dev/null
./build/host/raf_pipeline_v5 selftest
./build/host/raf_pipeline_v5 bench >/dev/null
