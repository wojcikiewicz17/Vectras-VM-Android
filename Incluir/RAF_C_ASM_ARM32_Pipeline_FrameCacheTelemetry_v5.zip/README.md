# RAF Pipeline v5 — ARM32 frame parser + cache stress + latency telemetry

Pacote C + ASM orientado a **pipeline low-level** mais próximo de uso real:

- geração de stream de frames em **5 MiB**
- **parser de frame** com cabeçalho fixo e payload alinhado
- **cache stress** determinístico por ciclo
- **telemetria de latência por frame**
- **ring de descritores**
- hot path com:
  - cópia em C
  - cópia/fold ASM ARM32 scalar
  - cópia NEON opcional

## Alvo
- Linux ARM32 / ARMv7-A / AAPCS EABI hard-float
- host simulator em C para validar lógica e produzir benchmark/telemetria

## Estrutura do frame
- `magic`
- `version`
- `flags`
- `header_bytes`
- `payload_len`
- `seq`
- `reserved`
- `payload_crc32`

## Modos
```bash
make host
make run
make bench
make test
make arm32_objcheck
```

## Observação importante
Neste ambiente eu validei:
- build host executável
- self-test lógico
- benchmark host
- montagem/objcheck ARM32
- disassembly dos objetos ARM32

Eu **não executei binário ARM32 final nativo** aqui, porque o ambiente não tem runtime/sysroot ARM32 completo.
