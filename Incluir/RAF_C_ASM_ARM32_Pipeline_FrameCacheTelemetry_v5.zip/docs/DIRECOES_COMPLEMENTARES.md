# 15 direções possíveis, diferentes e complementares

1. **CRC32 tabelado slicing-by-4/slicing-by-8**  
   Acelerar o checksum em software mantendo compatibilidade com o parser atual.

2. **Fast path / slow path de cabeçalho**  
   Separar frame válido comum de casos raros para reduzir branches no caminho quente.

3. **Prefetch explícito de payload**  
   Testar prefetch de próxima carga antes da cópia para reduzir custo de miss.

4. **NEON fold vetorial**  
   Levar parte do fold/XOR para vetor e comparar custo com scalar.

5. **Ring lock-free SPSC**  
   Trocar o ring atual por single-producer/single-consumer com barreiras mínimas.

6. **Zero-copy por descritor + offset**  
   Em vez de copiar sempre para stage, operar com offset/len quando o consumidor permitir.

7. **Backpressure realista**  
   Adicionar política de drop, retry, watermark e prioridade por tipo de frame.

8. **Parser com fragmentação e reassembly**  
   Simular frames partidos em múltiplos buffers, mais próximo de link real.

9. **Fault injection controlado**  
   Inserir CRC ruim, header truncado, seq quebrado e payload desalinhado para validar robustez.

10. **Telemetria por percentil**  
    Além de min/max/média, calcular p50/p90/p99 e exportar para CSV.

11. **Stress L1/L2 parametrizado**  
    Explorar strides, tamanhos e passes para mapear sensibilidade do pipeline a cache.

12. **Integração com timestamp de hardware**  
    Trocar clock host por contador de ciclo/temporizador do alvo real.

13. **Modelo TTL/timer por frame**  
    Anexar deadlines e expiração no ring para medir perda por latência, não só por CRC.

14. **CRC híbrido SW/HW**  
    Manter software como fallback e acoplar instrução/periférico de CRC quando existir.

15. **Traço exportável para análise externa**  
    Gerar log estruturado por frame para plotar latência, bursts e pressão de ring.
