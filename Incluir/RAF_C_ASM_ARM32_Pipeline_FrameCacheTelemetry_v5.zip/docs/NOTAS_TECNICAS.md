# Notas técnicas

## Objetivo
Aproximar o hot path anterior de um pipeline mais realista com:
- framing explícito
- parsing e validação
- backpressure simples por ring de descritores
- stress de cache entre janelas de processamento
- telemetria de latência por frame

## Ciclos
- 56 ciclos fixos
- budget de bytes por ciclo varia de forma determinística
- working set do stream: 5 MiB
- cache stress buffer: 1 MiB

## Limites assumidos
- payload entre 64 e 1536 bytes
- payload alinhado em 4 bytes
- parser em little-endian
- benchmark host mede tendência e integridade, não prova performance ARM real

## Caminhos de execução
- `RAF_PATH_C`: referência lógica
- `RAF_PATH_ASM_SCALAR`: usa stubs no host, ASM real no objcheck ARM32
- `RAF_PATH_ASM_NEON`: mesmo papel, com cópia NEON opcional
