# Comandos

## Host
```bash
make host
make run
make bench
make test
```

## Checagem ARM32
```bash
make arm32_objcheck
llvm-objdump -d build/obj/raf_armv7_pipeline.o
llvm-objdump -d build/obj/raf_neon_pipeline_optional.o
```

## Saída esperada
- `selftest`: deve terminar com `result=OK`
- `bench`: deve mostrar dois blocos (`bench-c` e `bench-asm`) com latência e throughput
