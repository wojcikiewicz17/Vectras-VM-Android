#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){ char line[]="10,20,30"; char *t=strtok(line,","); while(t){ int v=atoi(t); sscanf(t,"%d",&v); t=strtok(NULL,","); } return 0; }
