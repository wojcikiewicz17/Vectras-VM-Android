#include <sys/socket.h>
int main(){ int s=socket(2,1,0); bind(s,0,0); listen(s,16); return 0; }
