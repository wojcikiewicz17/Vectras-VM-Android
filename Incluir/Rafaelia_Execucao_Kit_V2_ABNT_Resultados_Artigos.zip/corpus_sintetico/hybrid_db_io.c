#include <stdio.h>
int main(){ FILE *f=fopen("db.txt","r"); query("select"); printf("ok"); fclose(f); return 0; }
