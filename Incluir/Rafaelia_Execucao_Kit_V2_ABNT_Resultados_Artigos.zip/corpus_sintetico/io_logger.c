#include <stdio.h>
#include <unistd.h>
int main(){ FILE *f=fopen("out.log","w"); fprintf(f,"ok\n"); fclose(f); write(1,"done\n",5); return 0; }
