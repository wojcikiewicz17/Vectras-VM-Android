int aes_round(int x){ return x ^ 0x5a; }
int main(){ int x=aes_round(1); encrypt(&x); decrypt(&x); return 0; }
