#include <stdio.h>
#include <unistd.h>
int main(){ char buf[64]; int n=read(0,buf,sizeof(buf)); if(n>0) write(1,buf,n); printf("copied\n"); return 0; }
