int main(){ for(int i=0;i<10;i++){ if(i%2){ continue; } else { while(0){} } } switch(1){ case 1: break; default: break; } return 0; }
