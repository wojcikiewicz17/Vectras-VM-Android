int main(){ sqlite_open("x.db"); query("select 1"); insert("cache"); commit(); return 0; }
