int main(){ int x=0; if(x){ goto done; } for(;;){ break; } done: return 0; }
