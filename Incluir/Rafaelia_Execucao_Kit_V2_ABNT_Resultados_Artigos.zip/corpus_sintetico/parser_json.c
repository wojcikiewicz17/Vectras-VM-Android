void parse_json(const char *json){ /* parse json */ }
int main(){ parse_json("{\"a\":1}"); return 0; }
