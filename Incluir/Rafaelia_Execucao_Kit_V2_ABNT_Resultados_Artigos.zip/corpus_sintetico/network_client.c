#include <sys/socket.h>
#include <arpa/inet.h>
int main(){ int s=socket(AF_INET,SOCK_STREAM,0); connect(s,0,0); send(s,"GET",3,0); recv(s,0,0,0); return 0; }
