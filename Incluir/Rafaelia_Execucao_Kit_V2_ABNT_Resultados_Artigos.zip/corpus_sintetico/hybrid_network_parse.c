#include <sys/socket.h>
#include <string.h>
int main(){ int s=socket(2,1,0); connect(s,0,0); char buf[128]; recv(s,buf,128,0); sscanf(buf,"%d",&s); parse(buf); return 0; }
