void sha256(const char *in, char *out){}
int main(){ char out[32]; sha256("abc",out); hash(out); encrypt(out); decrypt(out); return 0; }
