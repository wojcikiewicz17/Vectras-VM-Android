int main(){ sql_query("select * from t"); insert_row(); commit(); rollback(); return 0; }
