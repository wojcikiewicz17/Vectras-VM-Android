# Dissertação base em formato brasileiro

## Título
**Semântica Dinâmica, Fronteiras de Ruído e Inferência de Intenção: fundamentos, simulações e aplicação em artefatos de software**

## Observação
Esta versão foi preparada como base brasileira com formatação próxima ao padrão ABNT e elementos pré-textuais editáveis. Campos institucionais e nomes de orientação foram deixados como placeholders para preenchimento final.

## Elementos pré-textuais
- capa
- folha de rosto
- folha de aprovação (placeholder)
- dedicatória (placeholder)
- agradecimentos (placeholder)
- resumo
- abstract
- lista de figuras
- lista de tabelas
- sumário

## Resumo
Esta dissertação propõe um framework para modelar coerência, ruído e intenção como propriedades dinâmicas de estados latentes em sistemas simbólicos e computacionais. A hipótese central é que processos interpretativos podem ser tratados como transições de estado sob ação de contexto e perturbação, permitindo medir estabilidade, colapso, robustez e fronteiras de ruído. O trabalho separa explicitamente fato estabelecido, modelo técnico verificável, hipótese autoral e linguagem expressiva. Foram produzidos resultados simulados com diferenciação clara entre regimes de ruído e um baseline aplicado de inferência de intenção em código, com acurácia de 0.9286 e macro-F1 de 0.9333 em corpus sintético. As contribuições se concentram em uma taxonomia epistemológica operacional, um modelo mínimo reproduzível, protocolos de falsificação e uma ponte concreta com software archaeology e reverse engineering.

## Capítulos
1. Introdução
2. Ontologia e classificação epistemológica
3. Fundamentação matemática e computacional
4. Modelo de semântica dinâmica
5. Resultados simulados e fronteiras de ruído
6. Inferência de intenção em software
7. Validação, limites e ameaças à validade
8. Discussão
9. Conclusão
10. Referências
11. Apêndices e anexos

## Resultado-chave incorporado
- Monte Carlo separa regimes de ruído;
- faixa informativa estimada entre 0.17 e 0.29;
- robustez cai de forma gradual com o aumento da perturbação;
- baseline de intenção já é utilizável para triagem inicial.

## Observações finais
A dissertação já sai pronta para edição final, personalização institucional e ampliação empírica.
