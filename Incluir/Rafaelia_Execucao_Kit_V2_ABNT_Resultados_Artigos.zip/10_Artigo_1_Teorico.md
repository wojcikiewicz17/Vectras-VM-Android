# Artigo 1 — teórico

## Título
**Semântica como dinâmica de estado: taxonomia epistemológica e framework mínimo para coerência sob variação contextual**

## Resumo
Este artigo propõe um framework teórico para tratar coerência, ruído e interpretação como propriedades dinâmicas de estados latentes. O ponto de partida é a necessidade de separar, com rigor, quatro níveis frequentemente misturados em formulações conceituais amplas: fato estabelecido, modelo técnico verificável, hipótese autoral e linguagem expressiva. A contribuição central é dupla. Primeiro, apresenta-se uma taxonomia epistemológica que evita extrapolações indevidas. Segundo, propõe-se um modelo mínimo de semântica dinâmica no qual estabilidade, colapso e robustez podem ser investigados computacionalmente. O artigo não reivindica validação empírica final; seu objetivo é oferecer uma base formal e metodológica sobre a qual experimentos posteriores possam ser construídos.

## 1. Introdução
Em muitos contextos, o significado é tratado como propriedade local de símbolos. Essa abordagem é útil, mas insuficiente quando o interesse recai sobre persistência de coerência, transição entre regimes e reorganização sob perturbação. A proposta aqui é deslocar a análise do símbolo isolado para o estado do sistema.

## 2. Problema
Como transformar uma formulação conceitual ampla em um programa de pesquisa falsificável, evitando mistura de engenharia, ciência formal, hipótese autoral e linguagem expressiva?

## 3. Taxonomia epistemológica
Toda afirmação deve ser classificada como:
- fato estabelecido;
- modelo técnico verificável;
- hipótese científica aberta;
- hipótese autoral;
- linguagem expressiva.

Essa taxonomia não empobrece o projeto; ela o torna operacional.

## 4. Modelo mínimo
Considera-se uma atualização do tipo:

x(t+1) = f(x(t), u(t), epsilon(t), theta)

com seis variáveis escalares normalizadas:
- direção interpretativa;
- erro observável;
- tensão interna;
- persistência operacional;
- limite estrutural;
- distância observador-fenômeno.

## 5. Hipóteses centrais
- H1: há regimes de estabilidade contextual;
- H2: existe fronteira de ruído com reorganização sem colapso total;
- H3: intenção funcional pode ser inferida parcialmente em artefatos computacionais;
- H4: colapso é mensurável por divergência e instabilidade.

## 6. Critérios de admissibilidade
Uma proposição só entra na parte metodológica se responder:
1. qual é a entidade?
2. qual é a variável?
3. qual é o mecanismo?
4. como medir?
5. como refutar?

## 7. Agenda de pesquisa
A agenda derivada do framework inclui:
- simulações de estabilidade;
- análise de robustez;
- varredura de ruído;
- inferência de intenção em software;
- comparação com baselines mais fortes.

## 8. Conclusão
O principal resultado teórico é a criação de um espaço disciplinado em que um projeto conceitual amplo passa a sustentar pesquisa séria, crítica e incremental.

## Palavras-chave
semântica dinâmica; coerência; ruído; epistemologia; sistemas dinâmicos.
