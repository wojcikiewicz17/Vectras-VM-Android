# Resultados simulados e gráficos

## Escopo
Este relatório consolida a execução efetiva dos scripts do pacote anterior, com geração de resultados simulados, tabelas e gráficos. O objetivo não é afirmar validação científica conclusiva, mas transformar o framework em um conjunto inicial de evidências reproduzíveis.

## Scripts executados
- `sim_semantica_dinamica.py`
- `montecarlo_falsificabilidade.py`
- `fronteira_ruido_atratores.py`
- `robustez_contextual.py`
- `inferencia_intencao_codigo_baseline.py`

## Resultado 1 — simulação única
Com `steps=300`, `noise=0.15` e `seed=7`, a simulação única produziu:
- saída média: -0.5523
- desvio-padrão da saída: 0.3192
- delta médio de estado: 0.3051
- taxa de colapso: 0.0167
- índice de estabilidade: 0.7663

## Resultado 2 — Monte Carlo de falsificabilidade
A varredura Monte Carlo foi executada com 80 repetições por nível de ruído e 300 passos por repetição. O padrão observado foi monotônico e forte:
- ruído 0.01: colapso médio 0.0000; estabilidade média 0.9779
- ruído 0.15: colapso médio 0.0214; estabilidade média 0.7645
- ruído 0.20: colapso médio 0.1584; estabilidade média 0.7113
- ruído 0.30: colapso médio 0.5415; estabilidade média 0.6299
- ruído 0.40: colapso médio 0.7493; estabilidade média 0.5712

Leitura: o baseline distingue nitidamente regimes de baixo, médio e alto ruído. Isso fortalece a falsificabilidade do framework, porque o modelo não responde de forma indiferenciada ao parâmetro central.

## Resultado 3 — fronteira de ruído
Na varredura de fronteira, a entropia sobe de 1.4995 no ruído 0.01 para 3.4849 no ruído 0.45. A região mais interessante aparece entre 0.17 e 0.29, onde:
- a entropia já é alta (3.3140 a 3.4443);
- a estabilidade segue presente, embora decrescente (0.6369 a 0.7422);
- o colapso cresce sem saturar totalmente (0.0603 a 0.5068).

Interpretação operacional: essa faixa é a melhor candidata a “fronteira informativa”, isto é, uma zona em que o ruído reorganiza o sistema sem ainda destruí-lo por completo.

## Resultado 4 — robustez contextual
No experimento de robustez, a similaridade média cai de 0.9649 na escala 0.02 para 0.8046 na escala 0.50. O índice de robustez (quantil de 10%) cai de 0.9643 para 0.7591 no mesmo intervalo.

Leitura: o sistema simulado preserva alta similaridade sob perturbações pequenas e moderadas, mas começa a perder persistência de forma mais acentuada a partir das faixas 0.30–0.50.

## Resultado 5 — baseline de inferência de intenção em código
Foi criado um corpus sintético com 14 arquivos distribuídos entre as classes:
- I/O
- rede
- parsing
- criptografia
- persistência
- controle de fluxo

O baseline heurístico atingiu:
- acurácia global: 0.9286
- macro-F1: 0.9333

Houve apenas um erro no corpus sintético: `hybrid_db_io.c`, esperado como persistência e previsto como I/O. O erro é coerente com o desenho do baseline: a heurística lexical é puxada por chamadas de arquivo e impressão quando o arquivo contém sinais mistos.

## Leitura integrada dos resultados
Os cinco resultados convergem em uma direção coerente:
1. há diferença clara entre regimes de ruído;
2. existe uma zona intermediária com aumento de entropia sem colapso absoluto;
3. a robustez contextual decai de forma graduada, não caótica;
4. o baseline de intenção é aplicável em artefatos simples;
5. o pacote já sustenta uma agenda experimental séria.

## Limites
- os dados centrais ainda são sintéticos;
- a fronteira de ruído depende do baseline atual e deve ser testada contra variantes do modelo;
- o experimento de intenção usa um corpus controlado e pequeno;
- os números não devem ser extrapolados como evidência geral de cognição, linguagem natural ou física.

## Próxima extensão natural
- testar variações paramétricas do modelo;
- aumentar o corpus de código;
- adicionar análise estática real;
- comparar o baseline heurístico com modelos supervisionados;
- fazer ablação de variáveis.
