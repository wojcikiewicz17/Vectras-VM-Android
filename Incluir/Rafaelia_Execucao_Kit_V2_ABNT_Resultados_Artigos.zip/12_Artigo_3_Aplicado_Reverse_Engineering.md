# Artigo 3 — aplicado em software e reverse engineering

## Título
**Inferência de intenção em artefatos de software: um baseline heurístico para software archaeology e reverse engineering**

## Resumo
Este artigo explora a inferência de intenção funcional em código-fonte por meio de um baseline heurístico reproduzível. Foi construído um corpus sintético com 14 arquivos cobrindo as classes I/O, rede, parsing, criptografia, persistência e controle de fluxo. O baseline, baseado em padrões lexicais e chamadas típicas, alcançou acurácia de 0.9286 e macro-F1 de 0.9333. O erro principal ocorreu em um arquivo híbrido com sinais simultâneos de persistência e I/O, revelando a limitação central da abordagem: viés lexical em módulos mistos. Mesmo assim, o experimento mostra que a linha de pesquisa é tecnicamente concreta e pode ser expandida com análise estática, features semânticas e dados reais de engenharia reversa.

## 1. Introdução
Na prática de software archaeology e reverse engineering, recuperar a intenção funcional de um módulo é um problema recorrente. Este artigo propõe um primeiro baseline simples e transparente.

## 2. Corpus
O corpus sintético contém 14 arquivos, com classes esperadas balanceadas o suficiente para um teste inicial.

## 3. Método
Foram usados padrões heurísticos para detectar:
- operações de I/O;
- chamadas de rede;
- sinais de parsing;
- palavras-chave de criptografia;
- operações de persistência;
- estruturas de controle de fluxo.

## 4. Resultados
- acurácia: 0.9286
- macro-F1: 0.9333

F1 por classe:
         label  precision   recall  f1  support
            io   0.666667 1.000000 0.8        2
          rede   1.000000 1.000000 1.0        3
       parsing   1.000000 1.000000 1.0        2
  criptografia   1.000000 1.000000 1.0        2
  persistencia   1.000000 0.666667 0.8        3
controle_fluxo   1.000000 1.000000 1.0        2

## 5. Erro mais relevante
O arquivo `hybrid_db_io.c` foi esperado como persistência e previsto como I/O. Isso mostra que o baseline tende a priorizar o vocabulário mais superficial quando o módulo mistura domínios.

## 6. Implicações para reverse engineering
Mesmo simples, o baseline já serve para:
- triagem inicial de corpus;
- agrupamento preliminar de módulos;
- apoio a documentação tardia;
- priorização de análise humana.

## 7. Próximos passos
- features estruturais;
- uso de AST e CFG;
- integração com análise dinâmica;
- validação em código real.

## Palavras-chave
software archaeology; reverse engineering; inferência de intenção; classificação heurística; análise de código.
