# Artigo 2 — experimental

## Título
**Fronteiras de ruído em um modelo de semântica dinâmica: estudo de estabilidade, colapso e robustez contextual**

## Resumo
Este artigo apresenta resultados simulados para um baseline de semântica dinâmica executado em Python. Foram realizados: uma simulação única, uma varredura Monte Carlo de falsificabilidade, uma análise de fronteira de ruído e um experimento de robustez contextual. Os resultados mostram diferenciação clara entre regimes de baixo, médio e alto ruído. A taxa média de colapso sobe de 0.0000 no ruído 0.01 para 0.7493 no ruído 0.40, enquanto o índice médio de estabilidade cai de 0.9779 para 0.5712. A região entre 0.17 e 0.29 emerge como faixa de transição informativa, na qual a entropia já é alta, mas o colapso ainda não saturou. O artigo conclui que o baseline é suficiente para sustentar uma linha experimental inicial, embora ainda dependa de dados sintéticos e de maior análise de sensibilidade.

## 1. Introdução
Modelos de interpretação como dinâmica de estado exigem evidência de que as métricas respondem de forma consistente ao ruído. Este trabalho testa exatamente esse ponto.

## 2. Método
Foram executados quatro blocos:
- simulação única com 300 passos;
- Monte Carlo com 80 repetições por nível de ruído;
- varredura de fronteira em 12 níveis de ruído;
- robustez contextual em 9 escalas de perturbação.

## 3. Resultados principais
- ruído 0.15: colapso médio 0.0214; estabilidade 0.7645
- ruído 0.20: colapso médio 0.1584; estabilidade 0.7113
- ruído 0.30: colapso médio 0.5415; estabilidade 0.6299

Na fronteira informativa, a entropia varia entre 3.3140 e 3.4443, enquanto o colapso varia entre 0.0603 e 0.5068.

## 4. Discussão
Os resultados reforçam duas teses:
1. o modelo distingue regimes de ruído;
2. a região intermediária contém informação útil sobre reorganização do sistema.

## 5. Limitações
- dados sintéticos;
- baseline simples;
- ausência de comparação com outros modelos.

## 6. Conclusão
O pacote atual já sustenta um artigo experimental de base, desde que os limites sejam assumidos explicitamente.

## Palavras-chave
ruído; estabilidade; colapso; robustez; simulação computacional.
