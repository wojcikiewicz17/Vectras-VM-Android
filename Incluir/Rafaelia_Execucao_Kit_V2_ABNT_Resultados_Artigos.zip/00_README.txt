RAFAELIA EXECUÇÃO — KIT V2

Este pacote consolida quatro camadas:
1) saneamento conceitual e paper base;
2) resultados simulados e gráficos;
3) dissertação-base em padrão brasileiro/ABNT editável;
4) linha de três artigos pronta para expansão.

PRINCIPAIS ARQUIVOS NOVOS
- 06_Resultados_Simulados_e_Graficos.docx
- 06_Resultados_Simulados_e_Graficos.md
- 06_Resultados_Simulados.xlsx
- 08_Dissertacao_ABNT_Base.docx
- 08_Dissertacao_ABNT_Base.md
- 09_Linha_de_Artigos.docx
- 09_Linha_de_Artigos.md
- 10_Artigo_1_Teorico.docx
- 10_Artigo_1_Teorico.md
- 11_Artigo_2_Experimental.docx
- 11_Artigo_2_Experimental.md
- 12_Artigo_3_Aplicado_Reverse_Engineering.docx
- 12_Artigo_3_Aplicado_Reverse_Engineering.md
- graficos/
- sim_results/
- corpus_sintetico/

RESULTADOS-CHAVE DESTA VERSÃO
- Faixa informativa de ruído observada aproximadamente entre 0.17 e 0.29.
- Acurácia do baseline de intenção em corpus sintético: 0.9286
- Macro-F1 do baseline de intenção: 0.9333

OBSERVAÇÃO IMPORTANTE
Este pacote contém evidência computacional inicial e reproduzível.
Ele NÃO deve ser apresentado como prova científica definitiva.
Os resultados centrais ainda são sintéticos e precisam de expansão empírica.

ARQUIVOS HERDADOS DO KIT ANTERIOR
Os arquivos 01, 02, 04 e 05 foram mantidos para continuidade do projeto.
