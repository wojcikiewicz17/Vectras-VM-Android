# Linha de artigos

## Estratégia geral
A linha de publicação foi organizada em três artigos complementares, com encadeamento lógico e reaproveitamento controlado de material:

1. **Artigo 1 — teórico**: ontologia, taxonomia epistemológica e framework de semântica dinâmica.
2. **Artigo 2 — experimental**: resultados simulados sobre estabilidade, colapso e fronteira de ruído.
3. **Artigo 3 — aplicado**: inferência de intenção em código e software/reverse engineering.

## Artigo 1 — eixo teórico
**Título-base:** Semântica como dinâmica de estado: taxonomia epistemológica e framework mínimo para coerência sob variação contextual.

**Pergunta central:** como converter um conjunto conceitual amplo em um objeto acadêmico falsificável sem misturar fato, hipótese e linguagem expressiva?

**Contribuições:**
- taxonomia de status epistemológico;
- definição de variáveis e modelo mínimo;
- critérios de falsificação;
- agenda metodológica.

## Artigo 2 — eixo experimental
**Título-base:** Fronteiras de ruído em um modelo de semântica dinâmica: estudo de estabilidade, colapso e robustez contextual.

**Pergunta central:** o baseline computacional distingue regimes de baixo, médio e alto ruído, com zona intermediária de reorganização?

**Contribuições:**
- resultados Monte Carlo;
- identificação de faixa fronteiriça;
- métricas de estabilidade e entropia;
- limites e ameaças à validade.

## Artigo 3 — eixo aplicado
**Título-base:** Inferência de intenção em artefatos de software: um baseline heurístico para software archaeology e reverse engineering.

**Pergunta central:** até que ponto uma inferência lexical-estrutural simples já recupera intenção funcional em módulos de código?

**Contribuições:**
- corpus sintético inicial;
- baseline reproduzível;
- métricas por classe;
- discussão sobre ambiguidades híbridas.

## Ordem recomendada de escrita e submissão
1. Artigo 1 primeiro, para firmar o quadro conceitual.
2. Artigo 2 na sequência, usando os resultados já gerados.
3. Artigo 3 como peça de concretude técnica e ponte para análise de software.

## Mapa com a dissertação
- Capítulos 1 e 2 alimentam o Artigo 1.
- Capítulos 3 e 4 alimentam o Artigo 2.
- Capítulo 5 alimenta o Artigo 3.
- Capítulos 6 e 7 articulam discussão integrada e limites.

## Status
Os três artigos já saem deste pacote com versão-base redigida e editável.
