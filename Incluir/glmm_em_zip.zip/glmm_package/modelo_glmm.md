# Estrutura do GLMM

## Formulação
Modelo binomial com link logit:

`resposta ~ tratamento + idade + sexo_m + (1 | escola) + (1 | turma)`

## Quando usar
Use GLMM quando você tiver:
- resposta não normal (0/1, contagem, proporção),
- dados agrupados ou repetidos,
- necessidade de separar efeito médio e heterogeneidade entre grupos.

## Leitura substantiva
- **efeitos fixos**: efeito médio populacional.
- **efeitos aleatórios**: variação entre grupos.
- **odds ratio**: `exp(beta)` em modelo logístico.

## Exemplo de interpretação
Se `tratamento` tiver estimativa positiva e odds ratio > 1:
- o tratamento está associado a maior chance do evento,
- controlando por idade, sexo e estrutura de agrupamento.

## Extensões possíveis
- intercepto aleatório + inclinação aleatória: `(1 + tratamento | escola)`
- modelo Poisson: contagens
- modelo binomial negativo: superdispersão
- termos de interação: `tratamento * sexo_m`
