# Pacote GLMM — exemplo pronto em ZIP

## O que é este pacote
Este pacote entrega um **GLMM binomial** (Generalized Linear Mixed Model) com:
- **dados sintéticos hierárquicos**,
- **script em R com `lme4::glmer()`**,
- **script em Python com `statsmodels`**,
- **saídas já geradas** no ambiente Python.

## Estrutura do modelo
Resposta binária:

\[
\text{logit}(P(Y_{ijk}=1)) = \beta_0 + \beta_1\,tratamento_{ijk} + \beta_2\,idade_{ijk} + \beta_3\,sexo\_{ijk} + u_{escola_j} + u_{turma_k}
\]

onde:
- `tratamento`, `idade` e `sexo_m` são **efeitos fixos**;
- `escola` e `turma` entram como **efeitos aleatórios**.

## Estrutura dos arquivos
- `dados/dados_glmm_exemplo.csv` → base de dados sintética
- `scripts/glmm_binomial_lme4.R` → GLMM clássico em R com `glmer()`
- `scripts/glmm_binomial_statsmodels.py` → GLMM binomial em Python via `BinomialBayesMixedGLM`
- `saidas/resumo_modelo.txt` → resumo do ajuste Python
- `saidas/efeitos_fixos_glmm.csv` → coeficientes fixos e odds ratios
- `saidas/componentes_variancia_glmm.csv` → componentes de variância
- `saidas/predicoes_glmm.csv` → probabilidades previstas
- `saidas/glmm_observado_vs_previsto.png` → gráfico simples observado vs previsto

## Como usar rápido

### Opção A — R (recomendado para GLMM clássico)
1. Instale R e RStudio.
2. Instale os pacotes:
   ```r
   install.packages(c("lme4", "readr", "dplyr", "broom.mixed"))
   ```
3. Rode:
   ```r
   source("scripts/glmm_binomial_lme4.R")
   ```

### Opção B — Python
1. Crie um ambiente com:
   ```bash
   pip install pandas numpy matplotlib statsmodels
   ```
2. Rode:
   ```bash
   python scripts/glmm_binomial_statsmodels.py
   ```

## Como adaptar para seus dados
Troque o arquivo CSV por uma base sua e ajuste:
- variável resposta (`resposta`)
- covariáveis fixas
- fatores de agrupamento (`escola`, `turma`)
- família do modelo:
  - binomial → desfecho 0/1
  - poisson / negativa binomial → contagens

## Interpretação rápida
- coeficiente positivo em `tratamento` → aumenta a chance do desfecho
- `exp(beta)` = **odds ratio**
- maior variância de `escola` ou `turma` → maior heterogeneidade entre grupos

## Observação
O script em R foi preparado, mas não executado neste ambiente porque R não está instalado aqui. Já o script Python foi executado e as saídas foram exportadas.
