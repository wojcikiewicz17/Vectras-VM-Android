# GLMM binomial em R usando lme4::glmer
# Modelo: resposta ~ tratamento + idade + sexo_m + (1|escola) + (1|turma)

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(lme4)
  library(broom.mixed)
})

# Caminhos
base_dir <- normalizePath(".", winslash = "/", mustWork = FALSE)
dados_path <- file.path(base_dir, "dados", "dados_glmm_exemplo.csv")
saidas_dir <- file.path(base_dir, "saidas")
if (!dir.exists(saidas_dir)) dir.create(saidas_dir, recursive = TRUE)

# Leitura
dados <- read_csv(dados_path, show_col_types = FALSE) %>%
  mutate(
    escola = as.factor(escola),
    turma = as.factor(turma),
    sexo_m = as.numeric(sexo_m),
    tratamento = as.numeric(tratamento),
    resposta = as.numeric(resposta)
  )

# Ajuste do GLMM
mod_glmm <- glmer(
  resposta ~ tratamento + idade + sexo_m + (1 | escola) + (1 | turma),
  data = dados,
  family = binomial(link = "logit"),
  control = glmerControl(optimizer = "bobyqa")
)

# Resumo
sink(file.path(saidas_dir, "resumo_modelo_R.txt"))
print(summary(mod_glmm))
sink()

# Efeitos fixos
fixos <- tidy(mod_glmm, effects = "fixed", conf.int = TRUE, conf.method = "Wald") %>%
  mutate(
    odds_ratio = exp(estimate),
    or_low = exp(conf.low),
    or_high = exp(conf.high)
  )

write_csv(fixos, file.path(saidas_dir, "efeitos_fixos_glmm_R.csv"))

# Componentes de variância
vc <- as.data.frame(VarCorr(mod_glmm))
write_csv(vc, file.path(saidas_dir, "componentes_variancia_glmm_R.csv"))

# Predições
dados$prob_prevista <- predict(mod_glmm, type = "response")
write_csv(dados, file.path(saidas_dir, "predicoes_glmm_R.csv"))

cat("\nGLMM concluído com sucesso.\n")
cat("Arquivos exportados em:", saidas_dir, "\n")
