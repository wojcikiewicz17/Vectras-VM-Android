"""
GLMM binomial em Python usando statsmodels.
Ajusta um modelo com efeitos fixos para tratamento, idade e sexo,
e efeitos aleatórios para escola e turma.
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.genmod.bayes_mixed_glm import BinomialBayesMixedGLM

BASE = Path(__file__).resolve().parents[1]
DADOS = BASE / "dados" / "dados_glmm_exemplo.csv"
SAIDAS = BASE / "saidas"
SAIDAS.mkdir(exist_ok=True)

df = pd.read_csv(DADOS)

model = BinomialBayesMixedGLM.from_formula(
    "resposta ~ tratamento + idade + sexo_m",
    {"escola": "0 + C(escola)", "turma": "0 + C(turma)"},
    df,
)

result = model.fit_vb()

with open(SAIDAS / "resumo_modelo.txt", "w", encoding="utf-8") as f:
    f.write(str(result.summary()))

fe = pd.DataFrame(
    {
        "parametro": model.exog_names,
        "estimativa": result.fe_mean,
        "desvio_padrao": result.fe_sd,
    }
)
fe["odds_ratio"] = np.exp(fe["estimativa"])
fe.to_csv(SAIDAS / "efeitos_fixos_glmm.csv", index=False)

vcp = pd.DataFrame(
    {
        "componente": model.vcp_names,
        "log_sd_media_posterior": result.vcp_mean,
        "sd_aprox": np.exp(result.vcp_mean),
    }
)
vcp.to_csv(SAIDAS / "componentes_variancia_glmm.csv", index=False)

df["prob_prevista"] = result.predict()
df.to_csv(SAIDAS / "predicoes_glmm.csv", index=False)

agg = df.groupby("tratamento")[["resposta", "prob_prevista"]].mean().reset_index()

plt.figure(figsize=(6, 4))
x = np.arange(len(agg))
w = 0.35
plt.bar(x - w / 2, agg["resposta"], width=w, label="observado")
plt.bar(x + w / 2, agg["prob_prevista"], width=w, label="previsto")
plt.xticks(x, ["Controle", "Tratamento"])
plt.ylabel("Probabilidade média")
plt.title("GLMM binomial: observado vs previsto")
plt.legend()
plt.tight_layout()
plt.savefig(SAIDAS / "glmm_observado_vs_previsto.png", dpi=180)
plt.close()

print(result.summary())
print("\nArquivos exportados em:", SAIDAS)
