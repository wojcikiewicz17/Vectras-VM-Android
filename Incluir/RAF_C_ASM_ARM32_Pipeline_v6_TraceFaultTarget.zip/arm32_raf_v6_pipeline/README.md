# RAF C/ASM ARM32 Pipeline v6

Pacote ARM32/ARMv7 com foco em pipeline realista:
- parser de frame
- reassembly fragmentado
- fault injection determinístico
- cache stress
- telemetria por frame com export CSV/trace
- percentis p50/p90/p99
- modo alvo com contador de ciclos/timer de hardware

## O que é real nesta versão
- **Host executável**: roda pipeline completo com export CSV/trace, percentis e faults.
- **ASM ARM32 validado por objeto**: scalar + NEON montados e disassembláveis.
- **Modo alvo**: hooks reais para AArch32 via `PMCCNTR` ou generic timer, mas dependem de build/execução no hardware alvo.

## Comandos
```bash
make
make test
make bench
make export
make fault
make target
make arm32_objcheck
```

## Fontes de contador no alvo
- `host-clock`: fallback portátil
- `arm-pmccntr`: habilitar com `-DRAF_ARM32_USE_PMCCNTR`
- `arm-generic-timer`: habilitar com `-DRAF_ARM32_USE_GENERIC_TIMER`

## Artefatos gerados
- `out/trace_host.csv`
- `out/trace_host.log`
- `out/fault_trace.csv`
- `out/fault_trace.log`
- `out/target_trace.csv`
- `out/target_trace.log`

## Observação importante
No host, o caminho “ASM” usa **stubs em C** para validar a lógica do pipeline. O ganho de desempenho real de ASM só aparece quando o código for executado em **ARM32 nativo**.
