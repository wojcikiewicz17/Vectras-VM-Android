#!/usr/bin/env bash
set -euo pipefail
make host
./build/host/raf_pipeline_v6 selftest >/tmp/raf_v6_selftest.txt
grep -q "result=OK" /tmp/raf_v6_selftest.txt
./build/host/raf_pipeline_v6 export out/trace_host.csv out/trace_host.log >/tmp/raf_v6_export.txt
test -s out/trace_host.csv
test -s out/trace_host.log
./build/host/raf_pipeline_v6 fault out/fault_trace.csv out/fault_trace.log >/tmp/raf_v6_fault.txt
test -s out/fault_trace.csv
test -s out/fault_trace.log
echo "ok"
