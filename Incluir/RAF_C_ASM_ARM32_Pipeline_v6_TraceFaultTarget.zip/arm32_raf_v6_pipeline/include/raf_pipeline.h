#ifndef RAF_PIPELINE_H
#define RAF_PIPELINE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef uint8_t  raf_u8;
typedef uint16_t raf_u16;
typedef uint32_t raf_u32;
typedef uint64_t raf_u64;
typedef size_t   raf_size_t;

enum {
    RAF_PIPELINE_CYCLES = 56,
    RAF_WORKSET_BYTES = 5 * 1024 * 1024,
    RAF_MAX_PAYLOAD = 1536,
    RAF_MIN_PAYLOAD = 64,
    RAF_FRAME_MAGIC = 0x36464152u, /* RAF6 */
    RAF_FRAME_VERSION = 1u,
    RAF_DESC_RING_CAPACITY = 128,
    RAF_TRACE_PREVIEW = 16
};

typedef enum {
    RAF_PATH_C = 0,
    RAF_PATH_ASM_SCALAR = 1,
    RAF_PATH_ASM_NEON = 2
} RafPath;

typedef enum {
    RAF_FAULT_NONE = 0,
    RAF_FAULT_DROP_FRAGMENT = 1,
    RAF_FAULT_CORRUPT_HEADER = 2,
    RAF_FAULT_CORRUPT_PAYLOAD = 3,
    RAF_FAULT_TRUNCATE_LAST = 4
} RafFaultKind;

typedef enum {
    RAF_COUNTER_HOST_CLOCK = 0,
    RAF_COUNTER_ARM_PMCCNTR = 1,
    RAF_COUNTER_ARM_GENERIC_TIMER = 2
} RafCounterSource;

typedef struct {
    raf_u32 magic;
    raf_u16 version;
    raf_u16 flags;
    raf_u32 header_bytes;
    raf_u32 payload_len;
    raf_u32 seq;
    raf_u32 reserved;
    raf_u32 payload_crc32;
} RafFrameHeader;

typedef struct {
    raf_u32 seq;
    raf_u32 payload_len;
    raf_u32 payload_crc32;
    raf_u32 fold;
    raf_u32 frame_bytes;
    raf_u32 latency_ns;
    raf_u32 latency_cycles;
    raf_u8  fragments;
    raf_u8  fault_kind;
    raf_u16 status;
} RafDescriptor;

typedef struct {
    RafDescriptor slots[RAF_DESC_RING_CAPACITY];
    raf_u32 head;
    raf_u32 tail;
    raf_u32 count;
} RafDescRing;

typedef struct {
    raf_u8 buf[sizeof(RafFrameHeader) + RAF_MAX_PAYLOAD + 32];
    raf_size_t filled;
    raf_size_t expected;
    raf_u32 fragments_seen;
    raf_u32 resets;
} RafReassemblyCtx;

typedef struct {
    raf_u32 enabled;
    raf_u32 period;
    raf_u32 seed;
} RafFaultPolicy;

typedef struct {
    raf_u32 count;
    raf_u32 cap;
    raf_u32 *ns_values;
    raf_u32 *cycle_values;
    raf_u32 p50_ns;
    raf_u32 p90_ns;
    raf_u32 p99_ns;
    raf_u32 p50_cycles;
    raf_u32 p90_cycles;
    raf_u32 p99_cycles;
} RafPercentiles;

typedef struct {
    raf_u64 ns_start;
    raf_u64 ns_stop;
    raf_u64 cyc_start;
    raf_u64 cyc_stop;
    RafCounterSource source;
} RafLatencyStamp;

typedef struct {
    raf_u32 cycles;
    raf_u32 frames_total;
    raf_u32 frames_ok;
    raf_u32 frames_dropped;
    raf_u32 parser_errors;
    raf_u32 crc_errors;
    raf_u32 ring_highwater;
    raf_u32 cache_stress_rounds;
    raf_u32 descriptor_flushes;
    raf_u32 verification_failures;
    raf_u32 reassembly_resets;
    raf_u32 fragment_feeds;
    raf_u32 fragmented_frames;
    raf_u32 fault_injected;
    raf_u32 fault_drop;
    raf_u32 fault_header;
    raf_u32 fault_payload;
    raf_u32 fault_truncate;
    raf_u64 bytes_payload;
    raf_u32 crc_mix;
    raf_u32 fold_mix;
    raf_u32 cache_mix;
    raf_u32 stream_mix;
    raf_u32 trace_rows;
    RafPercentiles pct;
    RafCounterSource counter_source;
} RafPipelineStats;

typedef struct {
    void *csv;
    void *trace;
} RafTraceSink;

void raf_desc_ring_init(RafDescRing *rb);
int raf_desc_ring_push(RafDescRing *rb, const RafDescriptor *desc);
int raf_desc_ring_pop(RafDescRing *rb, RafDescriptor *out);

void raf_reassembly_init(RafReassemblyCtx *ctx);
void raf_reassembly_reset(RafReassemblyCtx *ctx);
int raf_reassembly_feed(RafReassemblyCtx *ctx, const raf_u8 *frag, raf_size_t len,
                        raf_u8 *out_frame, raf_size_t out_cap, raf_size_t *out_frame_bytes,
                        RafFrameHeader *hdr_out);

void raf_fill_pattern(raf_u8 *dst, raf_size_t n, raf_u32 seed);
raf_u32 raf_crc32_update_c(raf_u32 crc, const raf_u8 *data, raf_size_t n);
raf_u32 raf_fold_words_c(const raf_u32 *p, raf_size_t n_words);
void raf_copy_words_c(raf_u32 *dst, const raf_u32 *src, raf_size_t n_words);

raf_u32 raf_fold_words_asm(const raf_u32 *p, raf_u32 n_words);
void raf_copy_words_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words);
void raf_copy_words_neon_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words);

raf_size_t raf_build_frame_stream(raf_u8 *dst, raf_size_t cap, raf_u32 seed, raf_u32 *frames_out);
int raf_parse_frame_header(const raf_u8 *buf, raf_size_t available, RafFrameHeader *out_hdr, raf_size_t *frame_bytes_out);
raf_u32 raf_cache_stress_round(raf_u8 *buf, raf_size_t n, raf_u32 cycle, raf_u32 seed);

void raf_fault_policy_init(RafFaultPolicy *fp, int enabled, raf_u32 period, raf_u32 seed);
RafFaultKind raf_fault_pick(const RafFaultPolicy *fp, raf_u32 seq, raf_u32 cycle, raf_u32 fragments);

void raf_percentiles_init(RafPercentiles *pct, raf_u32 cap, raf_u32 *ns_buf, raf_u32 *cyc_buf);
void raf_percentiles_add(RafPercentiles *pct, raf_u32 ns, raf_u32 cycles);
void raf_percentiles_finalize(RafPercentiles *pct);

void raf_trace_open(RafTraceSink *sink, const char *csv_path, const char *trace_path);
void raf_trace_close(RafTraceSink *sink);
void raf_trace_frame(RafTraceSink *sink, raf_u32 cycle, const RafDescriptor *desc, const char *path_name, const char *status_text);
void raf_trace_event(RafTraceSink *sink, raf_u32 cycle, raf_u32 seq, const char *event_text, RafFaultKind fault);

void raf_latency_stamp_begin(RafLatencyStamp *stamp, int prefer_hw);
void raf_latency_stamp_end(RafLatencyStamp *stamp);
raf_u32 raf_latency_ns_delta(const RafLatencyStamp *stamp);
raf_u32 raf_latency_cycle_delta32(const RafLatencyStamp *stamp);
const char *raf_counter_source_name(RafCounterSource src);

RafPipelineStats raf_run_pipeline(RafPath path, int verbose, RafTraceSink *sink, const RafFaultPolicy *fault_policy, int prefer_hw_counter);
int raf_selftest_pipeline(int verbose);
const char *raf_path_name(RafPath path);
void raf_print_stats(const char *tag, const RafPipelineStats *st, raf_u64 elapsed_ns);

#ifdef __cplusplus
}
#endif

#endif
