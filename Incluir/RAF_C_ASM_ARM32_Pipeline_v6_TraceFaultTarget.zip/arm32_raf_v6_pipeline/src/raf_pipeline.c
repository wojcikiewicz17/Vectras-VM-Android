#include <stdio.h>
#include "raf_pipeline.h"

#include <stdlib.h>
#include <string.h>
#include <time.h>

#define RAF_PERCENTILE_CAP 16384u
#define RAF_REASSEMBLY_COMPLETE 1
#define RAF_REASSEMBLY_NEED_MORE 0
#define RAF_REASSEMBLY_ERROR (-1)

static raf_u32 raf_rotl32(raf_u32 x, unsigned r) {
    return (x << r) | (x >> ((32u - r) & 31u));
}

static raf_u32 raf_read_le32(const raf_u8 *p) {
    return ((raf_u32)p[0]) | ((raf_u32)p[1] << 8) | ((raf_u32)p[2] << 16) | ((raf_u32)p[3] << 24);
}

static void raf_write_le32(raf_u8 *p, raf_u32 v) {
    p[0] = (raf_u8)(v & 0xffu);
    p[1] = (raf_u8)((v >> 8) & 0xffu);
    p[2] = (raf_u8)((v >> 16) & 0xffu);
    p[3] = (raf_u8)((v >> 24) & 0xffu);
}

static void raf_write_le16(raf_u8 *p, raf_u16 v) {
    p[0] = (raf_u8)(v & 0xffu);
    p[1] = (raf_u8)((v >> 8) & 0xffu);
}

static void *raf_aligned_alloc64(raf_size_t nbytes) {
#if defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 201112L)
    raf_size_t rounded = (nbytes + 63u) & ~(raf_size_t)63u;
    return aligned_alloc(64u, rounded);
#else
    return malloc(nbytes);
#endif
}

static void raf_aligned_free64(void *p) {
    free(p);
}

static void raf_copy_dispatch(RafPath path, raf_u32 *dst, const raf_u32 *src, raf_u32 n_words) {
    switch (path) {
        case RAF_PATH_ASM_NEON:
            raf_copy_words_neon_asm(dst, src, n_words);
            break;
        case RAF_PATH_ASM_SCALAR:
            raf_copy_words_asm(dst, src, n_words);
            break;
        case RAF_PATH_C:
        default:
            raf_copy_words_c(dst, src, n_words);
            break;
    }
}

static raf_u32 raf_fold_dispatch(RafPath path, const raf_u32 *src, raf_u32 n_words) {
    switch (path) {
        case RAF_PATH_ASM_NEON:
        case RAF_PATH_ASM_SCALAR:
            return raf_fold_words_asm(src, n_words);
        case RAF_PATH_C:
        default:
            return raf_fold_words_c(src, n_words);
    }
}

static raf_u32 raf_cycle_budget_bytes(raf_u32 cycle) {
    static const raf_u32 budgets[] = {32768u, 49152u, 65536u, 81920u, 98304u, 114688u, 131072u, 163840u};
    return budgets[cycle % (sizeof(budgets) / sizeof(budgets[0]))];
}

static int raf_u32_cmp(const void *a, const void *b) {
    raf_u32 x = *(const raf_u32 *)a;
    raf_u32 y = *(const raf_u32 *)b;
    return (x > y) - (x < y);
}

static raf_u32 raf_percentile_from_sorted(const raf_u32 *buf, raf_u32 count, double p) {
    if (count == 0u) return 0u;
    raf_u32 idx = (raf_u32)((double)(count - 1u) * p + 0.5);
    if (idx >= count) idx = count - 1u;
    return buf[idx];
}

void raf_desc_ring_init(RafDescRing *rb) { memset(rb, 0, sizeof(*rb)); }

int raf_desc_ring_push(RafDescRing *rb, const RafDescriptor *desc) {
    if (rb->count >= RAF_DESC_RING_CAPACITY) return -1;
    rb->slots[rb->head] = *desc;
    rb->head = (rb->head + 1u) % RAF_DESC_RING_CAPACITY;
    rb->count++;
    return 0;
}

int raf_desc_ring_pop(RafDescRing *rb, RafDescriptor *out) {
    if (rb->count == 0u) return -1;
    *out = rb->slots[rb->tail];
    rb->tail = (rb->tail + 1u) % RAF_DESC_RING_CAPACITY;
    rb->count--;
    return 0;
}

void raf_reassembly_init(RafReassemblyCtx *ctx) { memset(ctx, 0, sizeof(*ctx)); }
void raf_reassembly_reset(RafReassemblyCtx *ctx) { ctx->filled = ctx->expected = ctx->fragments_seen = 0u; ctx->resets++; }

void raf_fill_pattern(raf_u8 *dst, raf_size_t n, raf_u32 seed) {
    raf_u32 x = seed ^ 0x9e3779b9u;
    for (raf_size_t i = 0; i < n; ++i) {
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        dst[i] = (raf_u8)((x + (raf_u32)(i * 17u)) & 0xffu);
    }
}

raf_u32 raf_crc32_update_c(raf_u32 crc, const raf_u8 *data, raf_size_t n) {
    crc = ~crc;
    for (raf_size_t i = 0; i < n; ++i) {
        crc ^= data[i];
        for (unsigned bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
        }
    }
    return ~crc;
}

raf_u32 raf_fold_words_c(const raf_u32 *p, raf_size_t n_words) {
    raf_u32 acc = 0u;
    for (raf_size_t i = 0; i < n_words; ++i) acc ^= p[i];
    return acc;
}

void raf_copy_words_c(raf_u32 *dst, const raf_u32 *src, raf_size_t n_words) {
    for (raf_size_t i = 0; i < n_words; ++i) dst[i] = src[i];
}

const char *raf_path_name(RafPath path) {
    switch (path) {
        case RAF_PATH_ASM_SCALAR: return "asm-scalar";
        case RAF_PATH_ASM_NEON: return "asm-neon";
        case RAF_PATH_C:
        default: return "c";
    }
}

void raf_fault_policy_init(RafFaultPolicy *fp, int enabled, raf_u32 period, raf_u32 seed) {
    fp->enabled = enabled ? 1u : 0u;
    fp->period = period ? period : 13u;
    fp->seed = seed;
}

RafFaultKind raf_fault_pick(const RafFaultPolicy *fp, raf_u32 seq, raf_u32 cycle, raf_u32 fragments) {
    raf_u32 mix;
    if (!fp || !fp->enabled) return RAF_FAULT_NONE;
    if (((seq + 1u + cycle) % fp->period) != 0u) return RAF_FAULT_NONE;
    mix = (seq * 1103515245u) ^ (cycle * 12345u) ^ fp->seed;
    switch ((mix >> 3) & 3u) {
        case 0u: return fragments > 1u ? RAF_FAULT_DROP_FRAGMENT : RAF_FAULT_CORRUPT_PAYLOAD;
        case 1u: return RAF_FAULT_CORRUPT_HEADER;
        case 2u: return RAF_FAULT_CORRUPT_PAYLOAD;
        default: return fragments > 1u ? RAF_FAULT_TRUNCATE_LAST : RAF_FAULT_CORRUPT_PAYLOAD;
    }
}

void raf_percentiles_init(RafPercentiles *pct, raf_u32 cap, raf_u32 *ns_buf, raf_u32 *cyc_buf) {
    memset(pct, 0, sizeof(*pct));
    pct->cap = cap;
    pct->ns_values = ns_buf;
    pct->cycle_values = cyc_buf;
}

void raf_percentiles_add(RafPercentiles *pct, raf_u32 ns, raf_u32 cycles) {
    if (pct->count >= pct->cap) return;
    pct->ns_values[pct->count] = ns;
    pct->cycle_values[pct->count] = cycles;
    pct->count++;
}

void raf_percentiles_finalize(RafPercentiles *pct) {
    if (pct->count == 0u) return;
    qsort(pct->ns_values, pct->count, sizeof(raf_u32), raf_u32_cmp);
    qsort(pct->cycle_values, pct->count, sizeof(raf_u32), raf_u32_cmp);
    pct->p50_ns = raf_percentile_from_sorted(pct->ns_values, pct->count, 0.50);
    pct->p90_ns = raf_percentile_from_sorted(pct->ns_values, pct->count, 0.90);
    pct->p99_ns = raf_percentile_from_sorted(pct->ns_values, pct->count, 0.99);
    pct->p50_cycles = raf_percentile_from_sorted(pct->cycle_values, pct->count, 0.50);
    pct->p90_cycles = raf_percentile_from_sorted(pct->cycle_values, pct->count, 0.90);
    pct->p99_cycles = raf_percentile_from_sorted(pct->cycle_values, pct->count, 0.99);
}

void raf_trace_open(RafTraceSink *sink, const char *csv_path, const char *trace_path) {
    FILE *csv = NULL;
    FILE *trace = NULL;
    if (!sink) return;
    memset(sink, 0, sizeof(*sink));
    if (csv_path) {
        csv = fopen(csv_path, "w");
        sink->csv = csv;
        if (csv) {
            fprintf(csv, "cycle,seq,path,status,fault,fragments,payload_len,frame_bytes,crc32,fold,latency_ns,latency_cycles\n");
        }
    }
    if (trace_path) {
        trace = fopen(trace_path, "w");
        sink->trace = trace;
        if (trace) {
            fprintf(trace, "# raf pipeline v6 trace\n");
        }
    }
}

void raf_trace_close(RafTraceSink *sink) {
    if (!sink) return;
    if (sink->csv) fclose((FILE *)sink->csv);
    if (sink->trace) fclose((FILE *)sink->trace);
    sink->csv = sink->trace = NULL;
}

void raf_trace_frame(RafTraceSink *sink, raf_u32 cycle, const RafDescriptor *desc, const char *path_name, const char *status_text) {
    FILE *csv;
    FILE *trace;
    if (!sink) return;
    csv = (FILE *)sink->csv;
    trace = (FILE *)sink->trace;
    if (csv) {
        fprintf(csv, "%u,%u,%s,%s,%u,%u,%u,%u,%08x,%08x,%u,%u\n",
                cycle, desc->seq, path_name, status_text, desc->fault_kind, desc->fragments,
                desc->payload_len, desc->frame_bytes, desc->payload_crc32, desc->fold,
                desc->latency_ns, desc->latency_cycles);
    }
    if (trace) {
        fprintf(trace, "[frame] cycle=%02u seq=%04u status=%s fault=%u frags=%u len=%u crc=%08x fold=%08x lat_ns=%u lat_cyc=%u\n",
                cycle, desc->seq, status_text, desc->fault_kind, desc->fragments,
                desc->payload_len, desc->payload_crc32, desc->fold, desc->latency_ns, desc->latency_cycles);
    }
}

void raf_trace_event(RafTraceSink *sink, raf_u32 cycle, raf_u32 seq, const char *event_text, RafFaultKind fault) {
    FILE *trace;
    if (!sink) return;
    trace = (FILE *)sink->trace;
    if (trace) {
        fprintf(trace, "[event] cycle=%02u seq=%04u event=%s fault=%u\n", cycle, seq, event_text, (unsigned)fault);
    }
}

raf_size_t raf_build_frame_stream(raf_u8 *dst, raf_size_t cap, raf_u32 seed, raf_u32 *frames_out) {
    raf_size_t off = 0u;
    raf_u32 seq = 0u;
    raf_u32 state = seed ^ 0xa5a55a5au;
    while (off + sizeof(RafFrameHeader) + RAF_MIN_PAYLOAD <= cap) {
        raf_u32 payload_len;
        raf_u8 *hdr = dst + off;
        raf_u8 *payload;
        state = state * 1664525u + 1013904223u;
        payload_len = RAF_MIN_PAYLOAD + (state % (RAF_MAX_PAYLOAD - RAF_MIN_PAYLOAD + 1u));
        payload_len = (payload_len + 3u) & ~3u;
        if (off + sizeof(RafFrameHeader) + payload_len > cap) break;
        payload = hdr + sizeof(RafFrameHeader);
        raf_fill_pattern(payload, payload_len, seed ^ seq ^ payload_len);
        raf_write_le32(hdr + 0, RAF_FRAME_MAGIC);
        raf_write_le16(hdr + 4, (raf_u16)RAF_FRAME_VERSION);
        raf_write_le16(hdr + 6, (raf_u16)(seq & 0x3u));
        raf_write_le32(hdr + 8, (raf_u32)sizeof(RafFrameHeader));
        raf_write_le32(hdr + 12, payload_len);
        raf_write_le32(hdr + 16, seq);
        raf_write_le32(hdr + 20, state ^ 0x55aa00ffu);
        raf_write_le32(hdr + 24, raf_crc32_update_c(0u, payload, payload_len));
        off += sizeof(RafFrameHeader) + payload_len;
        seq++;
    }
    if (frames_out) *frames_out = seq;
    return off;
}

int raf_parse_frame_header(const raf_u8 *buf, raf_size_t available, RafFrameHeader *out_hdr, raf_size_t *frame_bytes_out) {
    if (available < sizeof(RafFrameHeader)) return -1;
    out_hdr->magic = raf_read_le32(buf + 0);
    out_hdr->version = (raf_u16)(buf[4] | (buf[5] << 8));
    out_hdr->flags = (raf_u16)(buf[6] | (buf[7] << 8));
    out_hdr->header_bytes = raf_read_le32(buf + 8);
    out_hdr->payload_len = raf_read_le32(buf + 12);
    out_hdr->seq = raf_read_le32(buf + 16);
    out_hdr->reserved = raf_read_le32(buf + 20);
    out_hdr->payload_crc32 = raf_read_le32(buf + 24);

    if (out_hdr->magic != RAF_FRAME_MAGIC || out_hdr->version != RAF_FRAME_VERSION) return -2;
    if (out_hdr->header_bytes != sizeof(RafFrameHeader)) return -3;
    if (out_hdr->payload_len < RAF_MIN_PAYLOAD || out_hdr->payload_len > RAF_MAX_PAYLOAD) return -4;
    if ((out_hdr->payload_len & 3u) != 0u) return -5;
    if (available < sizeof(RafFrameHeader) + out_hdr->payload_len) return -6;
    if (frame_bytes_out) *frame_bytes_out = sizeof(RafFrameHeader) + out_hdr->payload_len;
    return 0;
}

int raf_reassembly_feed(RafReassemblyCtx *ctx, const raf_u8 *frag, raf_size_t len,
                        raf_u8 *out_frame, raf_size_t out_cap, raf_size_t *out_frame_bytes,
                        RafFrameHeader *hdr_out) {
    if (ctx->filled + len > sizeof(ctx->buf)) {
        raf_reassembly_reset(ctx);
        return RAF_REASSEMBLY_ERROR;
    }
    memcpy(ctx->buf + ctx->filled, frag, len);
    ctx->filled += len;
    ctx->fragments_seen++;
    if (ctx->expected == 0u && ctx->filled >= sizeof(RafFrameHeader)) {
        raf_size_t frame_bytes = 0u;
        int rc = raf_parse_frame_header(ctx->buf, ctx->filled, hdr_out, &frame_bytes);
        if (rc == -6) {
            return RAF_REASSEMBLY_NEED_MORE;
        }
        if (rc != 0) {
            raf_reassembly_reset(ctx);
            return RAF_REASSEMBLY_ERROR;
        }
        ctx->expected = frame_bytes;
        if (ctx->expected > sizeof(ctx->buf)) {
            raf_reassembly_reset(ctx);
            return RAF_REASSEMBLY_ERROR;
        }
    }
    if (ctx->expected != 0u && ctx->filled >= ctx->expected) {
        if (ctx->filled != ctx->expected || out_cap < ctx->expected) {
            raf_reassembly_reset(ctx);
            return RAF_REASSEMBLY_ERROR;
        }
        memcpy(out_frame, ctx->buf, ctx->expected);
        *out_frame_bytes = ctx->expected;
        raf_reassembly_init(ctx);
        return RAF_REASSEMBLY_COMPLETE;
    }
    return RAF_REASSEMBLY_NEED_MORE;
}

raf_u32 raf_cache_stress_round(raf_u8 *buf, raf_size_t n, raf_u32 cycle, raf_u32 seed) {
    static const raf_size_t strides[] = {64u, 96u, 128u, 160u, 192u, 256u, 320u, 384u, 512u};
    raf_size_t stride = strides[cycle % (sizeof(strides) / sizeof(strides[0]))];
    raf_u32 acc = seed ^ (cycle * 0x9e3779b9u);
    for (raf_size_t pass = 0; pass < 3u; ++pass) {
        for (raf_size_t i = (cycle * 17u + pass * 13u) % stride; i < n; i += stride) {
            acc ^= buf[i];
            buf[i] ^= (raf_u8)(acc + i + pass);
            acc = raf_rotl32(acc + buf[i] + (raf_u32)i, 5u);
        }
    }
    return acc;
}

static void raf_mutate_fragment(raf_u8 *frag, raf_size_t frag_len, raf_size_t frag_index, raf_u32 total_frags, RafFaultKind fk) {
    if (frag_len == 0u) return;
    switch (fk) {
        case RAF_FAULT_CORRUPT_HEADER:
            if (frag_index == 0u && frag_len > 5u) frag[4] ^= 0x7u;
            break;
        case RAF_FAULT_CORRUPT_PAYLOAD:
            if (frag_index == total_frags / 2u) frag[frag_len / 2u] ^= 0x5au;
            break;
        default:
            break;
    }
}

static void raf_fault_bump(RafPipelineStats *st, RafFaultKind fk) {
    if (fk == RAF_FAULT_NONE) return;
    st->fault_injected++;
    switch (fk) {
        case RAF_FAULT_DROP_FRAGMENT: st->fault_drop++; break;
        case RAF_FAULT_CORRUPT_HEADER: st->fault_header++; break;
        case RAF_FAULT_CORRUPT_PAYLOAD: st->fault_payload++; break;
        case RAF_FAULT_TRUNCATE_LAST: st->fault_truncate++; break;
        default: break;
    }
}

static void raf_descriptor_zero(RafDescriptor *d) { memset(d, 0, sizeof(*d)); }

RafPipelineStats raf_run_pipeline(RafPath path, int verbose, RafTraceSink *sink, const RafFaultPolicy *fault_policy, int prefer_hw_counter) {
    RafPipelineStats st;
    RafDescRing ring;
    RafReassemblyCtx reas;
    raf_u8 *stream = NULL;
    raf_u8 *stage = NULL;
    raf_u8 *cache = NULL;
    raf_u8 *assembled = NULL;
    raf_u32 *pct_ns = NULL;
    raf_u32 *pct_cyc = NULL;
    raf_size_t stream_bytes = 0u;
    raf_u32 total_frames = 0u;
    raf_size_t cursor = 0u;
    int have_last_seq = 0;
    raf_u32 last_seq = 0u;

    memset(&st, 0, sizeof(st));
    raf_desc_ring_init(&ring);
    raf_reassembly_init(&reas);

    stream = (raf_u8 *)raf_aligned_alloc64(RAF_WORKSET_BYTES);
    stage = (raf_u8 *)raf_aligned_alloc64(RAF_MAX_PAYLOAD);
    cache = (raf_u8 *)raf_aligned_alloc64(1024u * 1024u);
    assembled = (raf_u8 *)raf_aligned_alloc64(sizeof(RafFrameHeader) + RAF_MAX_PAYLOAD + 32u);
    pct_ns = (raf_u32 *)malloc(sizeof(raf_u32) * RAF_PERCENTILE_CAP);
    pct_cyc = (raf_u32 *)malloc(sizeof(raf_u32) * RAF_PERCENTILE_CAP);
    if (!stream || !stage || !cache || !assembled || !pct_ns || !pct_cyc) {
        st.verification_failures = 0xffffffffu;
        goto done;
    }

    raf_percentiles_init(&st.pct, RAF_PERCENTILE_CAP, pct_ns, pct_cyc);
    memset(stage, 0, RAF_MAX_PAYLOAD);
    raf_fill_pattern(cache, 1024u * 1024u, 0x13579bdfu);
    stream_bytes = raf_build_frame_stream(stream, RAF_WORKSET_BYTES, 0x2468ace1u, &total_frames);
    st.stream_mix = raf_crc32_update_c(0u, stream, stream_bytes > 4096u ? 4096u : stream_bytes);

    for (raf_u32 cycle = 0; cycle < RAF_PIPELINE_CYCLES; ++cycle) {
        raf_u32 budget = raf_cycle_budget_bytes(cycle);
        raf_u32 spent = 0u;
        st.cache_mix ^= raf_cache_stress_round(cache, 1024u * 1024u, cycle, 0x10203040u ^ cycle);
        st.cache_stress_rounds++;
        st.cycles++;
        while (spent < budget && cursor + sizeof(RafFrameHeader) <= stream_bytes) {
            RafFrameHeader src_hdr, hdr;
            raf_size_t frame_bytes = 0u;
            raf_u8 *frame = stream + cursor;
            raf_u32 fragments;
            RafFaultKind fk;
            raf_size_t pos = 0u;
            raf_size_t assembled_bytes = 0u;
            int completed = 0;
            int frame_failed = 0;
            RafDescriptor desc;
            raf_descriptor_zero(&desc);

            if (raf_parse_frame_header(frame, stream_bytes - cursor, &src_hdr, &frame_bytes) != 0) {
                st.parser_errors++;
                st.verification_failures++;
                break;
            }
            if (spent + (raf_u32)frame_bytes > budget && spent > 0u) break;

            fragments = 1u + ((src_hdr.seq + cycle) % 4u);
            if (fragments > 1u) st.fragmented_frames++;
            fk = raf_fault_pick(fault_policy, src_hdr.seq, cycle, fragments);
            raf_fault_bump(&st, fk);
            if (fk != RAF_FAULT_NONE) raf_trace_event(sink, cycle, src_hdr.seq, "fault-injected", fk);

            for (raf_u32 fi = 0u; fi < fragments; ++fi) {
                raf_size_t remain = frame_bytes - pos;
                raf_size_t frag_len = (fi + 1u == fragments) ? remain : ((frame_bytes / fragments + 3u) & ~3u);
                raf_u8 frag_tmp[sizeof(RafFrameHeader) + RAF_MAX_PAYLOAD + 32u];
                int rc;
                if (frag_len > remain) frag_len = remain;
                if (fk == RAF_FAULT_DROP_FRAGMENT && fi == 1u && fragments > 1u) {
                    st.fragment_feeds++;
                    frame_failed = 1;
                    raf_trace_event(sink, cycle, src_hdr.seq, "drop-fragment", fk);
                    pos += frag_len;
                    continue;
                }
                if (fk == RAF_FAULT_TRUNCATE_LAST && fi + 1u == fragments && frag_len > 8u) {
                    frag_len -= 8u;
                    frame_failed = 1;
                    raf_trace_event(sink, cycle, src_hdr.seq, "truncate-last", fk);
                }
                memcpy(frag_tmp, frame + pos, frag_len);
                raf_mutate_fragment(frag_tmp, frag_len, fi, fragments, fk);
                rc = raf_reassembly_feed(&reas, frag_tmp, frag_len, assembled, sizeof(RafFrameHeader) + RAF_MAX_PAYLOAD + 32u, &assembled_bytes, &hdr);
                st.fragment_feeds++;
                if (rc == RAF_REASSEMBLY_ERROR) {
                    st.parser_errors++;
                    st.reassembly_resets = reas.resets;
                    frame_failed = 1;
                    raf_trace_event(sink, cycle, src_hdr.seq, "reassembly-error", fk);
                    break;
                } else if (rc == RAF_REASSEMBLY_COMPLETE) {
                    completed = 1;
                    break;
                }
                pos += ((fi + 1u == fragments) ? remain : ((frame_bytes / fragments + 3u) & ~3u));
                if (pos > frame_bytes) pos = frame_bytes;
            }

            if (!completed) {
                if (reas.filled != 0u || frame_failed) {
                    raf_reassembly_reset(&reas);
                    st.reassembly_resets = reas.resets;
                }
                st.frames_dropped++;
                st.frames_total++;
                desc.seq = src_hdr.seq;
                desc.payload_len = src_hdr.payload_len;
                desc.frame_bytes = (raf_u32)frame_bytes;
                desc.fragments = (raf_u8)fragments;
                desc.fault_kind = (raf_u8)fk;
                desc.status = 1u;
                raf_trace_frame(sink, cycle, &desc, raf_path_name(path), "dropped");
                st.trace_rows++;
                spent += (raf_u32)frame_bytes;
                cursor += frame_bytes;
                if (cursor >= stream_bytes) { cursor = 0u; have_last_seq = 0; }
                continue;
            }

            {
                raf_u8 *payload = assembled + hdr.header_bytes;
                RafLatencyStamp stamp;
                raf_u32 calc_crc;
                raf_u32 fold;
                raf_latency_stamp_begin(&stamp, prefer_hw_counter);
                raf_copy_dispatch(path, (raf_u32 *)stage, (const raf_u32 *)payload, hdr.payload_len / 4u);
                fold = raf_fold_dispatch(path, (const raf_u32 *)stage, hdr.payload_len / 4u);
                calc_crc = raf_crc32_update_c(0u, stage, hdr.payload_len);
                raf_latency_stamp_end(&stamp);

                desc.seq = hdr.seq;
                desc.payload_len = hdr.payload_len;
                desc.payload_crc32 = calc_crc;
                desc.fold = fold;
                desc.frame_bytes = (raf_u32)assembled_bytes;
                desc.latency_ns = raf_latency_ns_delta(&stamp);
                desc.latency_cycles = raf_latency_cycle_delta32(&stamp);
                desc.fragments = (raf_u8)fragments;
                desc.fault_kind = (raf_u8)fk;
                desc.status = 0u;
                st.counter_source = stamp.source;

                st.frames_total++;
                st.bytes_payload += hdr.payload_len;
                st.crc_mix ^= raf_rotl32(calc_crc + hdr.seq, hdr.seq & 31u);
                st.fold_mix ^= raf_rotl32(fold ^ hdr.payload_len, (hdr.seq * 3u) & 31u);
                raf_percentiles_add(&st.pct, desc.latency_ns, desc.latency_cycles);

                if (calc_crc != hdr.payload_crc32) {
                    st.crc_errors++;
                    st.verification_failures += (fk == RAF_FAULT_CORRUPT_PAYLOAD) ? 0u : 1u;
                    desc.status = 2u;
                } else {
                    st.frames_ok++;
                }
                if (memcmp(stage, payload, hdr.payload_len) != 0) {
                    st.verification_failures++;
                    desc.status = 3u;
                }
                if (have_last_seq && hdr.seq != last_seq + 1u) {
                    if (fk == RAF_FAULT_DROP_FRAGMENT || fk == RAF_FAULT_TRUNCATE_LAST) {
                        /* acceptable discontinuity under injected drops */
                    } else {
                        st.verification_failures++;
                    }
                }
                last_seq = hdr.seq;
                have_last_seq = 1;

                if (raf_desc_ring_push(&ring, &desc) != 0) {
                    RafDescriptor out;
                    if (raf_desc_ring_pop(&ring, &out) == 0) st.descriptor_flushes++;
                    if (raf_desc_ring_push(&ring, &desc) != 0) {
                        st.frames_dropped++;
                        st.verification_failures++;
                    }
                }
                if (ring.count > st.ring_highwater) st.ring_highwater = ring.count;
                if ((hdr.seq & 7u) == 7u) {
                    RafDescriptor out;
                    if (raf_desc_ring_pop(&ring, &out) == 0) st.descriptor_flushes++;
                }
                raf_trace_frame(sink, cycle, &desc, raf_path_name(path), desc.status == 0u ? "ok" : (desc.status == 2u ? "crc-error" : "verify-error"));
                st.trace_rows++;
                if (verbose) {
                    fprintf(stdout, "[pipeline] cycle=%02u seq=%04u len=%4u frags=%u fault=%u crc=%08x fold=%08x lat_ns=%u lat_cyc=%u\n",
                            cycle, hdr.seq, hdr.payload_len, desc.fragments, desc.fault_kind,
                            calc_crc, fold, desc.latency_ns, desc.latency_cycles);
                }
            }

            spent += (raf_u32)frame_bytes;
            cursor += frame_bytes;
            if (cursor >= stream_bytes) {
                cursor = 0u;
                have_last_seq = 0;
            }
        }
    }

    while (ring.count != 0u) {
        RafDescriptor out;
        if (raf_desc_ring_pop(&ring, &out) == 0) st.descriptor_flushes++;
    }
    st.reassembly_resets = reas.resets;
    raf_percentiles_finalize(&st.pct);

done:
    raf_aligned_free64(stream);
    raf_aligned_free64(stage);
    raf_aligned_free64(cache);
    raf_aligned_free64(assembled);
    free(pct_ns);
    free(pct_cyc);
    return st;
}

int raf_selftest_pipeline(int verbose) {
    RafFaultPolicy clean;
    RafPipelineStats cst, ast;
    int ok = 1;
    raf_fault_policy_init(&clean, 0, 0u, 0u);
    cst = raf_run_pipeline(RAF_PATH_C, 0, NULL, &clean, 0);
    ast = raf_run_pipeline(RAF_PATH_ASM_SCALAR, 0, NULL, &clean, 0);
    if (cst.frames_total != ast.frames_total || cst.frames_ok != ast.frames_ok) ok = 0;
    if (cst.bytes_payload != ast.bytes_payload) ok = 0;
    if (cst.crc_mix != ast.crc_mix || cst.fold_mix != ast.fold_mix) ok = 0;
    if (cst.cache_mix != ast.cache_mix || cst.stream_mix != ast.stream_mix) ok = 0;
    if (cst.verification_failures != 0u || ast.verification_failures != 0u) ok = 0;
    if (cst.pct.p50_ns == 0u || ast.pct.p50_ns == 0u) ok = 0;
    if (verbose) {
        fprintf(stdout, "[selftest] c:   frames=%u ok=%u bytes=%llu crc_mix=%08x fold_mix=%08x fail=%u p50=%u p90=%u p99=%u\n",
                cst.frames_total, cst.frames_ok, (unsigned long long)cst.bytes_payload,
                cst.crc_mix, cst.fold_mix, cst.verification_failures,
                cst.pct.p50_ns, cst.pct.p90_ns, cst.pct.p99_ns);
        fprintf(stdout, "[selftest] asm: frames=%u ok=%u bytes=%llu crc_mix=%08x fold_mix=%08x fail=%u p50=%u p90=%u p99=%u\n",
                ast.frames_total, ast.frames_ok, (unsigned long long)ast.bytes_payload,
                ast.crc_mix, ast.fold_mix, ast.verification_failures,
                ast.pct.p50_ns, ast.pct.p90_ns, ast.pct.p99_ns);
        fprintf(stdout, "[selftest] result=%s\n", ok ? "OK" : "FAIL");
    }
    return ok ? 0 : 1;
}

void raf_print_stats(const char *tag, const RafPipelineStats *st, raf_u64 elapsed_ns) {
    FILE *fp = stdout;
    double mib = (double)st->bytes_payload / (1024.0 * 1024.0);
    double sec = elapsed_ns ? ((double)elapsed_ns / 1e9) : 0.0;
    double mibps = sec > 0.0 ? mib / sec : 0.0;
    fprintf(fp, "[%s] cycles=%u frames_total=%u ok=%u dropped=%u parser_err=%u crc_err=%u\n",
            tag, st->cycles, st->frames_total, st->frames_ok, st->frames_dropped, st->parser_errors, st->crc_errors);
    fprintf(fp, "[%s] bytes_payload=%llu ring_highwater=%u cache_rounds=%u flushes=%u fail=%u\n",
            tag, (unsigned long long)st->bytes_payload, st->ring_highwater, st->cache_stress_rounds,
            st->descriptor_flushes, st->verification_failures);
    fprintf(fp, "[%s] fragments=%u fragmented_frames=%u reas_resets=%u faults=%u(drop=%u hdr=%u payload=%u trunc=%u)\n",
            tag, st->fragment_feeds, st->fragmented_frames, st->reassembly_resets, st->fault_injected,
            st->fault_drop, st->fault_header, st->fault_payload, st->fault_truncate);
    fprintf(fp, "[%s] crc_mix=%08x fold_mix=%08x cache_mix=%08x stream_mix=%08x counter=%s rows=%u\n",
            tag, st->crc_mix, st->fold_mix, st->cache_mix, st->stream_mix, raf_counter_source_name(st->counter_source), st->trace_rows);
    fprintf(fp, "[%s] p50_ns=%u p90_ns=%u p99_ns=%u p50_cyc=%u p90_cyc=%u p99_cyc=%u\n",
            tag, st->pct.p50_ns, st->pct.p90_ns, st->pct.p99_ns, st->pct.p50_cycles, st->pct.p90_cycles, st->pct.p99_cycles);
    if (elapsed_ns) {
        fprintf(fp, "[%s] elapsed_ns=%llu throughput_mib_s=%.2f\n",
                tag, (unsigned long long)elapsed_ns, mibps);
    }
}
