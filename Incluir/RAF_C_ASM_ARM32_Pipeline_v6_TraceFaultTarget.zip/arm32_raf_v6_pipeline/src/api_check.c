#include "raf_pipeline.h"

int raf_api_check(void) {
    RafDescRing rb;
    RafFrameHeader hdr;
    RafDescriptor desc;
    RafPipelineStats st;
    RafReassemblyCtx ctx;
    RafFaultPolicy fp;
    RafTraceSink sink;
    raf_desc_ring_init(&rb);
    raf_reassembly_init(&ctx);
    raf_fault_policy_init(&fp, 1, 11u, 0x1234u);
    (void)rb; (void)hdr; (void)desc; (void)st; (void)sink;
    return 0;
}
