# Comandos v6

```bash
make test
make bench
make export
make fault
make target
make arm32_objcheck
```

### Inspecionar traces
```bash
head -n 20 out/trace_host.csv
head -n 20 out/fault_trace.log
```
