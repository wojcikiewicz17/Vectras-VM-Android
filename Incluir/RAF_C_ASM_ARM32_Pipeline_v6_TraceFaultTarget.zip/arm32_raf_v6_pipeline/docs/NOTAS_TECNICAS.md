# Notas técnicas v6

## Novidades
1. Export CSV por frame.
2. Trace textual por frame/evento.
3. Percentis p50/p90/p99 em ns e ciclos.
4. Fault injection determinístico.
5. Reassembly fragmentado com reset em erro.
6. Hooks de temporização para alvo ARM32.

## Modelo de fault injection
- `DROP_FRAGMENT`
- `CORRUPT_HEADER`
- `CORRUPT_PAYLOAD`
- `TRUNCATE_LAST`

## Semântica de verificação
- `selftest` roda sem faults e exige equivalência estrutural entre C e asm-stub.
- `fault` aceita drops/corruptions como parte do cenário de teste; o objetivo é medir reação do parser/reassembly.

## Contador de ciclos no alvo
### PMCCNTR
Build exemplo:
```bash
make CFLAGS="-O3 -std=c11 -Wall -Wextra -Wpedantic -DRAF_ARM32_USE_PMCCNTR"
```

### Generic timer
Build exemplo:
```bash
make CFLAGS="-O3 -std=c11 -Wall -Wextra -Wpedantic -DRAF_ARM32_USE_GENERIC_TIMER"
```

## Caveat
A leitura de `PMCCNTR` em user space depende de permissão/configuração do kernel/SoC.
