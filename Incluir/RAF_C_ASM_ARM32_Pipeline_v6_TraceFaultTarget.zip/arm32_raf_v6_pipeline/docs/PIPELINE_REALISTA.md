# Pipeline realista v6

Fluxo por frame:
1. stream linear -> frame source
2. fragmentação em 1..4 pedaços
3. reassembly incremental
4. parse e validação
5. copy/fold path (C ou ASM)
6. CRC do payload
7. cache stress por ciclo
8. descritor em ring buffer
9. telemetria por frame
10. export CSV/trace
