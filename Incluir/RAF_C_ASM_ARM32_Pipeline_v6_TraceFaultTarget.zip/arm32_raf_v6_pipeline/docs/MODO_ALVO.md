# Modo alvo: latência real no ARM32

Esta v6 inclui dois caminhos focados em contador de hardware no alvo:

- `RAF_ARM32_USE_PMCCNTR`
- `RAF_ARM32_USE_GENERIC_TIMER`

## PMCCNTR
Leitura AArch32 via:
- `mrc p15, 0, <Rt>, c9, c13, 0`

Uso recomendado quando o kernel/SoC permitir acesso user-space ao PMU.

## Generic timer
Leitura AArch32 via:
- `mrrc p15, 1, <Rt>, <Rt2>, c14`

Uso recomendado quando o SoC expõe generic timer no modo de execução desejado.

## Comportamento atual no host
Sem hardware ARM32 real, o binário cai em `host-clock`.

## Comportamento esperado no alvo
- `latency_ns`: via clock/timestamp de sistema
- `latency_cycles`: via PMCCNTR ou generic timer
- percentis p50/p90/p99 ficam disponíveis tanto em ns quanto em ciclos
