# RAF Hot Path ARM32 N55

Pacote C/ASM para **ARM32 Linux / ARMv7-A (AAPCS/EABI hard-float)** focado em:

- **CRC32** em fluxo de dados
- **ring buffer** de metadados
- **copy hot path** em ASM ARM32
- **fold/XOR** em ASM ARM32
- **harness determinístico de 56 ciclos**
- **working set de 5 MiB**

## Interpretação pé no chão do perfil pedido

- **56 ciclos** → harness fixo de estresse/validação
- **5 m³** → convertido para **janela de trabalho de 5 MiB**, para virar parâmetro computacional real
- **N55 / nióbio / coerente / sináptico / dinâmico** → tratados como **codinome do perfil**, não como afirmação física

## O que o pacote faz

Em cada ciclo o runner:

1. escolhe um chunk determinístico
2. copia palavras 32-bit do buffer de origem para destino
3. calcula **CRC32** do trecho copiado
4. calcula **fold XOR 32-bit** do mesmo trecho
5. empilha metadados no ring buffer
6. drena/valida parte da fila
7. mistura os acumuladores finais


> **Nota:** o benchmark incluído no pacote roda como **simulador host** usando stubs C. O ganho real de ASM precisa ser medido em hardware ARM32 nativo.

## Build local de lógica (host simulator)

```bash
make host
make run
make bench
make test
```

## Checagem ARM32 do ASM

```bash
make arm32_objcheck
```

Isso monta os objetos ARM32 e valida a superfície da API. Não faz link final ARM32 com libc neste ambiente.

## Rotas de execução

- `RAF_PATH_C`
- `RAF_PATH_ASM_SCALAR`
- `RAF_PATH_ASM_NEON` (copy path opcional)

## Arquivos principais

- `asm/raf_armv7_hotpath.S`
- `asm/raf_neon_copy_optional.S`
- `src/raf_hotpath.c`
- `src/asm_stubs.c`
- `src/main.c`

## Limite atual

O benchmark executável incluso roda como **simulador host** com stubs C para as rotas ASM. A parte ARM32 é validada por montagem e objdump; para benchmark real, rode em hardware ARMv7.
