#ifndef RAF_HOTPATH_H
#define RAF_HOTPATH_H

/* Freestanding-friendly header for ARM32 hot-path experiments.
 * The package can be syntax-checked for ARM32 and executed as a host-side
 * logic simulator using the C fallback stubs.
 */

typedef __SIZE_TYPE__ raf_size_t;
typedef unsigned char raf_u8;
typedef unsigned int raf_u32;
typedef unsigned long long raf_u64;

enum {
    RAF_N55_CYCLES = 56,
    RAF_N55_WORKSET_BYTES = 5 * 1024 * 1024,
    RAF_RING_CAPACITY = 64,
    RAF_PACKET_STRIDE = 4096
};

typedef enum {
    RAF_PATH_C = 0,
    RAF_PATH_ASM_SCALAR = 1,
    RAF_PATH_ASM_NEON = 2
} RafPath;

typedef struct {
    raf_u32 seq;
    raf_u32 len;
    raf_u32 crc32;
    raf_u32 fold;
} RafPacketMeta;

typedef struct {
    RafPacketMeta slots[RAF_RING_CAPACITY];
    raf_u32 head;
    raf_u32 tail;
    raf_u32 count;
} RafRing;

typedef struct {
    raf_u32 cycles;
    raf_u32 packets_pushed;
    raf_u32 packets_popped;
    raf_u64 bytes_processed;
    raf_u32 crc_mix;
    raf_u32 fold_mix;
    raf_u32 ring_highwater;
    raf_u32 verification_failures;
} RafRunStats;

#ifdef __cplusplus
extern "C" {
#endif

void raf_ring_init(RafRing *rb);
int raf_ring_push(RafRing *rb, const RafPacketMeta *meta);
int raf_ring_pop(RafRing *rb, RafPacketMeta *out);

void raf_fill_pattern(raf_u8 *dst, raf_size_t n, raf_u32 seed);
raf_u32 raf_crc32_update_c(raf_u32 crc, const raf_u8 *data, raf_size_t n);
raf_u32 raf_xor_fold32_c(const raf_u32 *p, raf_size_t n_words);
void raf_copy_words_c(raf_u32 *dst, const raf_u32 *src, raf_size_t n_words);

raf_u32 raf_xor_fold32_asm(const raf_u32 *p, raf_u32 n_words);
void raf_copy_words_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words);
void raf_copy_words_neon_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words);

RafRunStats raf_run_n55_profile(RafPath path, int verbose);
int raf_selftest_hotpath(int verbose);

#ifdef __cplusplus
}
#endif

#endif
