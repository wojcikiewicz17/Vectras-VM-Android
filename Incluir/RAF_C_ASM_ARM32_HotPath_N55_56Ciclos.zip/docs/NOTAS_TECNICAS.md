# Notas técnicas

## ABI e alvo

- ARMv7-A
- Linux EABI / AAPCS
- hard-float
- scalar VFP + NEON opcional

## Hot path implementado

### 1. `raf_copy_words_asm`

Cópia 32-bit em loop curto usando `ldmia/stmia` com 2 palavras por iteração.

### 2. `raf_xor_fold32_asm`

Fold XOR 32-bit simples para checksum rápido e barato.

### 3. `raf_copy_words_neon_asm`

Cópia opcional em blocos de 4 palavras com `q0`, seguida de cauda escalar.

## CRC32

Foi mantido em C por clareza e previsibilidade do pacote base. Isso deixa o projeto mais fácil de portar e auditar. A próxima iteração natural é usar tabela ou PMULL/CRC ISA quando houver alvo apropriado.

## Harness N55

- 56 ciclos fixos
- janela total: 5 MiB
- tamanhos de chunk variáveis entre 256 B e 16 KiB
- stride pseudo-determinístico por ciclo
- ring buffer de 64 entradas

## O que medir no hardware alvo

- throughput MiB/s
- custo por ciclo
- sensibilidade a alinhamento
- efeito de cache quente/frio
- ganho scalar vs NEON
