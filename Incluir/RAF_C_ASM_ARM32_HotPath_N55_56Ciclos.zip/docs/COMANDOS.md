# Comandos

## Host / simulador de lógica

```bash
make host
make run
make bench
make test
```

## Checagem ARM32

```bash
make arm32_objcheck
llvm-objdump -d build/obj/raf_armv7_hotpath.o
llvm-objdump -d build/obj/raf_neon_copy_optional.o
```

## Em ARM32 real

Use um toolchain como `arm-linux-gnueabihf-gcc` e substitua o build host pelos objetos ARM32 em link nativo.
