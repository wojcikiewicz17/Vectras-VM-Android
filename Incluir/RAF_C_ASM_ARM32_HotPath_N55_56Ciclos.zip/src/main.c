#include "raf_hotpath.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

static unsigned long long raf_ns_now(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return ((unsigned long long)ts.tv_sec * 1000000000ull) + (unsigned long long)ts.tv_nsec;
}

static void raf_print_stats(const char *tag, RafRunStats st, unsigned long long ns) {
    double mib = (double)st.bytes_processed / (1024.0 * 1024.0);
    double sec = (double)ns / 1e9;
    double mibps = sec > 0.0 ? mib / sec : 0.0;
    printf("[%s] cycles=%u pushed=%u popped=%u bytes=%llu highwater=%u fail=%u\n",
           tag,
           st.cycles,
           st.packets_pushed,
           st.packets_popped,
           (unsigned long long)st.bytes_processed,
           st.ring_highwater,
           st.verification_failures);
    printf("[%s] crc_mix=%08x fold_mix=%08x elapsed_ns=%llu throughput_mib_s=%.2f\n",
           tag,
           st.crc_mix,
           st.fold_mix,
           ns,
           mibps);
}

int main(int argc, char **argv) {
    if (argc > 1 && strcmp(argv[1], "selftest") == 0) {
        return raf_selftest_hotpath(1);
    }

    if (argc > 1 && strcmp(argv[1], "bench") == 0) {
        unsigned long long t0, t1;
        RafRunStats cst, ast;

        t0 = raf_ns_now();
        cst = raf_run_n55_profile(RAF_PATH_C, 0);
        t1 = raf_ns_now();
        raf_print_stats("bench-c", cst, t1 - t0);

        t0 = raf_ns_now();
        ast = raf_run_n55_profile(RAF_PATH_ASM_SCALAR, 0);
        t1 = raf_ns_now();
        raf_print_stats("bench-asm", ast, t1 - t0);
        return 0;
    }

    if (argc > 1 && strcmp(argv[1], "verbose") == 0) {
        RafRunStats st = raf_run_n55_profile(RAF_PATH_ASM_SCALAR, 1);
        raf_print_stats("verbose", st, 0ull);
        return 0;
    }

    {
        RafRunStats st = raf_run_n55_profile(RAF_PATH_ASM_SCALAR, 0);
        raf_print_stats("run", st, 0ull);
    }
    return 0;
}
