#include "raf_hotpath.h"

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static raf_u32 raf_rotl32(raf_u32 x, unsigned r) {
    return (x << r) | (x >> (32U - r));
}

void raf_ring_init(RafRing *rb) {
    rb->head = 0U;
    rb->tail = 0U;
    rb->count = 0U;
    memset(rb->slots, 0, sizeof(rb->slots));
}

int raf_ring_push(RafRing *rb, const RafPacketMeta *meta) {
    if (rb->count >= RAF_RING_CAPACITY) {
        return -1;
    }
    rb->slots[rb->head] = *meta;
    rb->head = (rb->head + 1U) % RAF_RING_CAPACITY;
    rb->count++;
    return 0;
}

int raf_ring_pop(RafRing *rb, RafPacketMeta *out) {
    if (rb->count == 0U) {
        return -1;
    }
    *out = rb->slots[rb->tail];
    rb->tail = (rb->tail + 1U) % RAF_RING_CAPACITY;
    rb->count--;
    return 0;
}

void raf_fill_pattern(raf_u8 *dst, raf_size_t n, raf_u32 seed) {
    raf_u32 x = seed ^ 0x9E3779B9u;
    for (raf_size_t i = 0; i < n; ++i) {
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        dst[i] = (raf_u8)((x + (raf_u32)i) & 0xFFu);
    }
}

raf_u32 raf_crc32_update_c(raf_u32 crc, const raf_u8 *data, raf_size_t n) {
    crc = ~crc;
    for (raf_size_t i = 0; i < n; ++i) {
        crc ^= data[i];
        for (unsigned bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
        }
    }
    return ~crc;
}

raf_u32 raf_xor_fold32_c(const raf_u32 *p, raf_size_t n_words) {
    raf_u32 acc = 0u;
    for (raf_size_t i = 0; i < n_words; ++i) {
        acc ^= p[i];
    }
    return acc;
}

void raf_copy_words_c(raf_u32 *dst, const raf_u32 *src, raf_size_t n_words) {
    for (raf_size_t i = 0; i < n_words; ++i) {
        dst[i] = src[i];
    }
}

static void *raf_aligned_alloc64(raf_size_t nbytes) {
#if defined(_MSC_VER)
    return _aligned_malloc(nbytes, 64);
#elif defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 201112L)
    return aligned_alloc(64, nbytes);
#else
    return malloc(nbytes);
#endif
}

static void raf_aligned_free64(void *p) {
#if defined(_MSC_VER)
    _aligned_free(p);
#else
    free(p);
#endif
}

static raf_size_t raf_chunk_size_for_cycle(raf_u32 cycle) {
    static const raf_size_t sizes[] = {
        256, 512, 768, 1024, 1536, 2048, 3072, 4096,
        6144, 8192, 12288, 16384
    };
    return sizes[cycle % (sizeof(sizes) / sizeof(sizes[0]))];
}

static void raf_copy_dispatch(RafPath path, raf_u32 *dst, const raf_u32 *src, raf_u32 n_words) {
    switch (path) {
        case RAF_PATH_ASM_NEON:
            raf_copy_words_neon_asm(dst, src, n_words);
            break;
        case RAF_PATH_ASM_SCALAR:
            raf_copy_words_asm(dst, src, n_words);
            break;
        case RAF_PATH_C:
        default:
            raf_copy_words_c(dst, src, n_words);
            break;
    }
}

static raf_u32 raf_fold_dispatch(RafPath path, const raf_u32 *src, raf_u32 n_words) {
    switch (path) {
        case RAF_PATH_ASM_NEON:
        case RAF_PATH_ASM_SCALAR:
            return raf_xor_fold32_asm(src, n_words);
        case RAF_PATH_C:
        default:
            return raf_xor_fold32_c(src, n_words);
    }
}

static const char *raf_path_name(RafPath path) {
    switch (path) {
        case RAF_PATH_ASM_SCALAR: return "asm-scalar";
        case RAF_PATH_ASM_NEON: return "asm-neon";
        case RAF_PATH_C:
        default: return "c";
    }
}

RafRunStats raf_run_n55_profile(RafPath path, int verbose) {
    RafRunStats st;
    RafRing rb;
    raf_u8 *src = NULL;
    raf_u8 *dst = NULL;
    raf_u32 seed = 0xC0A56A55u;

    memset(&st, 0, sizeof(st));
    raf_ring_init(&rb);

    src = (raf_u8 *)raf_aligned_alloc64(RAF_N55_WORKSET_BYTES);
    dst = (raf_u8 *)raf_aligned_alloc64(RAF_N55_WORKSET_BYTES);
    if (!src || !dst) {
        st.verification_failures = 0xFFFFFFFFu;
        raf_aligned_free64(src);
        raf_aligned_free64(dst);
        return st;
    }

    raf_fill_pattern(src, RAF_N55_WORKSET_BYTES, seed);
    memset(dst, 0, RAF_N55_WORKSET_BYTES);

    for (raf_u32 cycle = 0; cycle < RAF_N55_CYCLES; ++cycle) {
        raf_size_t chunk_bytes = raf_chunk_size_for_cycle(cycle);
        raf_u32 stride = ((cycle * 8191u) % (RAF_N55_WORKSET_BYTES - chunk_bytes)) & ~3u;
        raf_u32 word_off = stride / 4u;
        raf_u32 n_words = (raf_u32)(chunk_bytes / 4u);
        raf_u32 *dst_words = ((raf_u32 *)dst) + word_off;
        const raf_u32 *src_words = ((const raf_u32 *)src) + word_off;
        RafPacketMeta meta;

        raf_copy_dispatch(path, dst_words, src_words, n_words);
        if (memcmp(dst + stride, src + stride, chunk_bytes) != 0) {
            st.verification_failures++;
        }
        meta.seq = cycle;
        meta.len = (raf_u32)chunk_bytes;
        meta.crc32 = raf_crc32_update_c(0u, dst + stride, chunk_bytes);
        meta.fold = raf_fold_dispatch(path, dst_words, n_words);

        st.crc_mix ^= raf_rotl32(meta.crc32 + cycle, cycle & 31u);
        st.fold_mix ^= raf_rotl32(meta.fold ^ (0x9E37u * (cycle + 1u)), (cycle * 3u) & 31u);
        st.bytes_processed += chunk_bytes;
        st.cycles++;

        if (raf_ring_push(&rb, &meta) == 0) {
            st.packets_pushed++;
            if (rb.count > st.ring_highwater) {
                st.ring_highwater = rb.count;
            }
        } else {
            RafPacketMeta out;
            if (raf_ring_pop(&rb, &out) == 0) {
                st.packets_popped++;
                if (out.seq > cycle) {
                    st.verification_failures++;
                }
            }
            if (raf_ring_push(&rb, &meta) == 0) {
                st.packets_pushed++;
            } else {
                st.verification_failures++;
            }
        }

        if ((cycle & 3u) == 3u) {
            RafPacketMeta out;
            if (raf_ring_pop(&rb, &out) == 0) {
                if (out.seq > cycle || out.len == 0u) {
                    st.verification_failures++;
                }
                st.packets_popped++;
            }
        }

        if (verbose) {
            printf("[n55] cycle=%02u path=%s chunk=%5u crc=%08x fold=%08x ring=%u\n",
                   cycle,
                   raf_path_name(path),
                   (unsigned)chunk_bytes,
                   meta.crc32,
                   meta.fold,
                   rb.count);
        }
    }

    while (rb.count != 0u) {
        RafPacketMeta out;
        (void)raf_ring_pop(&rb, &out);
        st.packets_popped++;
    }

    raf_aligned_free64(src);
    raf_aligned_free64(dst);
    return st;
}

int raf_selftest_hotpath(int verbose) {
    RafRunStats cst = raf_run_n55_profile(RAF_PATH_C, 0);
    RafRunStats ast = raf_run_n55_profile(RAF_PATH_ASM_SCALAR, 0);
    int ok = 1;

    if (cst.verification_failures != 0u || ast.verification_failures != 0u) {
        ok = 0;
    }
    if (cst.bytes_processed != ast.bytes_processed) {
        ok = 0;
    }
    if (cst.crc_mix != ast.crc_mix || cst.fold_mix != ast.fold_mix) {
        ok = 0;
    }

    if (verbose) {
        printf("[selftest] c:   bytes=%llu crc_mix=%08x fold_mix=%08x fail=%u\n",
               (unsigned long long)cst.bytes_processed, cst.crc_mix, cst.fold_mix, cst.verification_failures);
        printf("[selftest] asm: bytes=%llu crc_mix=%08x fold_mix=%08x fail=%u\n",
               (unsigned long long)ast.bytes_processed, ast.crc_mix, ast.fold_mix, ast.verification_failures);
        printf("[selftest] result=%s\n", ok ? "OK" : "FAIL");
    }

    return ok ? 0 : 1;
}
