#include "raf_hotpath.h"

raf_u32 raf_xor_fold32_asm(const raf_u32 *p, raf_u32 n_words) {
    return raf_xor_fold32_c(p, n_words);
}

void raf_copy_words_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words) {
    raf_copy_words_c(dst, src, n_words);
}

void raf_copy_words_neon_asm(raf_u32 *dst, const raf_u32 *src, raf_u32 n_words) {
    raf_copy_words_c(dst, src, n_words);
}
