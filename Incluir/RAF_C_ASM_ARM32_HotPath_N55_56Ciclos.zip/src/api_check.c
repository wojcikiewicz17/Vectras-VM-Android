#include "raf_hotpath.h"

/* Freestanding translation unit used only for syntax/API checking. */
void raf_api_surface_check(void) {
    RafRing rb;
    RafRunStats st;
    RafPacketMeta meta;
    raf_u32 x[4] = {0, 1, 2, 3};

    raf_ring_init(&rb);
    meta.seq = 1u;
    meta.len = 16u;
    meta.crc32 = raf_crc32_update_c(0u, (const raf_u8 *)x, sizeof(x));
    meta.fold = raf_xor_fold32_c(x, 4u);
    (void)raf_ring_push(&rb, &meta);
    (void)raf_ring_pop(&rb, &meta);
    raf_copy_words_c(x, x, 4u);
    raf_copy_words_asm(x, x, 4u);
    st = raf_run_n55_profile(RAF_PATH_C, 0);
    (void)st;
}
