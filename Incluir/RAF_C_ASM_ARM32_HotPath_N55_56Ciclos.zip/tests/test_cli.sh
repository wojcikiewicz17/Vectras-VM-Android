#!/usr/bin/env sh
set -eu
make host >/dev/null
./build/host/raf_hotpath_n55 selftest
./build/host/raf_hotpath_n55 bench
