
from __future__ import annotations
import argparse
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import least_squares


@dataclass
class State:
    I: float
    E: float
    P: float
    V: float
    G: float
    O: float
    C: float
    phi: float
    S: float


ALL_PARAMS = ["alpha","beta","gamma","delta","epsilon","zeta","lambda_","omega","kappa"]
EST_PARAMS = ["beta","lambda_","omega","kappa"]


def clamp(x, lo=-1.0, hi=1.0):
    return max(lo, min(hi, x))


def default_theta():
    return {
        "alpha": 0.90,
        "beta": 0.75,
        "gamma": 0.50,
        "delta": 0.60,
        "epsilon": 0.45,
        "zeta": 0.40,
        "lambda_": 0.70,
        "omega": 0.18,
        "kappa": 0.10,
    }


def transition_params():
    return {
        "a1": 0.18, "a2": 0.12, "a3": 0.08,
        "b1": 0.16, "b2": 0.14,
        "c1": 0.15, "c2": 0.12, "c3": 0.10,
        "d1": 0.17, "d2": 0.09,
        "e1": 0.12, "e2": 0.10,
        "f1": 0.13, "f2": 0.09,
        "g1": 0.20, "g2": 0.18, "g3": 0.12, "g4": 0.10,
    }


def initial_state():
    return State(I=0.35, E=0.22, P=0.08, V=0.40, G=0.28, O=0.20, C=0.30, phi=0.0, S=0.0)


def input_schedule(t, T):
    pulse = 0.0
    if 20 <= t < 35:
        pulse += 0.18
    if 70 <= t < 80:
        pulse -= 0.10
    seasonal = 0.05 * math.sin(2 * math.pi * t / max(T, 1))
    return pulse + seasonal


def step(st: State, theta, trans, xi=0.0):
    I = math.tanh(st.I + trans["a1"] * st.V - trans["a2"] * st.E - trans["a3"] * st.O + 0.05 * xi)
    E = clamp(math.tanh(st.E + trans["b1"] * abs(xi) - trans["b2"] * st.C), 0.0, 1.0)
    P = math.tanh(st.P + trans["c1"] * st.E + trans["c2"] * st.O - trans["c3"] * st.C)
    V = math.tanh(st.V + trans["d1"] * st.I - trans["d2"] * st.G)
    G = clamp(math.tanh(st.G + trans["e1"] * st.V + trans["e2"] * st.P), 0.0, 1.0)
    O = clamp(math.tanh(st.O + trans["f1"] * st.E - trans["f2"] * st.I), 0.0, 1.0)
    C = math.tanh(st.C + trans["g1"] * st.I - trans["g2"] * st.E - trans["g3"] * st.P - trans["g4"] * st.O)
    S = math.tanh(
        theta["alpha"] * I
        - theta["beta"] * E
        - theta["gamma"] * P
        + theta["delta"] * V
        - theta["epsilon"] * G
        - theta["zeta"] * O
        + theta["lambda_"] * C
        + xi
    )
    phi = (st.phi + theta["omega"] + theta["kappa"] * E) % (2 * math.pi)
    return State(I=I, E=E, P=P, V=V, G=G, O=O, C=C, phi=phi, S=S)


def simulate(T=120, theta=None, seed=42, noise_y=0.0):
    theta = default_theta() if theta is None else dict(theta)
    trans = transition_params()
    st = initial_state()
    rng = np.random.default_rng(seed)
    rows = []
    for t in range(T):
        xi = input_schedule(t, T)
        st = step(st, theta, trans, xi=xi)
        y_S = st.S + (rng.normal(0.0, noise_y) if noise_y else 0.0)
        y_phi = st.phi + (rng.normal(0.0, noise_y * 0.4) if noise_y else 0.0)
        y_C = st.C + (rng.normal(0.0, noise_y * 0.5) if noise_y else 0.0)
        rows.append({
            "t": t, "xi": xi, **asdict(st),
            "y_S": y_S, "y_phi": y_phi, "y_C": y_C,
            "coherence_proxy": float(max(0.0, min(1.0, (st.C + 1.0) / 2.0))),
            "collapse": int(st.C < -0.25),
        })
    return pd.DataFrame(rows)


def vec_to_theta(vec):
    theta = default_theta()
    for k, v in zip(EST_PARAMS, vec):
        theta[k] = float(v)
    return theta


def residual_vector(theta_vec, observed_df):
    theta = vec_to_theta(theta_vec)
    sim = simulate(T=len(observed_df), theta=theta, seed=123, noise_y=0.0)
    res_S = sim["S"].to_numpy() - observed_df["y_S"].to_numpy()
    res_C = sim["C"].to_numpy() - observed_df["y_C"].to_numpy()
    phase_diff = np.angle(np.exp(1j * (sim["phi"].to_numpy() - observed_df["y_phi"].to_numpy())))
    return np.concatenate([res_S, 0.6 * res_C, 0.35 * phase_diff])


def estimate_parameters(observed_df, x0=None):
    defaults = default_theta()
    if x0 is None:
        x0 = np.array([defaults[k] for k in EST_PARAMS], dtype=float)
        x0 = x0 * np.array([0.92, 1.08, 1.03, 0.96])
    lower = np.array([0.20, 0.20, 0.01, 0.01], dtype=float)
    upper = np.array([1.50, 1.40, 0.50, 0.40], dtype=float)
    result = least_squares(residual_vector, x0=x0, bounds=(lower, upper), args=(observed_df,), method="trf", loss="soft_l1")
    return result, vec_to_theta(result.x)


def summary_metrics(df):
    return {
        "mean_S": float(df["S"].mean()),
        "std_S": float(df["S"].std(ddof=0)),
        "mean_C": float(df["C"].mean()),
        "collapse_rate": float(df["collapse"].mean()),
        "phase_variability": float(np.mean(np.abs(np.diff(df["phi"].to_numpy())))),
        "final_S": float(df["S"].iloc[-1]),
        "final_C": float(df["C"].iloc[-1]),
    }


def local_sensitivity(theta_hat, rel_step=0.05, T=120):
    base_df = simulate(T=T, theta=theta_hat, seed=123, noise_y=0.0)
    base_metrics = summary_metrics(base_df)
    rows = []
    for k in EST_PARAMS:
        val = theta_hat[k]
        h = max(rel_step * max(abs(val), 1e-3), 1e-3)
        theta_plus = dict(theta_hat)
        theta_minus = dict(theta_hat)
        theta_plus[k] = val + h
        theta_minus[k] = max(0.001, val - h)
        m_plus = summary_metrics(simulate(T=T, theta=theta_plus, seed=123))
        m_minus = summary_metrics(simulate(T=T, theta=theta_minus, seed=123))
        for metric in base_metrics:
            deriv = (m_plus[metric] - m_minus[metric]) / (theta_plus[k] - theta_minus[k])
            norm = deriv * val / (base_metrics[metric] if abs(base_metrics[metric]) > 1e-6 else 1.0)
            rows.append({"parameter": k, "metric": metric, "sensitivity": deriv, "normalized_sensitivity": norm})
    return pd.DataFrame(rows), base_metrics


def classify_regime(df):
    last = df.tail(40)
    mean_s = float(last["S"].mean())
    std_s = float(last["S"].std(ddof=0))
    if std_s > 0.02:
        return "oscilatorio"
    if mean_s < 0.60:
        return "baixa_ativacao"
    if mean_s < 0.80:
        return "moderado"
    if mean_s < 0.92:
        return "alto"
    return "saturado"



def regime_map(theta_hat, p1="alpha", p2="beta", n=31, span1=(0.2, 1.4), span2=(0.2, 1.4), T=120):
    grid1 = np.linspace(span1[0], span1[1], n)
    grid2 = np.linspace(span2[0], span2[1], n)
    rows = []
    for v1 in grid1:
        for v2 in grid2:
            th = dict(theta_hat)
            th[p1] = float(v1)
            th[p2] = float(v2)
            df = simulate(T=T, theta=th, seed=123)
            rows.append({
                p1: v1,
                p2: v2,
                "regime": classify_regime(df),
                "mean_S": df["S"].tail(40).mean(),
                "mean_C": df["C"].tail(40).mean(),
                "std_S": df["S"].tail(40).std(ddof=0),
            })
    return pd.DataFrame(rows)


def save_outputs(out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    fig_dir = out_dir / "figures"
    data_dir = out_dir / "data"
    fig_dir.mkdir(exist_ok=True)
    data_dir.mkdir(exist_ok=True)

    theta_true = default_theta()
    observed = simulate(T=120, theta=theta_true, seed=11, noise_y=0.03)
    observed.to_csv(data_dir / "synthetic_observations.csv", index=False)

    result, theta_hat = estimate_parameters(observed)
    fit_df = simulate(T=120, theta=theta_hat, seed=123, noise_y=0.0)
    fit_df.to_csv(data_dir / "fitted_timeseries.csv", index=False)

    summary_rows = []
    for k in ALL_PARAMS:
        summary_rows.append({
            "parameter": k,
            "true_value": theta_true[k],
            "estimated_value": theta_hat[k],
            "absolute_error": abs(theta_true[k] - theta_hat[k]),
            "estimated": k in EST_PARAMS,
        })
    est_df = pd.DataFrame(summary_rows)
    est_df.to_csv(data_dir / "parameter_estimation_summary.csv", index=False)

    sens_df, base_metrics = local_sensitivity(theta_hat)
    sens_df.to_csv(data_dir / "sensitivity_indices.csv", index=False)

    reg_df = regime_map(theta_hat, p1="alpha", p2="lambda_", n=31, span1=(0.0, 2.0), span2=(0.0, 2.0))
    reg_df.to_csv(data_dir / "regime_map_alpha_lambda.csv", index=False)

    plt.figure(figsize=(9, 4.8))
    plt.plot(observed["t"], observed["y_S"], label="observado")
    plt.plot(fit_df["t"], fit_df["S"], label="ajuste")
    plt.plot(observed["t"], observed["xi"], label="entrada", alpha=0.7)
    plt.xlabel("t")
    plt.ylabel("amplitude")
    plt.title("Ajuste da série temporal de S")
    plt.legend()
    plt.tight_layout()
    plt.savefig(fig_dir / "fit_timeseries_S.png", dpi=200)
    plt.close()

    plt.figure(figsize=(9, 4.8))
    plt.plot(observed["t"], observed["y_C"], label="C observado")
    plt.plot(fit_df["t"], fit_df["C"], label="C ajustado")
    plt.xlabel("t")
    plt.ylabel("coerência")
    plt.title("Ajuste da coerência estrutural C")
    plt.legend()
    plt.tight_layout()
    plt.savefig(fig_dir / "fit_coherence_C.png", dpi=200)
    plt.close()

    plt.figure(figsize=(9, 4.8))
    plt.plot(observed["t"], observed["y_phi"], label="fase observada")
    plt.plot(fit_df["t"], fit_df["phi"], label="fase ajustada")
    plt.xlabel("t")
    plt.ylabel("fase")
    plt.title("Dinâmica de fase")
    plt.legend()
    plt.tight_layout()
    plt.savefig(fig_dir / "phase_fit.png", dpi=200)
    plt.close()

    sens_metric = sens_df[sens_df["metric"] == "mean_S"].copy().sort_values("normalized_sensitivity", key=lambda s: np.abs(s), ascending=False)
    plt.figure(figsize=(9, 5.2))
    plt.bar(sens_metric["parameter"], sens_metric["normalized_sensitivity"])
    plt.xlabel("parâmetro")
    plt.ylabel("sensibilidade normalizada")
    plt.title("Sensibilidade local da métrica mean_S")
    plt.tight_layout()
    plt.savefig(fig_dir / "sensitivity_mean_S.png", dpi=200)
    plt.close()

    regime_order = {"baixa_ativacao": 0, "moderado": 1, "alto": 2, "saturado": 3, "oscilatorio": 4}
    pivot = reg_df.pivot(index="lambda_", columns="alpha", values="regime").sort_index(ascending=True)
    arr = np.vectorize(regime_order.get)(pivot.to_numpy())
    plt.figure(figsize=(7.6, 6.0))
    plt.imshow(arr, aspect="auto", origin="lower", extent=[pivot.columns.min(), pivot.columns.max(), pivot.index.min(), pivot.index.max()])
    plt.xlabel("alpha")
    plt.ylabel("lambda_")
    plt.title("Mapa de regime em alpha × lambda")
    cbar = plt.colorbar()
    cbar.set_ticks([0,1,2,3,4])
    cbar.set_ticklabels(["baixa","moderado","alto","saturado","oscilatório"])
    plt.tight_layout()
    plt.savefig(fig_dir / "regime_map_alpha_lambda.png", dpi=200)
    plt.close()

    plt.figure(figsize=(9, 5.2))
    x = np.arange(len(EST_PARAMS))
    w = 0.38
    true_vals = [theta_true[k] for k in EST_PARAMS]
    est_vals = [theta_hat[k] for k in EST_PARAMS]
    plt.bar(x - w/2, true_vals, width=w, label="verdadeiro")
    plt.bar(x + w/2, est_vals, width=w, label="estimado")
    plt.xticks(x, EST_PARAMS, rotation=30)
    plt.ylabel("valor")
    plt.title("Recuperação paramétrica")
    plt.legend()
    plt.tight_layout()
    plt.savefig(fig_dir / "parameter_recovery.png", dpi=200)
    plt.close()

    run_summary = {
        "optimization_success": bool(result.success),
        "optimization_status": int(result.status),
        "optimization_message": result.message,
        "cost": float(result.cost),
        "nfev": int(result.nfev),
        "base_metrics": base_metrics,
        "rmse_S": float(np.sqrt(np.mean((fit_df["S"].to_numpy() - observed["y_S"].to_numpy()) ** 2))),
        "rmse_C": float(np.sqrt(np.mean((fit_df["C"].to_numpy() - observed["y_C"].to_numpy()) ** 2))),
    }
    with open(out_dir / "run_summary.json", "w", encoding="utf-8") as f:
        json.dump(run_summary, f, ensure_ascii=False, indent=2)

    with open(out_dir / "theta_hat.json", "w", encoding="utf-8") as f:
        json.dump(theta_hat, f, ensure_ascii=False, indent=2)

    return {
        "theta_true": theta_true,
        "theta_hat": theta_hat,
        "run_summary": run_summary,
        "observed": observed,
        "fit_df": fit_df,
        "sensitivity": sens_df,
        "regime_map": reg_df,
    }


def main():
    parser = argparse.ArgumentParser(description="Modelo dinâmico para paper e análise exploratória.")
    parser.add_argument("--out_dir", default="submission_outputs", help="Diretório de saída.")
    args = parser.parse_args()
    outputs = save_outputs(Path(args.out_dir))
    print(json.dumps({
        "out_dir": str(Path(args.out_dir).resolve()),
        "theta_hat": outputs["theta_hat"],
        "cost": outputs["run_summary"]["cost"],
        "rmse_S": outputs["run_summary"]["rmse_S"],
        "rmse_C": outputs["run_summary"]["rmse_C"],
        "success": outputs["run_summary"]["optimization_success"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
