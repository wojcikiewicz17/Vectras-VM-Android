# Pacote de submissão

## Arquivos principais
- `paper_abnt_submission.docx`: manuscrito final em DOCX.
- `paper_abnt_submission.pdf`: manuscrito final em PDF.
- `paper_abnt_submission.md`: fonte em Markdown.
- `references.bib`: referências em BibTeX.
- `scripts/dynamic_state_paper_model.py`: script de simulação, estimação, sensibilidade e mapas de regime.

## Saídas computacionais
Na pasta `analysis_outputs/`:
- `data/synthetic_observations.csv`
- `data/fitted_timeseries.csv`
- `data/parameter_estimation_summary.csv`
- `data/sensitivity_indices.csv`
- `data/regime_map_alpha_lambda.csv`
- `figures/fit_timeseries_S.png`
- `figures/fit_coherence_C.png`
- `figures/sensitivity_mean_S.png`
- `figures/regime_map_alpha_lambda.png`
- `figures/parameter_recovery.png`
- `run_summary.json`
- `theta_hat.json`

## Observação metodológica
O manuscrito está formatado em estilo ABNT de forma prática e consistente, mas não está preso a um template institucional específico. Se a banca, revista ou programa exigir um modelo oficial, a estrutura já está pronta para adaptação fina.
