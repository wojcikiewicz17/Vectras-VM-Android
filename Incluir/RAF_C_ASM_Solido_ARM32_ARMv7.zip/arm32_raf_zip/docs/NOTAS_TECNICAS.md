# Notas técnicas

## ABI assumida

- ARM32 Linux
- ARMv7-A
- AAPCS / EABI hard-float

## Convenção de chamada relevante

- `r0`, `r1`, `r2`, `r3` são caller-saved e usados para argumentos escalares/pointers.
- Retorno `float` em **`s0`** no hard-float ABI.
- Os kernels ASM não preservam registradores caller-saved além do contrato ABI.

## Por que duas rotas ASM?

### 1. Scalar VFP
É a base mais estável para targets ARMv7-A hard-float que não garantem NEON em todos os modelos.

### 2. NEON opcional
Serve para targets embarcados ou SBCs em que NEON é parte conhecida do hardware.
É mais agressiva, mas não deve ser usada por padrão sem garantia do alvo.

## Benchmark

O benchmark usa `clock_gettime(CLOCK_MONOTONIC)` porque:

- é portável em Linux ARM32;
- evita depender de PMU/perf_event aberto ao usuário;
- evita assumir disponibilidade do contador de ciclos em EL0/user space.

## Limite do pacote no ambiente de geração

Este pacote foi **montado e validado por geração de objetos ARM32**, não por execução nativa ARM32 aqui no ambiente.
O motivo é simples: não havia sysroot/libc ARM32 e nem runtime/QEMU configurado para link+execução final.

Isso significa:

- **sintaxe ASM validada**;
- **surface API validada em TU freestanding**;
- **execução final deve ser feita no alvo ARM32 real** ou num cross environment completo.
