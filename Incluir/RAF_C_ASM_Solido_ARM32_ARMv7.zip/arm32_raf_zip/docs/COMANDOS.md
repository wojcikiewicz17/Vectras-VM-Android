# Comandos rápidos

## Em um ARM32 Linux real

```bash
make TARGET=native
make run TARGET=native
make bench TARGET=native
make test TARGET=native
```

## Em um ARM32 Linux real com NEON garantido

```bash
make TARGET=native ENABLE_NEON=1
make bench TARGET=native ENABLE_NEON=1
```

## No host atual, apenas checando objetos ARM32

```bash
make objcheck
```
