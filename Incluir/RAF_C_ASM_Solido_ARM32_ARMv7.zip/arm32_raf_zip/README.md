# RAF Semantic Core — C + ASM (ARM32 / ARMv7 / EABI hard-float)

Projeto enxuto para **Linux ARM32** com foco em:

- **C** como referência e lógica de domínio;
- **ASM ARMv7-A + VFP** para rota scalar sólida;
- **ASM NEON opcional** para targets que garantem NEON;
- **self-test** comparando C x ASM;
- **benchmark** simples com `clock_gettime`.

## O que ele implementa

- `raf_dot_f32_c` — referência em C;
- `raf_dot_f32_asm` — produto escalar em ARM32 scalar com VFP;
- `raf_dot_f32_neon_asm` — produto escalar NEON opcional;
- `raf_xor_checksum32_asm` — checksum XOR de 32 bits em ASM;
- atualização de estado (`tanh`, fase e coerência) em C.

## Alvo técnico

- **ARMv7-A**
- **AAPCS / Linux EABI hard-float**
- scalar: `-mfpu=vfpv3-d16 -mfloat-abi=hard`
- NEON opcional: `-mfpu=neon`

## Estrutura

```text
include/raf_core.h          API pública
src/raf_core.c              referência C + atualização de estado
src/selftest.c              comparação C x ASM
src/main.c                  demo + benchmark
src/api_check.c             TU freestanding para validação cruzada
asm/raf_armv7_eabihf.S      rota scalar ARM32 + checksum XOR
asm/raf_neon_optional.S     rota NEON opcional
tests/test_cli.sh           smoke test
Makefile                    build nativo ou objcheck cruzado
```

## Build nativo em uma máquina ARM32

```bash
make TARGET=native
make run TARGET=native
make bench TARGET=native
```

Com NEON garantido pelo target:

```bash
make TARGET=native ENABLE_NEON=1
make bench TARGET=native ENABLE_NEON=1
```

## Validação cruzada sem sysroot ARM completo

No ambiente em que este pacote foi montado, não havia libc/sysroot ARM32 para link final.
Mesmo assim, foi validado o ponto mais crítico: **geração de objetos ARM32** das rotinas ASM e da superfície pública da API.

```bash
make objcheck
```

Isso valida:

- sintaxe ARM32 scalar;
- sintaxe ARM32 NEON;
- chamadas do header/API em uma unidade freestanding.

## Observações de engenharia

1. A rota scalar usa **VFP** e retorna `float` em `s0`, compatível com **hard-float ABI**.
2. A rota NEON é **opt-in**. Só habilite quando o target realmente tiver NEON.
3. Não há leitura universal de contador de ciclos em user space ARM32 tão portátil quanto `rdtsc`; por isso o benchmark usa `clock_gettime`.
4. O projeto foi mantido pequeno para servir como base de expansão low-level real.

## Próximas extensões naturais

- dispatch runtime por HWCAP / `getauxval`
- versões Thumb2 dedicadas
- loop desenrolado (unrolled) para scalar VFP
- kernel CRC32 real (software e PMULL em ARM64 numa outra porta)
- integração com traços, buffer quente e parser de eventos

## Licença

Uso livre para estudo, adaptação e experimentação.
