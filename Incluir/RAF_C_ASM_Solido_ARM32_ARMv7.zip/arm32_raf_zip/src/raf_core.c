#include "raf_core.h"

#include <math.h>
#include <stddef.h>
#include <stdint.h>

float raf_dot_f32_c(const float *a, const float *b, raf_size_t n) {
    float acc = 0.0f;
    for (raf_size_t i = 0; i < n; ++i) {
        acc += a[i] * b[i];
    }
    return acc;
}

raf_u32 raf_xor_checksum32_c(const raf_u32 *p, raf_size_t n) {
    raf_u32 acc = 0U;
    for (raf_size_t i = 0; i < n; ++i) {
        acc ^= p[i];
    }
    return acc;
}

float raf_project_signal(const float inputs[6], const RafWeights *w, RafKernel kernel) {
    const float coeffs[6] = {
        w->alpha,
        w->beta,
        w->gamma,
        w->delta,
        w->epsilon,
        -w->eta,
    };

    switch (kernel) {
        case RAF_KERNEL_ASM_NEON:
            return raf_dot_f32_neon_asm(inputs, coeffs, 6U);
        case RAF_KERNEL_ASM_SCALAR:
            return raf_dot_f32_asm(inputs, coeffs, 6U);
        case RAF_KERNEL_C:
        default:
            return raf_dot_f32_c(inputs, coeffs, 6U);
    }
}

void raf_update_state(RafState *st,
                      const float inputs[6],
                      const RafWeights *w,
                      float omega,
                      float kappa,
                      RafKernel kernel) {
    const float prev_s = st->s;
    const float projected = raf_project_signal(inputs, w, kernel);
    const float mixed = projected + (w->memory * prev_s);

    st->s = tanhf(mixed);
    st->phi = st->phi + omega + (kappa * inputs[1]);
    st->coherence = 1.0f / (1.0f + fabsf(st->s - prev_s));
}

void raf_run_sequence(RafState *st,
                      const float *series_inputs,
                      raf_size_t steps,
                      const RafWeights *w,
                      float omega,
                      float kappa,
                      RafKernel kernel) {
    for (raf_size_t t = 0; t < steps; ++t) {
        raf_update_state(st, &series_inputs[t * 6U], w, omega, kappa, kernel);
    }
}
