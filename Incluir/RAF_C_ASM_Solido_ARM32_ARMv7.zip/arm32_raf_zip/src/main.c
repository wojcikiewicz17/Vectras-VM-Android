#define _POSIX_C_SOURCE 200809L
#include "raf_core.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static void fill_series(float *series, raf_size_t steps) {
    for (raf_size_t t = 0; t < steps; ++t) {
        const float x = (float)t / (float)(steps ? steps : 1U);
        series[t * 6U + 0U] = 0.80f + 0.10f * x;
        series[t * 6U + 1U] = 0.05f + 0.25f * (1.0f - x);
        series[t * 6U + 2U] = 0.10f + 0.20f * x;
        series[t * 6U + 3U] = 0.35f;
        series[t * 6U + 4U] = 0.70f + 0.05f * x;
        series[t * 6U + 5U] = 0.20f + 0.10f * (1.0f - x);
    }
}

static double now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1e9 + (double)ts.tv_nsec;
}

static void run_benchmark(int enable_neon) {
    enum { N = 1 << 19, ROUNDS = 150 };
    float *a = (float *)malloc(sizeof(float) * N);
    float *b = (float *)malloc(sizeof(float) * N);
    if (!a || !b) {
        fprintf(stderr, "falha ao alocar buffers do benchmark\n");
        free(a);
        free(b);
        return;
    }

    for (raf_size_t i = 0; i < (raf_size_t)N; ++i) {
        a[i] = (float)(i & 1023U) / 1024.0f;
        b[i] = (float)((i * 3U) & 1023U) / 1024.0f;
    }

    volatile float sink = 0.0f;
    const double t0 = now_ns();
    for (int r = 0; r < ROUNDS; ++r) sink += raf_dot_f32_c(a, b, (raf_size_t)N);
    const double t1 = now_ns();

    const double t2 = now_ns();
    for (int r = 0; r < ROUNDS; ++r) sink += raf_dot_f32_asm(a, b, (raf_u32)N);
    const double t3 = now_ns();

    printf("\n[benchmark dot_f32 ARM32]\n");
    printf("C          : %8.3f ms\n", (t1 - t0) / 1e6);
    printf("ASM scalar : %8.3f ms\n", (t3 - t2) / 1e6);

    if (enable_neon) {
        const double t4 = now_ns();
        for (int r = 0; r < ROUNDS; ++r) sink += raf_dot_f32_neon_asm(a, b, (raf_u32)N);
        const double t5 = now_ns();
        printf("ASM NEON   : %8.3f ms\n", (t5 - t4) / 1e6);
    }

    printf("sink(ignore) = %.3f\n", sink);
    free(a);
    free(b);
}

int main(int argc, char **argv) {
    const int run_bench = (argc > 1 && strcmp(argv[1], "--bench") == 0);
    const int enable_neon = (argc > 2 && strcmp(argv[2], "--neon") == 0) ||
                            (argc > 1 && strcmp(argv[1], "--neon") == 0);

    const RafWeights w = {
        .alpha = 0.95f,
        .beta = -0.55f,
        .gamma = 0.40f,
        .delta = -0.20f,
        .epsilon = 0.75f,
        .eta = 0.35f,
        .memory = 0.30f,
    };

    RafState st = {0.0f, 0.0f, 1.0f};
    float series[12U * 6U];
    fill_series(series, 12U);

    if (!raf_selftest(1e-4f, enable_neon)) {
        fprintf(stderr, "selftest falhou: C e ASM divergiram acima da tolerancia\n");
        return 1;
    }

    printf("RAF semantic core demo (ARM32 C + ASM)\n");
    printf("selftest: OK%s\n\n", enable_neon ? " + NEON" : "");
    printf(" t |    S_t    |   phi_t   | coherence\n");
    printf("---+-----------+-----------+-----------\n");

    for (raf_size_t t = 0; t < 12U; ++t) {
        raf_update_state(&st,
                         &series[t * 6U],
                         &w,
                         0.13f,
                         0.07f,
                         enable_neon ? RAF_KERNEL_ASM_NEON : RAF_KERNEL_ASM_SCALAR);
        printf("%2u | % .6f | % .6f | % .6f\n",
               (unsigned)(t + 1U), st.s, st.phi, st.coherence);
    }

    if (run_bench) {
        run_benchmark(enable_neon);
    }

    return 0;
}
