#include "raf_core.h"

/* Freestanding translation unit used only for cross-object validation. */
float raf_api_check(const float *a, const float *b, raf_u32 n) {
    return raf_dot_f32_asm(a, b, n) + raf_dot_f32_neon_asm(a, b, n);
}
