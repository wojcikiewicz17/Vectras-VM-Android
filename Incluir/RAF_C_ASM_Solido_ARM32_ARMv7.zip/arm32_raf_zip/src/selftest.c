#include "raf_core.h"

#include <math.h>
#include <stddef.h>
#include <stdint.h>

static raf_u32 raf_lcg(raf_u32 *state) {
    *state = (*state * 1664525u) + 1013904223u;
    return *state;
}

static float raf_rand_unit(raf_u32 *state) {
    const raf_u32 v = raf_lcg(state);
    return ((float)(v & 0x00FFFFFFu) / 16777215.0f) * 2.0f - 1.0f;
}

int raf_selftest(float tolerance, int enable_neon_checks) {
    float a[257];
    float b[257];
    raf_u32 words[257];
    raf_u32 seed = 0xA341316Cu;

    for (raf_size_t i = 0; i < 257U; ++i) {
        a[i] = raf_rand_unit(&seed);
        b[i] = raf_rand_unit(&seed);
        words[i] = raf_lcg(&seed);
    }

    for (raf_size_t n = 0; n <= 257U; ++n) {
        const float ref = raf_dot_f32_c(a, b, n);
        const float got_scalar = raf_dot_f32_asm(a, b, (raf_u32)n);
        if (fabsf(ref - got_scalar) > tolerance) {
            return 0;
        }
        if (enable_neon_checks) {
            const float got_neon = raf_dot_f32_neon_asm(a, b, (raf_u32)n);
            if (fabsf(ref - got_neon) > tolerance) {
                return 0;
            }
        }
        if (raf_xor_checksum32_c(words, n) != raf_xor_checksum32_asm(words, (raf_u32)n)) {
            return 0;
        }
    }

    return 1;
}
