#ifndef RAF_CORE_H
#define RAF_CORE_H

/* Header deliberately avoids libc headers so it can be syntax-checked in
 * freestanding cross-compilation environments without a target sysroot.
 */

typedef __SIZE_TYPE__ raf_size_t;
typedef unsigned int raf_u32;
typedef unsigned long long raf_u64;

typedef enum {
    RAF_KERNEL_C = 0,
    RAF_KERNEL_ASM_SCALAR = 1,
    RAF_KERNEL_ASM_NEON = 2
} RafKernel;

typedef struct {
    float alpha;
    float beta;
    float gamma;
    float delta;
    float epsilon;
    float eta;
    float memory;
} RafWeights;

typedef struct {
    float s;
    float phi;
    float coherence;
} RafState;

#ifdef __cplusplus
extern "C" {
#endif

float raf_dot_f32_c(const float *a, const float *b, raf_size_t n);
raf_u32 raf_xor_checksum32_c(const raf_u32 *p, raf_size_t n);

float raf_dot_f32_asm(const float *a, const float *b, raf_u32 n);
raf_u32 raf_xor_checksum32_asm(const raf_u32 *p, raf_u32 n);

/* Optional NEON path. Build only when the target guarantees NEON. */
float raf_dot_f32_neon_asm(const float *a, const float *b, raf_u32 n);

float raf_project_signal(const float inputs[6], const RafWeights *w, RafKernel kernel);
void raf_update_state(RafState *st,
                      const float inputs[6],
                      const RafWeights *w,
                      float omega,
                      float kappa,
                      RafKernel kernel);
void raf_run_sequence(RafState *st,
                      const float *series_inputs,
                      raf_size_t steps,
                      const RafWeights *w,
                      float omega,
                      float kappa,
                      RafKernel kernel);

int raf_selftest(float tolerance, int enable_neon_checks);

#ifdef __cplusplus
}
#endif

#endif
