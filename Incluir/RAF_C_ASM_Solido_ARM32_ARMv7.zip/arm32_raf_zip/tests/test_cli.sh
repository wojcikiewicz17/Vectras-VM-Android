#!/usr/bin/env sh
set -eu

./build/raf_demo >/tmp/raf_arm32_out.txt

grep -q "selftest: OK" /tmp/raf_arm32_out.txt
grep -q "coherence" /tmp/raf_arm32_out.txt
printf 'teste rápido: OK\n'
