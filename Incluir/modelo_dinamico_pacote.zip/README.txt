PACOTE: MODELO DINÂMICO NÃO LINEAR

Conteúdo do ZIP
1. 01_modelo_formal_academico.docx
   Documento curto em formato acadêmico, com:
   - formalização mínima;
   - hipóteses testáveis;
   - estabilidade local;
   - observabilidade;
   - métricas de validação;
   - limites epistemológicos.

2. 02_projeto_pesquisa_dissertacao_doutorado.docx
   Projeto de pesquisa estruturado para adaptação em:
   - dissertação de mestrado;
   - tese de doutorado;
   - proposta de paper base.

3. 03_simulacao_modelo_dinamico.py
   Script Python reprodutível para:
   - simular o sistema;
   - gerar CSV das séries temporais;
   - gerar gráficos de amplitude, fase e plano complexo;
   - salvar parâmetros e resumo da simulação.

Uso do script
python 03_simulacao_modelo_dinamico.py --steps 250 --output-dir saida_demo

Dependências
- Python 3
- numpy
- pandas
- matplotlib

Observação metodológica
O pacote trata o modelo como estrutura formal e testável.
Ele não assume, por si só, validade psicológica, cognitiva ou física.
Essa validade depende de operacionalização, dados e comparação com baseline.

