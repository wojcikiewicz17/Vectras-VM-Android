#!/usr/bin/env python3
"""
Simulador de um modelo dinâmico discreto não linear com saída complexa.

Uso básico:
    python 03_simulacao_modelo_dinamico.py --steps 250 --output-dir saida_demo

O script gera:
- series.csv                séries temporais simuladas
- amplitude.png             trajetória da amplitude A_t
- fase.png                  trajetória da fase phi_t
- plano_complexo.png        trajetória de Psi_t no plano complexo
- parametros.json           parâmetros usados na simulação

Autor: OpenAI / ChatGPT
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


@dataclass
class Params:
    alpha: float = 0.90
    beta: float = 0.55
    gamma: float = 0.40
    delta: float = 0.65
    epsilon: float = 0.70
    eta: float = 0.35
    omega: float = 0.18
    kappa: float = 0.22
    bias: float = 0.00
    noise_std: float = 0.00


def clamp(x: np.ndarray, low: float = -1.0, high: float = 1.0) -> np.ndarray:
    return np.clip(x, low, high)


def generate_inputs(steps: int, seed: int = 42) -> Dict[str, np.ndarray]:
    """
    Gera sinais normalizados em [-1, 1] para o sistema.
    Esses sinais podem ser substituídos por dados reais posteriormente.
    """
    rng = np.random.default_rng(seed)
    t = np.arange(steps)

    I = 0.55 + 0.25 * np.sin(2 * np.pi * t / 55.0) + 0.08 * rng.normal(size=steps)
    E = 0.10 + 0.35 * np.sin(2 * np.pi * t / 37.0 + 0.8) + 0.06 * rng.normal(size=steps)
    P = 0.18 * np.sin(2 * np.pi * t / 23.0 + 1.1) + 0.14 * np.sin(2 * np.pi * t / 71.0)
    V = 0.40 + 0.20 * np.sin(2 * np.pi * t / 48.0 + 0.2) + 0.05 * rng.normal(size=steps)
    G = 0.45 + 0.10 * np.sin(2 * np.pi * t / 90.0 + 2.0)
    O = 0.20 + 0.22 * np.sin(2 * np.pi * t / 64.0 + 1.5) + 0.05 * rng.normal(size=steps)

    return {
        "I": clamp(I),
        "E": clamp(E),
        "P": clamp(P),
        "V": clamp(V),
        "G": np.clip(G, 0.0, 1.0),
        "O": clamp(O),
    }


def simulate(params: Params, signals: Dict[str, np.ndarray], A0: float = 0.0, phi0: float = 0.0, seed: int = 42) -> pd.DataFrame:
    n = len(next(iter(signals.values())))
    rng = np.random.default_rng(seed)

    A = np.zeros(n)
    phi = np.zeros(n)
    psi_real = np.zeros(n)
    psi_imag = np.zeros(n)
    magnitude = np.zeros(n)

    A[0] = A0
    phi[0] = phi0
    psi_real[0] = A0 * np.cos(phi0)
    psi_imag[0] = A0 * np.sin(phi0)
    magnitude[0] = np.abs(A0)

    for t in range(n - 1):
        drive = (
            params.alpha * signals["I"][t]
            + params.beta * signals["E"][t]
            + params.gamma * signals["P"][t]
            - params.delta * signals["G"][t]
            + params.epsilon * signals["V"][t]
            - params.eta * signals["O"][t]
            + params.bias
        )

        noise = params.noise_std * rng.normal()
        A[t + 1] = np.tanh(drive + noise)
        phi[t + 1] = phi[t] + params.omega + params.kappa * signals["E"][t]

        psi_real[t + 1] = A[t + 1] * np.cos(phi[t + 1])
        psi_imag[t + 1] = A[t + 1] * np.sin(phi[t + 1])
        magnitude[t + 1] = np.sqrt(psi_real[t + 1] ** 2 + psi_imag[t + 1] ** 2)

    df = pd.DataFrame(
        {
            "t": np.arange(n),
            "I_t": signals["I"],
            "E_t": signals["E"],
            "P_t": signals["P"],
            "V_t": signals["V"],
            "G_t": signals["G"],
            "O_t": signals["O"],
            "A_t": A,
            "phi_t": phi,
            "psi_real": psi_real,
            "psi_imag": psi_imag,
            "abs_psi": magnitude,
        }
    )
    return df


def summarize(df: pd.DataFrame) -> Dict[str, float]:
    dphi = np.diff(df["phi_t"].to_numpy())
    return {
        "A_media": float(df["A_t"].mean()),
        "A_desvio": float(df["A_t"].std(ddof=0)),
        "velocidade_angular_media": float(dphi.mean()) if len(dphi) else 0.0,
        "velocidade_angular_desvio": float(dphi.std(ddof=0)) if len(dphi) else 0.0,
        "modulo_medio": float(df["abs_psi"].mean()),
    }


def save_plots(df: pd.DataFrame, outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(10, 4.8))
    plt.plot(df["t"], df["A_t"])
    plt.xlabel("t")
    plt.ylabel("A_t")
    plt.title("Amplitude interna")
    plt.tight_layout()
    plt.savefig(outdir / "amplitude.png", dpi=180)
    plt.close()

    plt.figure(figsize=(10, 4.8))
    plt.plot(df["t"], df["phi_t"])
    plt.xlabel("t")
    plt.ylabel("phi_t")
    plt.title("Fase acumulativa")
    plt.tight_layout()
    plt.savefig(outdir / "fase.png", dpi=180)
    plt.close()

    plt.figure(figsize=(6.5, 6.5))
    plt.plot(df["psi_real"], df["psi_imag"])
    plt.xlabel("Re(Psi_t)")
    plt.ylabel("Im(Psi_t)")
    plt.title("Trajetória no plano complexo")
    plt.axis("equal")
    plt.tight_layout()
    plt.savefig(outdir / "plano_complexo.png", dpi=180)
    plt.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Simulador do modelo dinâmico discreto não linear com saída complexa.")
    parser.add_argument("--steps", type=int, default=250, help="Número de passos simulados.")
    parser.add_argument("--seed", type=int, default=42, help="Semente para reprodutibilidade.")
    parser.add_argument("--output-dir", type=Path, default=Path("saida_modelo"), help="Diretório para os arquivos gerados.")
    parser.add_argument("--noise-std", type=float, default=0.00, help="Desvio padrão do ruído de processo.")
    parser.add_argument("--alpha", type=float, default=0.90)
    parser.add_argument("--beta", type=float, default=0.55)
    parser.add_argument("--gamma", type=float, default=0.40)
    parser.add_argument("--delta", type=float, default=0.65)
    parser.add_argument("--epsilon", type=float, default=0.70)
    parser.add_argument("--eta", type=float, default=0.35)
    parser.add_argument("--omega", type=float, default=0.18)
    parser.add_argument("--kappa", type=float, default=0.22)
    parser.add_argument("--bias", type=float, default=0.00)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    params = Params(
        alpha=args.alpha,
        beta=args.beta,
        gamma=args.gamma,
        delta=args.delta,
        epsilon=args.epsilon,
        eta=args.eta,
        omega=args.omega,
        kappa=args.kappa,
        bias=args.bias,
        noise_std=args.noise_std,
    )

    signals = generate_inputs(args.steps, seed=args.seed)
    df = simulate(params=params, signals=signals, seed=args.seed)
    summary = summarize(df)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.output_dir / "series.csv", index=False)
    save_plots(df, args.output_dir)

    with open(args.output_dir / "parametros.json", "w", encoding="utf-8") as f:
        json.dump(asdict(params), f, ensure_ascii=False, indent=2)

    with open(args.output_dir / "resumo.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("Simulação concluída.")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
