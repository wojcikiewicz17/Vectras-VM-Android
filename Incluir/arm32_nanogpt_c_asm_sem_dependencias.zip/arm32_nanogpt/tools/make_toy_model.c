#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint32_t vocab_size;
    uint32_t dim;
    uint32_t hidden_dim;
    uint32_t n_layers;
    uint32_t n_heads;
    uint32_t seq_len;
} ModelHeader;

#define MODEL_MAGIC 0x5447504eu

static uint32_t rng_state = 0xdeadbeefu;

static float frand(void) {
    rng_state ^= rng_state << 13;
    rng_state ^= rng_state >> 17;
    rng_state ^= rng_state << 5;
    return (float)((int32_t)(rng_state & 0x7fffffff)) / 2147483648.0f;
}

static float wsmall(float s) {
    return (frand() * 2.0f - 1.0f) * s;
}

static void write_array(FILE *f, size_t n, float scale, int ones) {
    for (size_t i = 0; i < n; ++i) {
        float v = ones ? 1.0f : wsmall(scale);
        fwrite(&v, sizeof(float), 1, f);
    }
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "uso: %s <saida.bin>\n", argv[0]);
        return 1;
    }

    const char *out = argv[1];
    FILE *f = fopen(out, "wb");
    if (!f) {
        fprintf(stderr, "erro: nao abriu '%s'\n", out);
        return 1;
    }

    ModelHeader h;
    h.magic = MODEL_MAGIC;
    h.version = 1;
    h.vocab_size = 256;
    h.dim = 32;
    h.hidden_dim = 64;
    h.n_layers = 2;
    h.n_heads = 4;
    h.seq_len = 128;

    fwrite(&h, sizeof(h), 1, f);

    size_t V = h.vocab_size, D = h.dim, H = h.hidden_dim, L = h.n_layers, T = h.seq_len;

    write_array(f, V * D, 0.02f, 0);
    write_array(f, T * D, 0.02f, 0);

    for (size_t l = 0; l < L; ++l) {
        write_array(f, D, 0.0f, 1);
        write_array(f, D, 0.0f, 0);
        write_array(f, D * D, 0.05f, 0);
        write_array(f, D * D, 0.05f, 0);
        write_array(f, D * D, 0.05f, 0);
        write_array(f, D * D, 0.05f, 0);
        write_array(f, D, 0.0f, 1);
        write_array(f, D, 0.0f, 0);
        write_array(f, H * D, 0.05f, 0);
        write_array(f, H, 0.01f, 0);
        write_array(f, D * H, 0.05f, 0);
        write_array(f, D, 0.01f, 0);
    }

    write_array(f, D, 0.0f, 1);
    write_array(f, D, 0.0f, 0);

    fclose(f);
    fprintf(stdout, "modelo toy escrito em %s\n", out);
    return 0;
}
