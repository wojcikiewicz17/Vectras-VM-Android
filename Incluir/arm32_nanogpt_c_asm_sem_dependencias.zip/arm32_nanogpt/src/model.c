#include "model.h"
#include "kernels.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MODEL_MAGIC 0x5447504eu
#define EPS 1e-5f

static float frand_u32(uint32_t *state) {
    *state ^= *state << 13;
    *state ^= *state >> 17;
    *state ^= *state << 5;
    return (float)(*state & 0x00FFFFFFu) / 16777216.0f;
}

static void *xcalloc(size_t n, size_t sz) {
    void *p = calloc(n, sz);
    if (!p) {
        fprintf(stderr, "erro: memoria insuficiente\n");
        exit(1);
    }
    return p;
}

static int read_f32(FILE *f, float *dst, size_t n) {
    return fread(dst, sizeof(float), n, f) == n ? 0 : -1;
}

static int alloc_layers(Model *m) {
    uint32_t L = m->h.n_layers;
    uint32_t D = m->h.dim;
    uint32_t H = m->h.hidden_dim;

    m->layers = (LayerWeights *)xcalloc(L, sizeof(LayerWeights));
    for (uint32_t l = 0; l < L; ++l) {
        LayerWeights *w = &m->layers[l];
        w->ln1_g = (float *)xcalloc(D, sizeof(float));
        w->ln1_b = (float *)xcalloc(D, sizeof(float));
        w->wq    = (float *)xcalloc((size_t)D * D, sizeof(float));
        w->wk    = (float *)xcalloc((size_t)D * D, sizeof(float));
        w->wv    = (float *)xcalloc((size_t)D * D, sizeof(float));
        w->wo    = (float *)xcalloc((size_t)D * D, sizeof(float));
        w->ln2_g = (float *)xcalloc(D, sizeof(float));
        w->ln2_b = (float *)xcalloc(D, sizeof(float));
        w->fc1   = (float *)xcalloc((size_t)H * D, sizeof(float));
        w->fc1_b = (float *)xcalloc(H, sizeof(float));
        w->fc2   = (float *)xcalloc((size_t)D * H, sizeof(float));
        w->fc2_b = (float *)xcalloc(D, sizeof(float));
    }
    return 0;
}

int model_load(Model *m, const char *path) {
    memset(m, 0, sizeof(*m));
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "erro: nao abriu modelo '%s'\n", path);
        return -1;
    }
    if (fread(&m->h, sizeof(ModelHeader), 1, f) != 1) {
        fclose(f);
        return -1;
    }
    if (m->h.magic != MODEL_MAGIC || m->h.version != 1) {
        fprintf(stderr, "erro: header invalido\n");
        fclose(f);
        return -1;
    }

    uint32_t V = m->h.vocab_size;
    uint32_t D = m->h.dim;
    uint32_t T = m->h.seq_len;

    m->token_embedding = (float *)xcalloc((size_t)V * D, sizeof(float));
    m->position_embedding = (float *)xcalloc((size_t)T * D, sizeof(float));
    m->lnf_g = (float *)xcalloc(D, sizeof(float));
    m->lnf_b = (float *)xcalloc(D, sizeof(float));

    alloc_layers(m);

    if (read_f32(f, m->token_embedding, (size_t)V * D) != 0) goto fail;
    if (read_f32(f, m->position_embedding, (size_t)T * D) != 0) goto fail;

    for (uint32_t l = 0; l < m->h.n_layers; ++l) {
        LayerWeights *w = &m->layers[l];
        if (read_f32(f, w->ln1_g, D) != 0) goto fail;
        if (read_f32(f, w->ln1_b, D) != 0) goto fail;
        if (read_f32(f, w->wq, (size_t)D * D) != 0) goto fail;
        if (read_f32(f, w->wk, (size_t)D * D) != 0) goto fail;
        if (read_f32(f, w->wv, (size_t)D * D) != 0) goto fail;
        if (read_f32(f, w->wo, (size_t)D * D) != 0) goto fail;
        if (read_f32(f, w->ln2_g, D) != 0) goto fail;
        if (read_f32(f, w->ln2_b, D) != 0) goto fail;
        if (read_f32(f, w->fc1, (size_t)m->h.hidden_dim * D) != 0) goto fail;
        if (read_f32(f, w->fc1_b, m->h.hidden_dim) != 0) goto fail;
        if (read_f32(f, w->fc2, (size_t)D * m->h.hidden_dim) != 0) goto fail;
        if (read_f32(f, w->fc2_b, D) != 0) goto fail;
    }

    if (read_f32(f, m->lnf_g, D) != 0) goto fail;
    if (read_f32(f, m->lnf_b, D) != 0) goto fail;

    fclose(f);
    return 0;

fail:
    fclose(f);
    model_free(m);
    fprintf(stderr, "erro: arquivo de pesos truncado\n");
    return -1;
}

void model_free(Model *m) {
    if (!m) return;
    free(m->token_embedding);
    free(m->position_embedding);
    free(m->lnf_g);
    free(m->lnf_b);

    if (m->layers) {
        for (uint32_t l = 0; l < m->h.n_layers; ++l) {
            LayerWeights *w = &m->layers[l];
            free(w->ln1_g); free(w->ln1_b);
            free(w->wq); free(w->wk); free(w->wv); free(w->wo);
            free(w->ln2_g); free(w->ln2_b);
            free(w->fc1); free(w->fc1_b);
            free(w->fc2); free(w->fc2_b);
        }
    }
    free(m->layers);
    memset(m, 0, sizeof(*m));
}

static void layernorm(float *out, const float *x, const float *g, const float *b, int n) {
    float mean = 0.0f;
    for (int i = 0; i < n; ++i) mean += x[i];
    mean /= (float)n;

    float var = 0.0f;
    for (int i = 0; i < n; ++i) {
        float d = x[i] - mean;
        var += d * d;
    }
    var /= (float)n;
    float inv = 1.0f / sqrtf(var + EPS);

    for (int i = 0; i < n; ++i) {
        float z = (x[i] - mean) * inv;
        out[i] = z * g[i] + b[i];
    }
}

static float gelu(float x) {
    const float k = 0.7978845608f;
    return 0.5f * x * (1.0f + tanhf(k * (x + 0.044715f * x * x * x)));
}

static void add_inplace(float *dst, const float *src, int n) {
    for (int i = 0; i < n; ++i) dst[i] += src[i];
}

static float maxf(const float *x, int n) {
    float m = x[0];
    for (int i = 1; i < n; ++i) if (x[i] > m) m = x[i];
    return m;
}

static void softmax_inplace(float *x, int n) {
    float m = maxf(x, n);
    float s = 0.0f;
    for (int i = 0; i < n; ++i) {
        x[i] = expf(x[i] - m);
        s += x[i];
    }
    s = (s > 0.0f) ? (1.0f / s) : 1.0f;
    for (int i = 0; i < n; ++i) x[i] *= s;
}

static void project_tokens(float *out, const float *W, const uint8_t *tokens, int T, int D, const float *pos) {
    for (int t = 0; t < T; ++t) {
        const float *te = W + ((int)tokens[t] * D);
        for (int i = 0; i < D; ++i) out[t * D + i] = te[i] + pos[t * D + i];
    }
}

static void transformer_forward_logits(Model *m, const uint8_t *tokens, int T, float *logits_out) {
    const int D = (int)m->h.dim;
    const int H = (int)m->h.hidden_dim;
    const int L = (int)m->h.n_layers;
    const int NH = (int)m->h.n_heads;
    const int HD = D / NH;

    float scale = 1.0f / sqrtf((float)HD);

    float *x      = (float *)xcalloc((size_t)T * D, sizeof(float));
    float *x2     = (float *)xcalloc((size_t)T * D, sizeof(float));
    float *norm   = (float *)xcalloc((size_t)T * D, sizeof(float));
    float *Q      = (float *)xcalloc((size_t)T * D, sizeof(float));
    float *K      = (float *)xcalloc((size_t)T * D, sizeof(float));
    float *Vv     = (float *)xcalloc((size_t)T * D, sizeof(float));
    float *attn   = (float *)xcalloc((size_t)T * D, sizeof(float));
    float *scores = (float *)xcalloc((size_t)T, sizeof(float));
    float *ff1    = (float *)xcalloc((size_t)T * H, sizeof(float));
    float *ff2    = (float *)xcalloc((size_t)T * D, sizeof(float));
    float *last   = (float *)xcalloc((size_t)D, sizeof(float));

    project_tokens(x, m->token_embedding, tokens, T, D, m->position_embedding);

    for (int l = 0; l < L; ++l) {
        LayerWeights *w = &m->layers[l];

        for (int t = 0; t < T; ++t) {
            layernorm(norm + t * D, x + t * D, w->ln1_g, w->ln1_b, D);
            matvec_f32(Q + t * D, w->wq, norm + t * D, NULL, D, D);
            matvec_f32(K + t * D, w->wk, norm + t * D, NULL, D, D);
            matvec_f32(Vv + t * D, w->wv, norm + t * D, NULL, D, D);
        }

        memset(attn, 0, (size_t)T * D * sizeof(float));

        for (int t = 0; t < T; ++t) {
            for (int h = 0; h < NH; ++h) {
                int off = h * HD;
                for (int j = 0; j <= t; ++j) {
                    float s = 0.0f;
                    dot_f32_out(&s, Q + t * D + off, K + j * D + off, HD);
                    scores[j] = s * scale;
                }
                softmax_inplace(scores, t + 1);

                for (int j = 0; j <= t; ++j) {
                    float a = scores[j];
                    axpy_f32(attn + t * D + off, Vv + j * D + off, a, HD);
                }
            }
        }

        for (int t = 0; t < T; ++t) {
            matvec_f32(x2 + t * D, w->wo, attn + t * D, NULL, D, D);
        }
        for (int t = 0; t < T; ++t) add_inplace(x + t * D, x2 + t * D, D);

        for (int t = 0; t < T; ++t) {
            layernorm(norm + t * D, x + t * D, w->ln2_g, w->ln2_b, D);
            matvec_f32(ff1 + t * H, w->fc1, norm + t * D, w->fc1_b, H, D);
            for (int i = 0; i < H; ++i) ff1[t * H + i] = gelu(ff1[t * H + i]);
            matvec_f32(ff2 + t * D, w->fc2, ff1 + t * H, w->fc2_b, D, H);
        }
        for (int t = 0; t < T; ++t) add_inplace(x + t * D, ff2 + t * D, D);
    }

    layernorm(last, x + (T - 1) * D, m->lnf_g, m->lnf_b, D);

    for (uint32_t tok = 0; tok < m->h.vocab_size; ++tok) {
        float s = 0.0f;
        dot_f32_out(&s, last, m->token_embedding + (size_t)tok * D, D);
        logits_out[tok] = s;
    }

    free(x); free(x2); free(norm);
    free(Q); free(K); free(Vv); free(attn);
    free(scores); free(ff1); free(ff2); free(last);
}

static int topk_sample(const float *logits, int n, float temperature, int top_k, uint32_t *rng_state) {
    float *buf = (float *)xcalloc((size_t)n, sizeof(float));
    int *idx = (int *)xcalloc((size_t)n, sizeof(int));
    for (int i = 0; i < n; ++i) {
        buf[i] = logits[i] / ((temperature > 1e-4f) ? temperature : 1e-4f);
        idx[i] = i;
    }

    if (top_k > 0 && top_k < n) {
        for (int i = 0; i < top_k; ++i) {
            int best = i;
            for (int j = i + 1; j < n; ++j) {
                if (buf[j] > buf[best]) best = j;
            }
            float tv = buf[i]; buf[i] = buf[best]; buf[best] = tv;
            int ti = idx[i]; idx[i] = idx[best]; idx[best] = ti;
        }
        for (int i = top_k; i < n; ++i) buf[i] = -1e30f;
    }

    softmax_inplace(buf, n);
    float r = frand_u32(rng_state);
    float c = 0.0f;
    int out = idx[n - 1];
    for (int i = 0; i < n; ++i) {
        c += buf[i];
        if (r <= c) {
            out = idx[i];
            break;
        }
    }
    free(buf);
    free(idx);
    return out;
}

int sample_next_token(Model *m, const uint8_t *tokens, int T, float temperature, int top_k, uint32_t *rng_state) {
    if (T <= 0 || T > (int)m->h.seq_len) return -1;
    float *logits = (float *)xcalloc(m->h.vocab_size, sizeof(float));
    transformer_forward_logits(m, tokens, T, logits);
    int tok = topk_sample(logits, (int)m->h.vocab_size, temperature, top_k, rng_state);
    free(logits);
    return tok;
}
