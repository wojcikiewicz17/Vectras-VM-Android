#ifndef MODEL_H
#define MODEL_H

#include <stdint.h>

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint32_t vocab_size;
    uint32_t dim;
    uint32_t hidden_dim;
    uint32_t n_layers;
    uint32_t n_heads;
    uint32_t seq_len;
} ModelHeader;

typedef struct {
    float *ln1_g, *ln1_b;
    float *wq, *wk, *wv, *wo;
    float *ln2_g, *ln2_b;
    float *fc1, *fc1_b;
    float *fc2, *fc2_b;
} LayerWeights;

typedef struct {
    ModelHeader h;
    float *token_embedding;
    float *position_embedding;
    LayerWeights *layers;
    float *lnf_g;
    float *lnf_b;
} Model;

int model_load(Model *m, const char *path);
void model_free(Model *m);
int sample_next_token(Model *m, const uint8_t *tokens, int T, float temperature, int top_k, uint32_t *rng_state);

#endif
