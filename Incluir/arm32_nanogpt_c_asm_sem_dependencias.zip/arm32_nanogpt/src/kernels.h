#ifndef KERNELS_H
#define KERNELS_H

void dot_f32_out(float *out, const float *a, const float *b, int n);
void axpy_f32(float *y, const float *x, float alpha, int n);
void matvec_f32(float *out, const float *W, const float *x, const float *bias, int rows, int cols);

#endif
