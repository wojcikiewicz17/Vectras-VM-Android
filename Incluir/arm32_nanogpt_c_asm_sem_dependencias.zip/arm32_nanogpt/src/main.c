#include "model.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

static void usage(const char *prog) {
    fprintf(stderr, "uso: %s <modelo.bin> <prompt> <n_tokens> <temperature> <top_k>\n", prog);
}

int main(int argc, char **argv) {
    if (argc < 6) {
        usage(argv[0]);
        return 1;
    }

    const char *model_path = argv[1];
    const char *prompt = argv[2];
    int n_tokens = atoi(argv[3]);
    float temperature = (float)atof(argv[4]);
    int top_k = atoi(argv[5]);

    Model m;
    if (model_load(&m, model_path) != 0) return 1;

    int prompt_len = (int)strlen(prompt);
    if (prompt_len <= 0 || prompt_len >= (int)m.h.seq_len) {
        fprintf(stderr, "erro: prompt precisa ter 1..%u bytes\n", m.h.seq_len - 1);
        model_free(&m);
        return 1;
    }

    uint8_t *tokens = (uint8_t *)calloc(m.h.seq_len, sizeof(uint8_t));
    if (!tokens) {
        model_free(&m);
        return 1;
    }

    for (int i = 0; i < prompt_len; ++i) tokens[i] = (uint8_t)prompt[i];

    uint32_t rng = 0x12345678u;

    fwrite(prompt, 1, (size_t)prompt_len, stdout);

    int T = prompt_len;
    for (int step = 0; step < n_tokens && T < (int)m.h.seq_len; ++step) {
        int next = sample_next_token(&m, tokens, T, temperature, top_k, &rng);
        if (next < 0) break;
        tokens[T++] = (uint8_t)next;
        fputc(next, stdout);
    }

    free(tokens);
    model_free(&m);
    return 0;
}
