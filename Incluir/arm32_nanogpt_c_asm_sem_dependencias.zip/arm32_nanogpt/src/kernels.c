#include "kernels.h"

#if !defined(USE_ARM32_ASM)
static void arm32_dot_f32_out(float *out, const float *a, const float *b, int n) {
    float s = 0.0f;
    for (int i = 0; i < n; ++i) s += a[i] * b[i];
    *out = s;
}
#else
extern void arm32_dot_f32_out(float *out, const float *a, const float *b, int n);
#endif

void dot_f32_out(float *out, const float *a, const float *b, int n) {
    arm32_dot_f32_out(out, a, b, n);
}

void axpy_f32(float *y, const float *x, float alpha, int n) {
    for (int i = 0; i < n; ++i) y[i] += alpha * x[i];
}

void matvec_f32(float *out, const float *W, const float *x, const float *bias, int rows, int cols) {
    for (int r = 0; r < rows; ++r) {
        float acc = 0.0f;
        dot_f32_out(&acc, W + (r * cols), x, cols);
        out[r] = bias ? (acc + bias[r]) : acc;
    }
}
