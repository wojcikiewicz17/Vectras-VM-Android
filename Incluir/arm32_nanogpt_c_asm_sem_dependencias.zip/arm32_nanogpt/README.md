# nanoGPT-like ARM32 em C/ASM puro

Projeto **mínimo e cru** de um transformer autoregressivo estilo nanoGPT para **ARM32**, escrito em **C + assembly ARM32**, sem dependências externas além da libc padrão.

## O que é
- **Tokenizer byte-level**: 1 byte = 1 token (vocabulário 256)
- **Transformer causal**: embeddings, atenção causal multi-head, MLP GELU, layer norm
- **Inferência autoregressiva**: gera próximos bytes
- **Kernels ARM32 em ASM**: dot product em `arm32_kernels.S`
- **Fallback em C**: compila e roda fora de ARM32 para smoke test

## O que não é
- Não é PyTorch.
- Não depende de BLAS, NumPy, protobuf ou bibliotecas externas.
- Não é trainer completo de grande porte.
- Não tem abstrações pesadas, templates, OOP ou framework.

## Estrutura
- `src/main.c`                CLI
- `src/model.c/.h`            loader, forward, sampling
- `src/kernels.c/.h`          kernels C + binding
- `src/arm32_kernels.S`       kernel ARM32 em ASM
- `tools/make_toy_model.c`    gera um modelo binário de teste
- `Makefile`                  build host + arm32
- `MODEL_FORMAT.md`           layout binário do modelo

## Build

### Host (teste rápido, usa fallback em C)
```sh
make clean
make host
```

### ARM32 Linux hard-float (usa ASM)
```sh
make clean
make arm32
```

## Gerar modelo de teste
```sh
./build/host/make_toy_model models/toy.bin
```

## Rodar geração
```sh
./build/host/nanogpt_arm32 models/toy.bin "Ola mundo\n" 64 0.9 32
```

Parâmetros:
1. caminho do modelo
2. prompt inicial
3. número de tokens a gerar
4. temperatura
5. top-k

## Observações técnicas
- O projeto recompõe a sequência inteira a cada token gerado. Isso simplifica a implementação.
- O kernel em ASM acelera o dot product; o restante fica em C cru.
- O `lm_head` é amarrado ao `token_embedding` (weight tying).
- O modelo de teste gera **gibberish**. Ele existe para validar pipeline, formato binário e execução.

## Próximo passo para virar um “nanoGPT de verdade”
1. adicionar treino SGD/Adam em C,
2. adicionar KV-cache por camada,
3. suportar checkpoint compatível com um exportador externo,
4. trocar byte tokenizer por BPE real,
5. otimizar matvec em NEON/VFP com kernels adicionais.

## Licença
Uso livre para estudo e engenharia reversa do pipeline transformer.
