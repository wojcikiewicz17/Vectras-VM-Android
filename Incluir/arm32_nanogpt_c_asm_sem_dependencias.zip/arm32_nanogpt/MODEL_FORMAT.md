# MODEL_FORMAT.md

## Header
Todos os campos são little-endian.

```c
typedef struct {
    uint32_t magic;      // 'NGPT' = 0x5447504e
    uint32_t version;    // 1
    uint32_t vocab_size; // fixo em 256 no toy
    uint32_t dim;
    uint32_t hidden_dim;
    uint32_t n_layers;
    uint32_t n_heads;
    uint32_t seq_len;
} ModelHeader;
```

## Pesos na ordem
Todos como `float32`.

1. `token_embedding`        `[vocab_size, dim]`
2. `position_embedding`     `[seq_len, dim]`

Para cada camada `l` em `0..n_layers-1`:
3. `ln1_g`                  `[dim]`
4. `ln1_b`                  `[dim]`
5. `wq`                     `[dim, dim]`
6. `wk`                     `[dim, dim]`
7. `wv`                     `[dim, dim]`
8. `wo`                     `[dim, dim]`
9. `ln2_g`                  `[dim]`
10. `ln2_b`                 `[dim]`
11. `fc1`                   `[hidden_dim, dim]`
12. `fc1_b`                 `[hidden_dim]`
13. `fc2`                   `[dim, hidden_dim]`
14. `fc2_b`                 `[dim]`

Final:
15. `lnf_g`                 `[dim]`
16. `lnf_b`                 `[dim]`

## Observação
- O `lm_head` não é salvo separado: usa `token_embedding^T`.
- O formato foi mantido propositalmente simples para leitura direta por `fread()`.
