Pacote de submissão — modelo dinâmico ABNT

Conteúdo principal:
- artigo_modelo_dinamico_abnt.docx  -> manuscrito final em formato DOCX
- artigo_modelo_dinamico_abnt.pdf   -> manuscrito final em PDF
- modelo_dinamico_avancado.py       -> script com simulação, estimação paramétrica,
                                       análise de sensibilidade e mapas de regime
- pasta saida_demo/                 -> figuras, tabelas CSV e resumos JSON gerados pelo script

Arquivos de apoio gerados pelo script:
- ajuste_amplitude.png
- ajuste_fase.png
- sensibilidade_local.png
- mapa_regime_amplitude.png
- mapa_regime_categorico.png
- mapa_regime_fase.png
- comparacao_parametros.csv
- sensibilidade_local.csv
- series_verdadeiras.csv
- series_observadas.csv
- series_estimadas.csv
- resumo_estimacao.json
- sumario_geral.json

Execução básica:
python modelo_dinamico_avancado.py --output-dir saida_demo
