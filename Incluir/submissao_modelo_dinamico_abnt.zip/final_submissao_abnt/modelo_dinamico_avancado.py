#!/usr/bin/env python3
"""
Modelo dinâmico discreto não linear com saída complexa.

Recursos principais:
- simulação com sinais sintéticos controlados;
- geração de observações ruidosas;
- estimação de parâmetros por differential evolution + least_squares;
- análise de sensibilidade local por diferenças finitas;
- mapas de regime em grades bidimensionais;
- exportação de séries, métricas e figuras.

Exemplo de uso:
    python modelo_dinamico_avancado.py --output-dir saida_abnt
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import differential_evolution, least_squares


PARAMETER_NAMES = [
    "alpha",
    "beta",
    "gamma",
    "delta",
    "epsilon",
    "eta",
    "omega",
    "kappa",
    "bias",
]


@dataclass
class Params:
    alpha: float = 0.90
    beta: float = 0.55
    gamma: float = 0.40
    delta: float = 0.65
    epsilon: float = 0.70
    eta: float = 0.35
    omega: float = 0.18
    kappa: float = 0.22
    bias: float = 0.00
    noise_std: float = 0.00

    def to_vector(self) -> np.ndarray:
        return np.array([getattr(self, name) for name in PARAMETER_NAMES], dtype=float)

    @classmethod
    def from_vector(cls, x: np.ndarray, noise_std: float = 0.0) -> "Params":
        values = {name: float(v) for name, v in zip(PARAMETER_NAMES, x)}
        values["noise_std"] = float(noise_std)
        return cls(**values)


def clamp(x: np.ndarray, low: float = -1.0, high: float = 1.0) -> np.ndarray:
    return np.clip(x, low, high)


def wrap_phase(x: np.ndarray) -> np.ndarray:
    return (x + np.pi) % (2 * np.pi) - np.pi


def generate_inputs(steps: int, seed: int = 42) -> Dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    t = np.arange(steps)

    I = 0.55 + 0.25 * np.sin(2 * np.pi * t / 55.0) + 0.08 * rng.normal(size=steps)
    E = 0.10 + 0.35 * np.sin(2 * np.pi * t / 37.0 + 0.8) + 0.06 * rng.normal(size=steps)
    P = 0.18 * np.sin(2 * np.pi * t / 23.0 + 1.1) + 0.14 * np.sin(2 * np.pi * t / 71.0)
    V = 0.40 + 0.20 * np.sin(2 * np.pi * t / 48.0 + 0.2) + 0.05 * rng.normal(size=steps)
    G = 0.45 + 0.10 * np.sin(2 * np.pi * t / 90.0 + 2.0)
    O = 0.20 + 0.22 * np.sin(2 * np.pi * t / 64.0 + 1.5) + 0.05 * rng.normal(size=steps)

    return {
        "I": clamp(I),
        "E": clamp(E),
        "P": clamp(P),
        "V": clamp(V),
        "G": np.clip(G, 0.0, 1.0),
        "O": clamp(O),
    }


def simulate(
    params: Params,
    signals: Dict[str, np.ndarray],
    A0: float = 0.0,
    phi0: float = 0.0,
    seed: int = 42,
) -> pd.DataFrame:
    n = len(next(iter(signals.values())))
    rng = np.random.default_rng(seed)

    A = np.zeros(n)
    phi = np.zeros(n)
    psi_real = np.zeros(n)
    psi_imag = np.zeros(n)
    magnitude = np.zeros(n)

    A[0] = A0
    phi[0] = phi0
    psi_real[0] = A0 * np.cos(phi0)
    psi_imag[0] = A0 * np.sin(phi0)
    magnitude[0] = np.abs(A0)

    for t in range(n - 1):
        drive = (
            params.alpha * signals["I"][t]
            + params.beta * signals["E"][t]
            + params.gamma * signals["P"][t]
            - params.delta * signals["G"][t]
            + params.epsilon * signals["V"][t]
            - params.eta * signals["O"][t]
            + params.bias
        )
        noise = params.noise_std * rng.normal()
        A[t + 1] = np.tanh(drive + noise)
        phi[t + 1] = phi[t] + params.omega + params.kappa * signals["E"][t]
        psi_real[t + 1] = A[t + 1] * np.cos(phi[t + 1])
        psi_imag[t + 1] = A[t + 1] * np.sin(phi[t + 1])
        magnitude[t + 1] = np.hypot(psi_real[t + 1], psi_imag[t + 1])

    return pd.DataFrame(
        {
            "t": np.arange(n),
            "I_t": signals["I"],
            "E_t": signals["E"],
            "P_t": signals["P"],
            "V_t": signals["V"],
            "G_t": signals["G"],
            "O_t": signals["O"],
            "A_t": A,
            "phi_t": phi,
            "psi_real": psi_real,
            "psi_imag": psi_imag,
            "abs_psi": magnitude,
        }
    )


def summarize(df: pd.DataFrame) -> Dict[str, float]:
    dphi = np.diff(df["phi_t"].to_numpy())
    return {
        "A_media": float(df["A_t"].mean()),
        "A_desvio": float(df["A_t"].std(ddof=0)),
        "velocidade_angular_media": float(dphi.mean()) if len(dphi) else 0.0,
        "velocidade_angular_desvio": float(dphi.std(ddof=0)) if len(dphi) else 0.0,
        "modulo_medio": float(df["abs_psi"].mean()),
        "psi_real_desvio": float(df["psi_real"].std(ddof=0)),
        "psi_imag_desvio": float(df["psi_imag"].std(ddof=0)),
    }


def build_observed_dataset(
    true_df: pd.DataFrame,
    amplitude_noise: float = 0.025,
    phase_noise: float = 0.02,
    seed: int = 123,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    obs = true_df.copy()
    obs["A_obs"] = clamp(obs["A_t"].to_numpy() + amplitude_noise * rng.normal(size=len(obs)))
    obs["phi_obs"] = obs["phi_t"].to_numpy() + phase_noise * rng.normal(size=len(obs))
    obs["dphi_obs"] = np.r_[0.0, np.diff(obs["phi_obs"].to_numpy())]
    return obs


def residuals_from_vector(x: np.ndarray, signals: Dict[str, np.ndarray], observed: pd.DataFrame) -> np.ndarray:
    params = Params.from_vector(x)
    pred = simulate(params, signals, A0=float(observed["A_obs"].iloc[0]), phi0=float(observed["phi_obs"].iloc[0]))

    amp_res = pred["A_t"].to_numpy()[1:] - observed["A_obs"].to_numpy()[1:]
    dphi_pred = np.diff(pred["phi_t"].to_numpy())
    dphi_obs = np.diff(observed["phi_obs"].to_numpy())
    phase_res = wrap_phase(dphi_pred - dphi_obs)
    return np.concatenate([amp_res, phase_res])


def objective_sse(x: np.ndarray, signals: Dict[str, np.ndarray], observed: pd.DataFrame) -> float:
    r = residuals_from_vector(x, signals, observed)
    return float(np.mean(r**2))


def estimate_parameters(
    signals: Dict[str, np.ndarray],
    observed: pd.DataFrame,
    bounds: List[Tuple[float, float]],
    seed: int = 123,
) -> Dict[str, object]:
    de_result = differential_evolution(
        objective_sse,
        bounds=bounds,
        args=(signals, observed),
        seed=seed,
        polish=False,
        maxiter=80,
        popsize=12,
        tol=1e-4,
    )
    ls_result = least_squares(
        residuals_from_vector,
        x0=de_result.x,
        bounds=np.array(bounds).T,
        args=(signals, observed),
        method="trf",
        loss="soft_l1",
        f_scale=0.1,
        max_nfev=10000,
    )

    est_params = Params.from_vector(ls_result.x)
    pred = simulate(est_params, signals, A0=float(observed["A_obs"].iloc[0]), phi0=float(observed["phi_obs"].iloc[0]))
    fit = compute_fit_metrics(pred, observed)
    return {
        "de_result": de_result,
        "ls_result": ls_result,
        "estimated_params": est_params,
        "predicted_df": pred,
        "fit_metrics": fit,
    }


def compute_fit_metrics(pred: pd.DataFrame, observed: pd.DataFrame) -> Dict[str, float]:
    amp_err = pred["A_t"].to_numpy()[1:] - observed["A_obs"].to_numpy()[1:]
    phase_step_err = wrap_phase(np.diff(pred["phi_t"].to_numpy()) - np.diff(observed["phi_obs"].to_numpy()))
    amp_rmse = float(np.sqrt(np.mean(amp_err**2)))
    phase_step_rmse = float(np.sqrt(np.mean(phase_step_err**2)))

    a_true = observed["A_obs"].to_numpy()[1:]
    a_pred = pred["A_t"].to_numpy()[1:]
    ss_res = float(np.sum((a_true - a_pred) ** 2))
    ss_tot = float(np.sum((a_true - a_true.mean()) ** 2))
    r2_amp = 1.0 - ss_res / ss_tot if ss_tot > 0 else np.nan

    return {
        "amp_rmse": amp_rmse,
        "phase_step_rmse": phase_step_rmse,
        "amp_r2": r2_amp,
        "objective_mse": float(np.mean(np.r_[amp_err, phase_step_err] ** 2)),
    }


def local_sensitivity_analysis(
    baseline: Params,
    signals: Dict[str, np.ndarray],
    observed: pd.DataFrame,
    rel_step: float = 0.05,
) -> pd.DataFrame:
    base_vec = baseline.to_vector()
    baseline_pred = simulate(baseline, signals, A0=float(observed["A_obs"].iloc[0]), phi0=float(observed["phi_obs"].iloc[0]))
    base_summary = summarize(baseline_pred)
    base_fit = compute_fit_metrics(baseline_pred, observed)

    metrics = {
        "A_media": base_summary["A_media"],
        "A_desvio": base_summary["A_desvio"],
        "velocidade_angular_media": base_summary["velocidade_angular_media"],
        "modulo_medio": base_summary["modulo_medio"],
        "fit_rmse_amplitude": base_fit["amp_rmse"],
        "fit_rmse_passo_fase": base_fit["phase_step_rmse"],
    }

    rows = []
    for i, name in enumerate(PARAMETER_NAMES):
        step = rel_step * max(abs(base_vec[i]), 0.1)
        x_minus = base_vec.copy()
        x_plus = base_vec.copy()
        x_minus[i] -= step
        x_plus[i] += step

        p_minus = Params.from_vector(x_minus)
        p_plus = Params.from_vector(x_plus)
        df_minus = simulate(p_minus, signals, A0=float(observed["A_obs"].iloc[0]), phi0=float(observed["phi_obs"].iloc[0]))
        df_plus = simulate(p_plus, signals, A0=float(observed["A_obs"].iloc[0]), phi0=float(observed["phi_obs"].iloc[0]))
        sum_minus, sum_plus = summarize(df_minus), summarize(df_plus)
        fit_minus, fit_plus = compute_fit_metrics(df_minus, observed), compute_fit_metrics(df_plus, observed)

        row = {"parametro": name, "step": step}
        for metric_name, base_value in metrics.items():
            if metric_name == "fit_rmse_amplitude":
                f_minus = fit_minus["amp_rmse"]
                f_plus = fit_plus["amp_rmse"]
            elif metric_name == "fit_rmse_passo_fase":
                f_minus = fit_minus["phase_step_rmse"]
                f_plus = fit_plus["phase_step_rmse"]
            else:
                f_minus = sum_minus[metric_name]
                f_plus = sum_plus[metric_name]

            deriv = (f_plus - f_minus) / (2.0 * step)
            norm_sens = deriv * (base_vec[i] / base_value) if abs(base_value) > 1e-12 else np.nan
            row[metric_name] = norm_sens
        rows.append(row)

    return pd.DataFrame(rows)


def classify_regime(df: pd.DataFrame) -> int:
    a = df["A_t"].to_numpy()
    mean_abs = float(np.mean(np.abs(a)))
    std_a = float(np.std(a))
    zero_crossings = int(np.sum(np.signbit(a[1:]) != np.signbit(a[:-1])))

    if mean_abs > 0.72:
        return 2  # saturado
    if std_a < 0.06 and zero_crossings < 3:
        return 0  # quase fixo
    if std_a > 0.14 or zero_crossings >= 6:
        return 1  # oscilatorio
    return 3  # transicional


def generate_regime_maps(
    base_params: Params,
    signals: Dict[str, np.ndarray],
    n_grid: int = 40,
) -> Dict[str, np.ndarray]:
    alpha_grid = np.linspace(0.1, 2.4, n_grid)
    beta_grid = np.linspace(-0.6, 1.4, n_grid)
    omega_grid = np.linspace(0.02, 0.45, n_grid)
    kappa_grid = np.linspace(0.0, 0.6, n_grid)

    amp_mean_map = np.zeros((n_grid, n_grid))
    regime_map = np.zeros((n_grid, n_grid), dtype=int)
    vel_phase_map = np.zeros((n_grid, n_grid))

    for i, alpha in enumerate(alpha_grid):
        for j, beta in enumerate(beta_grid):
            p = Params.from_vector(base_params.to_vector())
            p.alpha = float(alpha)
            p.beta = float(beta)
            df = simulate(p, signals)
            amp_mean_map[i, j] = float(np.mean(np.abs(df["A_t"].to_numpy())))
            regime_map[i, j] = classify_regime(df)

    for i, omega in enumerate(omega_grid):
        for j, kappa in enumerate(kappa_grid):
            p = Params.from_vector(base_params.to_vector())
            p.omega = float(omega)
            p.kappa = float(kappa)
            df = simulate(p, signals)
            vel_phase_map[i, j] = float(np.mean(np.diff(df["phi_t"].to_numpy())))

    return {
        "alpha_grid": alpha_grid,
        "beta_grid": beta_grid,
        "omega_grid": omega_grid,
        "kappa_grid": kappa_grid,
        "amp_mean_map": amp_mean_map,
        "regime_map": regime_map,
        "vel_phase_map": vel_phase_map,
    }


def save_main_plots(
    true_df: pd.DataFrame,
    observed: pd.DataFrame,
    predicted: pd.DataFrame,
    sensitivity_df: pd.DataFrame,
    regime_maps: Dict[str, np.ndarray],
    outdir: Path,
) -> None:
    outdir.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(10, 4.8))
    plt.plot(true_df["t"], true_df["A_t"], label="A verdadeiro")
    plt.plot(observed["t"], observed["A_obs"], label="A observado", alpha=0.8)
    plt.plot(predicted["t"], predicted["A_t"], label="A estimado", linewidth=1.8)
    plt.xlabel("t")
    plt.ylabel("Amplitude")
    plt.title("Recuperação da amplitude")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outdir / "ajuste_amplitude.png", dpi=180)
    plt.close()

    plt.figure(figsize=(10, 4.8))
    plt.plot(true_df["t"], true_df["phi_t"], label="Fase verdadeira")
    plt.plot(observed["t"], observed["phi_obs"], label="Fase observada", alpha=0.8)
    plt.plot(predicted["t"], predicted["phi_t"], label="Fase estimada", linewidth=1.8)
    plt.xlabel("t")
    plt.ylabel("Fase")
    plt.title("Recuperação da fase")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outdir / "ajuste_fase.png", dpi=180)
    plt.close()

    sens_matrix = sensitivity_df.set_index("parametro")[[
        "A_media",
        "A_desvio",
        "velocidade_angular_media",
        "modulo_medio",
        "fit_rmse_amplitude",
        "fit_rmse_passo_fase",
    ]]
    plt.figure(figsize=(10, 5.8))
    plt.imshow(sens_matrix.to_numpy(), aspect="auto")
    plt.xticks(range(sens_matrix.shape[1]), sens_matrix.columns, rotation=30, ha="right")
    plt.yticks(range(sens_matrix.shape[0]), sens_matrix.index)
    plt.colorbar(label="Sensibilidade normalizada")
    plt.title("Análise de sensibilidade local")
    plt.tight_layout()
    plt.savefig(outdir / "sensibilidade_local.png", dpi=180)
    plt.close()

    plt.figure(figsize=(6.6, 5.5))
    plt.imshow(
        regime_maps["amp_mean_map"],
        origin="lower",
        aspect="auto",
        extent=[
            regime_maps["beta_grid"][0],
            regime_maps["beta_grid"][-1],
            regime_maps["alpha_grid"][0],
            regime_maps["alpha_grid"][-1],
        ],
    )
    plt.xlabel("beta")
    plt.ylabel("alpha")
    plt.title("Mapa de regime: média de |A_t|")
    plt.colorbar(label="média de |A_t|")
    plt.tight_layout()
    plt.savefig(outdir / "mapa_regime_amplitude.png", dpi=180)
    plt.close()

    plt.figure(figsize=(6.6, 5.5))
    plt.imshow(
        regime_maps["regime_map"],
        origin="lower",
        aspect="auto",
        extent=[
            regime_maps["beta_grid"][0],
            regime_maps["beta_grid"][-1],
            regime_maps["alpha_grid"][0],
            regime_maps["alpha_grid"][-1],
        ],
    )
    plt.xlabel("beta")
    plt.ylabel("alpha")
    plt.title("Mapa categórico de regimes")
    plt.colorbar(label="0=fixed, 1=oscilatório, 2=saturado, 3=transicional")
    plt.tight_layout()
    plt.savefig(outdir / "mapa_regime_categorico.png", dpi=180)
    plt.close()

    plt.figure(figsize=(6.6, 5.5))
    plt.imshow(
        regime_maps["vel_phase_map"],
        origin="lower",
        aspect="auto",
        extent=[
            regime_maps["kappa_grid"][0],
            regime_maps["kappa_grid"][-1],
            regime_maps["omega_grid"][0],
            regime_maps["omega_grid"][-1],
        ],
    )
    plt.xlabel("kappa")
    plt.ylabel("omega")
    plt.title("Mapa de regime: velocidade angular média")
    plt.colorbar(label="média de Δfase")
    plt.tight_layout()
    plt.savefig(outdir / "mapa_regime_fase.png", dpi=180)
    plt.close()


def save_tables_and_json(
    outdir: Path,
    true_params: Params,
    est_params: Params,
    fit_metrics: Dict[str, float],
    sensitivity_df: pd.DataFrame,
    true_df: pd.DataFrame,
    observed: pd.DataFrame,
    predicted: pd.DataFrame,
    regime_maps: Dict[str, np.ndarray],
) -> None:
    outdir.mkdir(parents=True, exist_ok=True)

    comparison = pd.DataFrame({
        "parametro": PARAMETER_NAMES,
        "verdadeiro": true_params.to_vector(),
        "estimado": est_params.to_vector(),
    })
    comparison["erro_abs"] = np.abs(comparison["estimado"] - comparison["verdadeiro"])
    comparison["erro_rel_%"] = np.where(
        np.abs(comparison["verdadeiro"]) > 1e-12,
        100 * comparison["erro_abs"] / np.abs(comparison["verdadeiro"]),
        np.nan,
    )

    comparison.to_csv(outdir / "comparacao_parametros.csv", index=False)
    sensitivity_df.to_csv(outdir / "sensibilidade_local.csv", index=False)
    true_df.to_csv(outdir / "series_verdadeiras.csv", index=False)
    observed.to_csv(outdir / "series_observadas.csv", index=False)
    predicted.to_csv(outdir / "series_estimadas.csv", index=False)

    regime_summary = {
        "amp_mean_min": float(np.min(regime_maps["amp_mean_map"])),
        "amp_mean_max": float(np.max(regime_maps["amp_mean_map"])),
        "phase_vel_min": float(np.min(regime_maps["vel_phase_map"])),
        "phase_vel_max": float(np.max(regime_maps["vel_phase_map"])),
    }

    with open(outdir / "resumo_estimacao.json", "w", encoding="utf-8") as f:
        json.dump({
            "fit_metrics": fit_metrics,
            "regime_summary": regime_summary,
        }, f, ensure_ascii=False, indent=2)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Simulação, estimação e análise de regimes do modelo dinâmico.")
    parser.add_argument("--steps", type=int, default=180, help="Número de passos da série temporal.")
    parser.add_argument("--seed", type=int, default=42, help="Semente para reprodutibilidade.")
    parser.add_argument("--output-dir", type=Path, default=Path("saida_modelo_avancado"), help="Diretório de saída.")
    parser.add_argument("--amplitude-noise", type=float, default=0.025, help="Ruído nas observações de amplitude.")
    parser.add_argument("--phase-noise", type=float, default=0.02, help="Ruído nas observações de fase.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    outdir = args.output_dir
    outdir.mkdir(parents=True, exist_ok=True)

    true_params = Params()
    signals = generate_inputs(args.steps, seed=args.seed)
    true_df = simulate(true_params, signals, seed=args.seed)
    observed = build_observed_dataset(true_df, amplitude_noise=args.amplitude_noise, phase_noise=args.phase_noise, seed=args.seed + 1)

    bounds = [
        (0.0, 1.5),   # alpha
        (-0.3, 1.2),  # beta
        (-0.2, 1.2),  # gamma
        (0.0, 1.2),   # delta
        (0.0, 1.2),   # epsilon
        (0.0, 1.2),   # eta
        (0.0, 0.5),   # omega
        (0.0, 0.8),   # kappa
        (-0.5, 0.5),  # bias
    ]
    estimation = estimate_parameters(signals, observed, bounds=bounds, seed=args.seed + 2)
    est_params = estimation["estimated_params"]
    predicted = estimation["predicted_df"]
    fit_metrics = estimation["fit_metrics"]

    sensitivity_df = local_sensitivity_analysis(est_params, signals, observed, rel_step=0.05)
    regime_maps = generate_regime_maps(est_params, signals, n_grid=40)

    save_main_plots(true_df, observed, predicted, sensitivity_df, regime_maps, outdir)
    save_tables_and_json(outdir, true_params, est_params, fit_metrics, sensitivity_df, true_df, observed, predicted, regime_maps)

    summary = {
        "true_params": asdict(true_params),
        "estimated_params": asdict(est_params),
        "fit_metrics": fit_metrics,
        "true_summary": summarize(true_df),
        "estimated_summary": summarize(predicted),
    }
    with open(outdir / "sumario_geral.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
