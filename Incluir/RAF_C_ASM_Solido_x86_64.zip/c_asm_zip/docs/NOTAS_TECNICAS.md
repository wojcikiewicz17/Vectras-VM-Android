# Notas técnicas

## Decisões de projeto

### 1. C como referência
A implementação em C define o comportamento esperado e facilita auditoria, testes e manutenção.

### 2. ASM apenas no hot path
O uso de assembly foi restrito a rotinas pequenas e bem delimitadas:

- produto escalar de `float`
- leitura de contador de ciclos

Isso reduz risco de manutenção e mantém clareza arquitetural.

### 3. Tolerância de comparação
O self-test usa tolerância por ponto flutuante para aceitar diferenças mínimas de acumulação entre C e ASM.

## ABI usada

- arquitetura: x86_64
- calling convention: System V AMD64 ABI
- argumentos principais:
  - `rdi`, `rsi`, `rdx`
- retorno `float`: `xmm0`
- retorno `uint64_t`: `rax`

## Sobre o modelo de estado

O modelo não pretende ser uma teoria física. Aqui ele funciona como:

- exemplo de estado escalar atualizado por múltiplas entradas;
- caso de uso plausível para misturar C de alto nível com ASM de baixo nível;
- base para benchmarks, tracing e expansão posterior.
