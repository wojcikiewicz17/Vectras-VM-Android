# RAF Semantic Core — C + ASM (x86_64 SysV)

Projeto enxuto e compilável que combina:

- **C** como implementação de referência e lógica de domínio;
- **ASM x86_64 (SysV ABI)** para rotinas de baixo nível;
- **self-test** comparando C e ASM;
- **benchmark** simples com `rdtsc` e `clock_gettime`.

## O que o projeto faz

Ele implementa um núcleo mínimo de atualização de estado inspirado em dinâmica semântica:

- projeção de um vetor de entrada em pesos (`dot product`);
- atualização não linear com `tanh`;
- fase acumulada;
- medida simples de coerência temporal.

A parte em Assembly foi colocada onde faz mais sentido técnico:

- `raf_dot_f32_asm` — produto escalar de `float` com blocos SSE;
- `raf_rdtsc_asm` — leitura de ciclo de CPU para benchmark.

## Estrutura

```text
include/raf_core.h        API pública
src/raf_core.c            referência em C e atualização de estado
src/selftest.c            comparação C x ASM
src/main.c                demo + benchmark opcional
asm/raf_x86_64_sysv.S     rotinas Assembly
tests/test_cli.sh         teste rápido de execução
Makefile                  build local
```

## Requisitos

- Linux x86_64
- GCC ou Clang
- libc com `clock_gettime`
- ABI SysV

## Compilar

```bash
make
```

## Executar demo

```bash
make run
```

## Executar benchmark

```bash
make bench
```

## Executar teste rápido

```bash
make test
```

## Saída esperada

A demo imprime:

- confirmação do self-test;
- tabela temporal com `S_t`, `phi_t` e `coherence`.

Com `--bench`, imprime também tempos e ciclos aproximados para:

- implementação C
- implementação ASM

## Observações de engenharia

1. O código ASM assume **x86_64 SysV**.
2. O `dot product` usa SSE com bloco de 4 `float`s e cauda escalar.
3. O benchmark é **indicativo**, não substitui `perf`, `pmu` ou metodologia controlada.
4. O projeto foi mantido deliberadamente pequeno para servir de base de expansão.

## Próximas extensões naturais

- versão AVX2 / FMA
- dispatch por feature (`cpuid`)
- build para Windows x64
- porta ARM64 (AArch64)
- parser de traços de execução para inferência de intenção
- integração com `perf` / `ftrace`

## Licença

Uso livre para estudo, adaptação e experimentação.
