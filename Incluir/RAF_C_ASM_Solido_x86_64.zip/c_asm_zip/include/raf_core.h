#ifndef RAF_CORE_H
#define RAF_CORE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float alpha;
    float beta;
    float gamma;
    float delta;
    float epsilon;
    float eta;
    float memory;
} RafWeights;

typedef struct {
    float s;
    float phi;
    float coherence;
} RafState;

/* C reference implementations */
float raf_dot_f32_c(const float *a, const float *b, size_t n);
uint64_t raf_rdtsc_c(void);

/* x86_64 SysV assembly implementations */
float raf_dot_f32_asm(const float *a, const float *b, size_t n);
uint64_t raf_rdtsc_asm(void);

/* Shared API */
float raf_project_signal(const float inputs[6], const RafWeights *w, int use_asm);
void raf_update_state(RafState *st,
                      const float inputs[6],
                      const RafWeights *w,
                      float omega,
                      float kappa,
                      int use_asm);
void raf_run_sequence(RafState *st,
                      const float *series_inputs,
                      size_t steps,
                      const RafWeights *w,
                      float omega,
                      float kappa,
                      int use_asm);

int raf_selftest(float tolerance);

#ifdef __cplusplus
}
#endif

#endif /* RAF_CORE_H */
