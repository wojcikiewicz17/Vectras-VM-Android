#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

make clean >/dev/null 2>&1 || true
make >/dev/null

OUTPUT="$(./build/raf_demo)"
echo "$OUTPUT" | grep -q "selftest: OK"
echo "$OUTPUT" | grep -q "RAF semantic core demo"

echo "teste CLI: OK"
