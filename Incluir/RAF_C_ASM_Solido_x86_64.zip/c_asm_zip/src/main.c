#define _POSIX_C_SOURCE 200809L
#include "raf_core.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static void fill_series(float *series, size_t steps) {
    for (size_t t = 0; t < steps; ++t) {
        const float x = (float)t / (float)(steps ? steps : 1U);
        series[t * 6U + 0U] = 0.80f + 0.10f * x;             /* I */
        series[t * 6U + 1U] = 0.05f + 0.25f * (1.0f - x);    /* E */
        series[t * 6U + 2U] = 0.10f + 0.20f * x;             /* P */
        series[t * 6U + 3U] = 0.35f;                         /* G */
        series[t * 6U + 4U] = 0.70f + 0.05f * x;             /* V */
        series[t * 6U + 5U] = 0.20f + 0.10f * (1.0f - x);    /* O */
    }
}

static double now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1e9 + (double)ts.tv_nsec;
}

static void run_benchmark(void) {
    enum { N = 1 << 20, ROUNDS = 200 };
    float *a = (float *)malloc(sizeof(float) * N);
    float *b = (float *)malloc(sizeof(float) * N);
    if (!a || !b) {
        fprintf(stderr, "falha ao alocar buffers do benchmark\n");
        free(a);
        free(b);
        return;
    }

    for (size_t i = 0; i < (size_t)N; ++i) {
        a[i] = (float)(i & 1023U) / 1024.0f;
        b[i] = (float)((i * 3U) & 1023U) / 1024.0f;
    }

    volatile float sink = 0.0f;

    const uint64_t c0 = raf_rdtsc_asm();
    const double t0 = now_ns();
    for (int r = 0; r < ROUNDS; ++r) {
        sink += raf_dot_f32_c(a, b, (size_t)N);
    }
    const double t1 = now_ns();
    const uint64_t c1 = raf_rdtsc_asm();

    const uint64_t c2 = raf_rdtsc_asm();
    const double t2 = now_ns();
    for (int r = 0; r < ROUNDS; ++r) {
        sink += raf_dot_f32_asm(a, b, (size_t)N);
    }
    const double t3 = now_ns();
    const uint64_t c3 = raf_rdtsc_asm();

    printf("\n[benchmark dot_f32]\n");
    printf("C   : %8.3f ms | cycles ~= %llu\n", (t1 - t0) / 1e6,
           (unsigned long long)(c1 - c0));
    printf("ASM : %8.3f ms | cycles ~= %llu\n", (t3 - t2) / 1e6,
           (unsigned long long)(c3 - c2));
    printf("sink(ignore) = %.3f\n", sink);

    free(a);
    free(b);
}

int main(int argc, char **argv) {
    const int run_bench = (argc > 1 && strcmp(argv[1], "--bench") == 0);
    const RafWeights w = {
        .alpha = 0.95f,
        .beta = -0.55f,
        .gamma = 0.40f,
        .delta = -0.20f,
        .epsilon = 0.75f,
        .eta = 0.35f,
        .memory = 0.30f,
    };

    RafState st = {0.0f, 0.0f, 1.0f};
    float series[12U * 6U];
    fill_series(series, 12U);

    if (!raf_selftest(1e-4f)) {
        fprintf(stderr, "selftest falhou: C e ASM divergiram acima da tolerancia\n");
        return 1;
    }

    printf("RAF semantic core demo (C + ASM)\n");
    printf("selftest: OK\n\n");
    printf(" t |    S_t    |   phi_t   | coherence\n");
    printf("---+-----------+-----------+-----------\n");

    for (size_t t = 0; t < 12U; ++t) {
        raf_update_state(&st, &series[t * 6U], &w, 0.13f, 0.07f, 1);
        printf("%2zu | % .6f | % .6f | % .6f\n", t + 1U, st.s, st.phi, st.coherence);
    }

    if (run_bench) {
        run_benchmark();
    }

    return 0;
}
