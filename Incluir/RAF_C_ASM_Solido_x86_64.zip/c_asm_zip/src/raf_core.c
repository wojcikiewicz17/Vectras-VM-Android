#include "raf_core.h"

#include <math.h>
#include <stdint.h>

float raf_dot_f32_c(const float *a, const float *b, size_t n) {
    float acc = 0.0f;
    for (size_t i = 0; i < n; ++i) {
        acc += a[i] * b[i];
    }
    return acc;
}

uint64_t raf_rdtsc_c(void) {
#if defined(__x86_64__) || defined(__i386__)
    unsigned int lo = 0U;
    unsigned int hi = 0U;
    __asm__ __volatile__("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32U) | lo;
#else
    return 0U;
#endif
}

float raf_project_signal(const float inputs[6], const RafWeights *w, int use_asm) {
    const float coeffs[6] = {
        w->alpha,
        w->beta,
        w->gamma,
        w->delta,
        w->epsilon,
        -w->eta,
    };

    if (use_asm) {
        return raf_dot_f32_asm(inputs, coeffs, 6U);
    }
    return raf_dot_f32_c(inputs, coeffs, 6U);
}

void raf_update_state(RafState *st,
                      const float inputs[6],
                      const RafWeights *w,
                      float omega,
                      float kappa,
                      int use_asm) {
    const float prev_s = st->s;
    const float projected = raf_project_signal(inputs, w, use_asm);
    const float mixed = projected + (w->memory * prev_s);

    st->s = tanhf(mixed);
    st->phi = st->phi + omega + (kappa * inputs[1]);
    st->coherence = 1.0f / (1.0f + fabsf(st->s - prev_s));
}

void raf_run_sequence(RafState *st,
                      const float *series_inputs,
                      size_t steps,
                      const RafWeights *w,
                      float omega,
                      float kappa,
                      int use_asm) {
    for (size_t t = 0; t < steps; ++t) {
        raf_update_state(st, &series_inputs[t * 6U], w, omega, kappa, use_asm);
    }
}
