#include "raf_core.h"

#include <math.h>
#include <stddef.h>
#include <stdint.h>

static uint32_t raf_lcg(uint32_t *state) {
    *state = (*state * 1664525u) + 1013904223u;
    return *state;
}

static float raf_rand_unit(uint32_t *state) {
    const uint32_t v = raf_lcg(state);
    return ((float)(v & 0x00FFFFFFu) / 16777215.0f) * 2.0f - 1.0f;
}

int raf_selftest(float tolerance) {
    float a[257];
    float b[257];
    uint32_t seed = 0xC0FFEE11u;

    for (size_t i = 0; i < 257U; ++i) {
        a[i] = raf_rand_unit(&seed);
        b[i] = raf_rand_unit(&seed);
    }

    for (size_t n = 0; n <= 257U; ++n) {
        const float c_ref = raf_dot_f32_c(a, b, n);
        const float a_ref = raf_dot_f32_asm(a, b, n);
        const float diff = fabsf(c_ref - a_ref);
        if (diff > tolerance) {
            return 0;
        }
    }

    return 1;
}
