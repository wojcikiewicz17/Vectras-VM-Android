# ZIPDROP — Upload zip em `_incoming/` e o repo se auto-atualiza

## Como usar
1. Coloque seu arquivo `.zip` em **`_incoming/`** (pode ser subpasta também).
2. Faça commit + push.
3. O GitHub Actions **`zipdrop-overlay`** vai:
   - validar o zip (bloqueia caminhos perigosos)
   - aplicar `unzip -o` no root do repo
   - opcionalmente executar `__DELTA__/DELETE_LIST.txt` (se existir)
   - remover o zip (pra não poluir o repo)
   - commitar tudo com mensagem **`[zipdrop] apply delta`**

## Formato opcional para deleções
Se quiser que o zip apague arquivos/pastas ao aplicar, inclua no zip:

`__DELTA__/DELETE_LIST.txt`

Cada linha é um caminho relativo (sem `..` e sem caminhos absolutos).

## Dicas
- Zips em `_incoming/` disparam o workflow em **qualquer branch**.
- Commits do bot são marcados com `[zipdrop]` e não re-disparam o zipdrop.
