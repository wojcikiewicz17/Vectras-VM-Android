#ifndef RMR_MATH_FABRIC_H
#define RMR_MATH_FABRIC_H

#include "rmr_hw_detect.h"

typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned long long u64;

#define RMR_MATH_DOMAINS 8u
#define RMR_MATH_POINTS 9u

typedef enum {
  RMR_DOMAIN_ALGEBRA = 0,
  RMR_DOMAIN_TRIGONOMETRY = 1,
  RMR_DOMAIN_NUMBER_THEORY = 2,
  RMR_DOMAIN_GEOMETRY = 3,
  RMR_DOMAIN_LOGIC = 4,
  RMR_DOMAIN_ANALYSIS = 5,
  RMR_DOMAIN_DISCRETE = 6,
  RMR_DOMAIN_PROBABILITY = 7
} RmR_MathDomain;

typedef struct {
  u32 arch_code;
  u32 register_bits;
  u32 lane_count;
  u32 pin_stride;
  u32 cacheline_bytes;
  u32 page_bytes;
  u32 matrix_seed;
  u32 matrix[RMR_MATH_DOMAINS][RMR_MATH_POINTS];
} RmR_MathFabricPlan;

void RmR_MathFabric_AutodetectPlan(const RmR_HW_Info *hw, RmR_MathFabricPlan *out);
void RmR_MathFabric_VectorMix(const RmR_MathFabricPlan *plan,
                              const u32 in_points[RMR_MATH_POINTS],
                              u32 out_domains[RMR_MATH_DOMAINS]);

/* ─── RAFAELIA Math Fabric Extensions (formula index §16,17,19,29) ────────── */

/**
 * RAFAELIA domain constants embedded in the fabric matrix.
 * These annotate which math domain maps to which RAFAELIA operator.
 */
#define RMR_DOMAIN_SPIRAL     RMR_DOMAIN_GEOMETRY       /* Spiral(n)=(√3/2)^n      */
#define RMR_DOMAIN_TOROID     RMR_DOMAIN_ANALYSIS       /* T_Δπφ=Δ·π·φ            */
#define RMR_DOMAIN_FIBONACCI  RMR_DOMAIN_NUMBER_THEORY  /* F_Rafael modified       */
#define RMR_DOMAIN_TRINITY    RMR_DOMAIN_ALGEBRA        /* Trinity633=A^6·L^3·C^3  */
#define RMR_DOMAIN_ETHICA     RMR_DOMAIN_LOGIC          /* Φ_ethica filter         */
#define RMR_DOMAIN_RETRO      RMR_DOMAIN_DISCRETE       /* RetroΩ feedback         */

/**
 * RAFAELIA extension plan — overlays RAFAELIA-specific constants onto the
 * existing MathFabricPlan. Populated by RmR_MathFabric_RafaeliaExtend().
 */
typedef struct {
    u32 spiral_q16;          /* (√3/2) in Q16.16 = 56756 */
    u32 phi_q16;             /* φ in Q16.16 = 106039       */
    u32 pi_q16;              /* π in Q16.16 = 205887        */
    u32 spiral_pi_phi_q16;   /* (√3/2)^(π·φ) Q16.16 = 23163 */
    u32 r_corr_q16;          /* R_corr ≈ 0.963999  Q16.16   */
    u32 theta_999_sin_pi_q16;/* |π·sin(θ_999)| Q16.16 = 203360 */
    u32 fomega_low;          /* 963 */
    u32 fomega_high;         /* 999 */
    u32 ruler_42;            /* structural ruler = 42 */
    u32 calibration_999;     /* calibration constant = 999 */
} RmR_MathFabricRafaeliaExt;

/**
 * Populate a RafaeliaExt struct with pre-computed constants.
 * No hardware detection needed — these are mathematical constants.
 */
void RmR_MathFabric_RafaeliaExtend(RmR_MathFabricRafaeliaExt *out);

/**
 * Compute Spiral(n) = (√3/2)^n using the fabric's Q16.16 constant.
 * @param ext  populated extension struct
 * @param n    exponent
 * @return (√3/2)^n in Q16.16
 */
u32 RmR_MathFabric_Spiral(const RmR_MathFabricRafaeliaExt *ext, u32 n);

/**
 * Compute one Fibonacci-Rafael step:
 *   F_next = F_n × (√3/2) − |π·sin(θ_999)|  (Q16.16, clamped at 0).
 */
u32 RmR_MathFabric_FibRafaelStep(const RmR_MathFabricRafaeliaExt *ext, u32 fn_q16);

#endif /* RMR_MATH_FABRIC_H */
