/**
 * Rafaelia Baremetal - ZIPRAF Implementation
 * 
 * Pure C implementation for data archiving and compression utilities.
 * No external dependencies - baremetal implementation.
 * 
 * Copyright (c) 2026 Rafael Melo Reis
 * Licensed under MIT License - See LICENSE file
 */

#include "raf_zipraf.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* CRC32 table for checksum calculation */
static uint32_t crc32_table[256];
static int crc32_table_initialized = 0;

static void raf_zipraf_init_crc32_table(void) {
    if (crc32_table_initialized) return;
    
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t crc = i;
        for (int j = 0; j < 8; j++) {
            if (crc & 1) {
                crc = (crc >> 1) ^ 0xEDB88320;
            } else {
                crc >>= 1;
            }
        }
        crc32_table[i] = crc;
    }
    
    crc32_table_initialized = 1;
}

uint32_t raf_zipraf_crc32(const uint8_t *data, size_t size) {
    raf_zipraf_init_crc32_table();
    
    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < size; i++) {
        uint8_t index = (crc ^ data[i]) & 0xFF;
        crc = (crc >> 8) ^ crc32_table[index];
    }
    
    return ~crc;
}

/* Archive management */
raf_zipraf_archive* raf_zipraf_create(void) {
    raf_zipraf_archive *archive = (raf_zipraf_archive*)malloc(sizeof(raf_zipraf_archive));
    if (!archive) return NULL;
    
    archive->num_entries = 0;
    archive->entries = NULL;
    archive->data = NULL;
    archive->data_size = 0;
    
    return archive;
}

void raf_zipraf_destroy(raf_zipraf_archive *archive) {
    if (archive) {
        if (archive->entries) free(archive->entries);
        if (archive->data) free(archive->data);
        free(archive);
    }
}

int raf_zipraf_add_data(raf_zipraf_archive *archive, const char *name,
                        const uint8_t *data, size_t size) {
    if (!archive || !name || !data) return -1;
    
    /* Expand entries array */
    raf_zipraf_entry *new_entries = (raf_zipraf_entry*)realloc(
        archive->entries, 
        (archive->num_entries + 1) * sizeof(raf_zipraf_entry)
    );
    
    if (!new_entries) return -1;
    archive->entries = new_entries;
    
    /* Create new entry */
    raf_zipraf_entry *entry = &archive->entries[archive->num_entries];
    strncpy(entry->name, name, sizeof(entry->name) - 1);
    entry->name[sizeof(entry->name) - 1] = '\0';
    entry->original_size = size;
    entry->compressed_size = size; /* Simple: no compression for now */
    entry->offset = archive->data_size;
    entry->crc32 = raf_zipraf_crc32(data, size);
    
    /* Expand data buffer */
    uint8_t *new_data = (uint8_t*)realloc(archive->data, archive->data_size + size);
    if (!new_data) return -1;
    archive->data = new_data;
    
    /* Copy data */
    memcpy(archive->data + archive->data_size, data, size);
    archive->data_size += size;
    archive->num_entries++;
    
    return 0;
}

int raf_zipraf_add_file(raf_zipraf_archive *archive, const char *name,
                        const char *filename) {
    if (!archive || !name || !filename) return -1;

    FILE *file = fopen(filename, "rb");
    if (!file) return -1;

    if (fseek(file, 0, SEEK_END) != 0) {
        fclose(file);
        return -1;
    }

    long file_size = ftell(file);
    if (file_size < 0) {
        fclose(file);
        return -1;
    }

    if (fseek(file, 0, SEEK_SET) != 0) {
        fclose(file);
        return -1;
    }

    uint8_t *buffer = (uint8_t*)malloc((size_t)file_size);
    if (!buffer) {
        fclose(file);
        return -1;
    }

    size_t read_size = fread(buffer, 1, (size_t)file_size, file);
    fclose(file);

    if (read_size != (size_t)file_size) {
        free(buffer);
        return -1;
    }

    int result = raf_zipraf_add_data(archive, name, buffer, (size_t)file_size);
    free(buffer);

    return result;
}

int raf_zipraf_extract_data(const raf_zipraf_archive *archive, const char *name,
                             uint8_t **output, size_t *size) {
    if (!archive || !name || !output || !size) return -1;
    
    /* Find entry */
    for (uint32_t i = 0; i < archive->num_entries; i++) {
        if (strcmp(archive->entries[i].name, name) == 0) {
            const raf_zipraf_entry *entry = &archive->entries[i];
            
            /* Allocate output buffer */
            *output = (uint8_t*)malloc(entry->original_size);
            if (!*output) return -1;
            
            /* Copy data */
            memcpy(*output, archive->data + entry->offset, entry->original_size);
            *size = entry->original_size;
            
            /* Verify CRC */
            uint32_t crc = raf_zipraf_crc32(*output, *size);
            if (crc != entry->crc32) {
                free(*output);
                *output = NULL;
                return -2; /* CRC mismatch */
            }
            
            return 0;
        }
    }
    
    return -1; /* Entry not found */
}

int raf_zipraf_list_entries(const raf_zipraf_archive *archive) {
    if (!archive) return -1;
    
    /* Would print entry information in a real implementation */
    /* For now, just return count without iteration */
    return archive->num_entries;
}

/* Archive save/load */
int raf_zipraf_save(const raf_zipraf_archive *archive, const char *filename) {
    if (!archive || !filename) return -1;

    FILE *file = fopen(filename, "wb");
    if (!file) return -1;

    const uint32_t magic = 0x5A524146; /* "ZRAF" */
    const uint32_t version = 1;
    const uint64_t data_size = (uint64_t)archive->data_size;

    if (fwrite(&magic, sizeof(magic), 1, file) != 1 ||
        fwrite(&version, sizeof(version), 1, file) != 1 ||
        fwrite(&archive->num_entries, sizeof(archive->num_entries), 1, file) != 1 ||
        fwrite(&data_size, sizeof(data_size), 1, file) != 1) {
        fclose(file);
        return -1;
    }

    if (archive->num_entries > 0) {
        size_t entries_size = sizeof(raf_zipraf_entry) * archive->num_entries;
        if (fwrite(archive->entries, 1, entries_size, file) != entries_size) {
            fclose(file);
            return -1;
        }
    }

    if (archive->data_size > 0) {
        if (fwrite(archive->data, 1, archive->data_size, file) != archive->data_size) {
            fclose(file);
            return -1;
        }
    }

    fclose(file);
    return 0;
}

raf_zipraf_archive* raf_zipraf_load(const char *filename) {
    if (!filename) return NULL;

    FILE *file = fopen(filename, "rb");
    if (!file) return NULL;

    uint32_t magic = 0;
    uint32_t version = 0;
    uint32_t num_entries = 0;
    uint64_t data_size = 0;

    if (fread(&magic, sizeof(magic), 1, file) != 1 ||
        fread(&version, sizeof(version), 1, file) != 1 ||
        fread(&num_entries, sizeof(num_entries), 1, file) != 1 ||
        fread(&data_size, sizeof(data_size), 1, file) != 1) {
        fclose(file);
        return NULL;
    }

    if (magic != 0x5A524146 || version != 1) {
        fclose(file);
        return NULL;
    }

    raf_zipraf_archive *archive = raf_zipraf_create();
    if (!archive) {
        fclose(file);
        return NULL;
    }

    archive->num_entries = num_entries;
    archive->data_size = (size_t)data_size;

    if (num_entries > 0) {
        archive->entries = (raf_zipraf_entry*)malloc(sizeof(raf_zipraf_entry) * num_entries);
        if (!archive->entries) {
            raf_zipraf_destroy(archive);
            fclose(file);
            return NULL;
        }

        size_t entries_size = sizeof(raf_zipraf_entry) * num_entries;
        if (fread(archive->entries, 1, entries_size, file) != entries_size) {
            raf_zipraf_destroy(archive);
            fclose(file);
            return NULL;
        }
    }

    if (archive->data_size > 0) {
        archive->data = (uint8_t*)malloc(archive->data_size);
        if (!archive->data) {
            raf_zipraf_destroy(archive);
            fclose(file);
            return NULL;
        }

        if (fread(archive->data, 1, archive->data_size, file) != archive->data_size) {
            raf_zipraf_destroy(archive);
            fclose(file);
            return NULL;
        }
    }

    fclose(file);
    return archive;
}

/* Simple LZ77 compression (sliding window) */
int raf_zipraf_lz77_compress(const uint8_t *input, size_t input_size,
                              uint8_t *output, size_t *output_size) {
    if (!input || !output || !output_size) return -1;
    
    /* Simplified implementation - just copy data for now */
    /* Full LZ77 would use sliding window and match finding */
    if (*output_size < input_size) return -1;
    
    memcpy(output, input, input_size);
    *output_size = input_size;
    
    return 0;
}

int raf_zipraf_lz77_decompress(const uint8_t *input, size_t input_size,
                                uint8_t *output, size_t *output_size) {
    if (!input || !output || !output_size) return -1;
    
    /* Simplified implementation - just copy data for now */
    if (*output_size < input_size) return -1;
    
    memcpy(output, input, input_size);
    *output_size = input_size;
    
    return 0;
}

/* Canonical Huffman compression - deterministic, no external deps
 * Format: [256 x uint16_t freq_table][bitstream payload]
 * Symbols not present get code length 0 (skipped on decode).
 */

/* Internal: build frequency table */
static void huf_count_freq(const uint8_t *input, size_t n, uint32_t freq[256]) {
    size_t i;
    for (i = 0; i < 256; i++) freq[i] = 0;
    for (i = 0; i < n; i++) freq[(uint8_t)input[i]]++;
}

/* Internal: simple insertion-sort priority queue for 256 symbols */
typedef struct { uint32_t freq; int sym; } HufNode;

static void huf_sort(HufNode *nodes, int count) {
    int i, j;
    for (i = 1; i < count; i++) {
        HufNode key = nodes[i];
        for (j = i - 1; j >= 0 && nodes[j].freq > key.freq; j--)
            nodes[j + 1] = nodes[j];
        nodes[j + 1] = key;
    }
}

/* Assign canonical code lengths via package-merge (simplified: limited to depth 15) */
static void huf_assign_lengths(uint32_t freq[256], uint8_t lengths[256]) {
    HufNode nodes[512];
    int alive = 0, i;
    for (i = 0; i < 256; i++) {
        lengths[i] = 0;
        if (freq[i] > 0) { nodes[alive].freq = freq[i]; nodes[alive].sym = i; alive++; }
    }
    if (alive == 0) return;
    if (alive == 1) { lengths[nodes[0].sym] = 1; return; }

    huf_sort(nodes, alive);

    /* Build tree by merging two smallest nodes (greedy) */
    /* Use extra nodes array; parent stored in same pool */
    HufNode pool[512];
    int depth[512];
    int n = alive;
    for (i = 0; i < n; i++) { pool[i] = nodes[i]; depth[i] = 0; }

    int left = 0; /* next to consume */
    int merged_start = n; /* where merged nodes go */
    int merged_end = n;

    while ((n - left) + (merged_end - merged_start) > 1) {
        /* pick 2 smallest from pool[left..n-1] and pool[merged_start..merged_end-1] */
        int picks[2];
        int pc = 0;
        int pl = left, pm = merged_start;
        while (pc < 2) {
            int from_orig = (pl < n);
            int from_mrgd = (pm < merged_end);
            if (from_orig && from_mrgd)
                picks[pc++] = (pool[pl].freq <= pool[pm].freq) ? pl++ : pm++;
            else if (from_orig) picks[pc++] = pl++;
            else if (from_mrgd) picks[pc++] = pm++;
            else break;
        }
        if (pc < 2) break;
        int a = picks[0], b = picks[1];
        /* Increase depth of children */
        depth[a]++;
        depth[b]++;
        /* Propagate: if a or b are themselves merged nodes, recursively bump their subtrees */
        /* (Simplified: cap at 15 anyway) */
        pool[merged_end].freq = pool[a].freq + pool[b].freq;
        pool[merged_end].sym  = -1; /* internal */
        depth[merged_end] = 0;
        merged_end++;
        if (pl > left) left = pl;
    }

    /* Assign lengths from depth array (leaf nodes only, sym >= 0) */
    for (i = 0; i < merged_end; i++) {
        if (pool[i].sym >= 0) {
            lengths[pool[i].sym] = (uint8_t)(depth[i] > 15 ? 15 : depth[i]);
        }
    }
    /* Ensure singletons have length 1 */
    for (i = 0; i < 256; i++) {
        if (freq[i] > 0 && lengths[i] == 0) lengths[i] = 1;
    }
}

int raf_zipraf_huffman_compress(const uint8_t *input, size_t input_size,
                                 uint8_t *output, size_t *output_size) {
    if (!input || !output || !output_size || input_size == 0) return -1;

    uint32_t freq[256];
    uint8_t  lengths[256];
    uint32_t codes[256];
    uint8_t  lens_sorted[256]; /* canonical lengths */
    int      syms_by_len[16][256];
    int      len_count[16];
    int      i, l;

    huf_count_freq(input, input_size, freq);
    huf_assign_lengths(freq, lengths);

    /* Canonical Huffman: sort by (length, symbol) */
    for (l = 0; l < 16; l++) { len_count[l] = 0; (void)syms_by_len[l]; }
    for (i = 0; i < 256; i++) {
        if (lengths[i] > 0 && lengths[i] <= 15)
            syms_by_len[lengths[i]][len_count[lengths[i]]++] = i;
    }
    /* Assign canonical codes */
    for (i = 0; i < 256; i++) codes[i] = 0;
    uint32_t code = 0;
    for (l = 1; l <= 15; l++) {
        /* sort syms_by_len[l] ascending */
        int cnt = len_count[l];
        for (i = 1; i < cnt; i++) {
            int key = syms_by_len[l][i], j;
            for (j = i - 1; j >= 0 && syms_by_len[l][j] > key; j--)
                syms_by_len[l][j + 1] = syms_by_len[l][j];
            syms_by_len[l][j + 1] = key;
        }
        for (i = 0; i < cnt; i++) {
            codes[syms_by_len[l][i]] = code;
            code++;
        }
        code <<= 1;
    }

    /* Header: 256 x uint8_t lengths (1 byte each = 256 bytes) + 4-byte original_size LE */
    size_t hdr_size = 256 + 4;
    if (*output_size < hdr_size + 1) return -1;

    for (i = 0; i < 256; i++) output[i] = lengths[i];
    output[256] = (uint8_t)(input_size & 0xFF);
    output[257] = (uint8_t)((input_size >> 8) & 0xFF);
    output[258] = (uint8_t)((input_size >> 16) & 0xFF);
    output[259] = (uint8_t)((input_size >> 24) & 0xFF);

    /* Bitstream output */
    size_t out_byte = hdr_size;
    uint8_t  bit_buf = 0;
    int      bit_pos = 7; /* MSB first */
    size_t j;

    for (j = 0; j < input_size; j++) {
        uint8_t sym = input[j];
        int len = lengths[sym];
        uint32_t c = codes[sym];
        int b;
        for (b = len - 1; b >= 0; b--) {
            uint8_t bit = (uint8_t)((c >> b) & 1u);
            bit_buf |= (uint8_t)(bit << bit_pos);
            bit_pos--;
            if (bit_pos < 0) {
                if (out_byte >= *output_size) return -1;
                output[out_byte++] = bit_buf;
                bit_buf = 0;
                bit_pos = 7;
            }
        }
    }
    if (bit_pos < 7) {
        if (out_byte >= *output_size) return -1;
        output[out_byte++] = bit_buf;
    }

    *output_size = out_byte;
    return 0;
}

int raf_zipraf_huffman_decompress(const uint8_t *input, size_t input_size,
                                   uint8_t *output, size_t *output_size) {
    if (!input || !output || !output_size) return -1;
    if (input_size < 260) return -1;

    /* Read header */
    uint8_t  lengths[256];
    uint32_t codes[256];
    int      i, l;
    for (i = 0; i < 256; i++) lengths[i] = input[i];
    size_t orig_size = (size_t)input[256]
                     | ((size_t)input[257] << 8)
                     | ((size_t)input[258] << 16)
                     | ((size_t)input[259] << 24);
    if (*output_size < orig_size) return -1;

    /* Rebuild canonical codes */
    int syms_by_len[16][256];
    int len_count[16];
    for (l = 0; l < 16; l++) len_count[l] = 0;
    for (i = 0; i < 256; i++) {
        if (lengths[i] > 0 && lengths[i] <= 15)
            syms_by_len[lengths[i]][len_count[lengths[i]]++] = i;
    }
    for (i = 0; i < 256; i++) codes[i] = 0;
    uint32_t code = 0;
    for (l = 1; l <= 15; l++) {
        int cnt = len_count[l];
        for (i = 1; i < cnt; i++) {
            int key = syms_by_len[l][i], j;
            for (j = i - 1; j >= 0 && syms_by_len[l][j] > key; j--)
                syms_by_len[l][j + 1] = syms_by_len[l][j];
            syms_by_len[l][j + 1] = key;
        }
        for (i = 0; i < cnt; i++) { codes[syms_by_len[l][i]] = code; code++; }
        code <<= 1;
    }

    /* Decode bitstream */
    size_t in_byte = 260;
    int    bit_pos = 7;
    uint8_t cur_byte = (in_byte < input_size) ? input[in_byte] : 0;
    size_t out_pos = 0;

    while (out_pos < orig_size) {
        uint32_t acc = 0;
        int depth = 0;
        int found = 0;
        while (depth <= 15) {
            uint8_t bit = (uint8_t)((cur_byte >> bit_pos) & 1u);
            acc = (acc << 1) | bit;
            bit_pos--;
            if (bit_pos < 0) {
                in_byte++;
                bit_pos = 7;
                cur_byte = (in_byte < input_size) ? input[in_byte] : 0;
            }
            depth++;
            /* Search for symbol with this code and length */
            for (i = 0; i < 256; i++) {
                if (lengths[i] == (uint8_t)depth && codes[i] == acc) {
                    output[out_pos++] = (uint8_t)i;
                    found = 1;
                    break;
                }
            }
            if (found) break;
        }
        if (!found) break; /* corrupted or done */
    }

    *output_size = out_pos;
    return 0;
}
